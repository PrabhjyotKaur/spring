package com.cg.eztrac.resttemplate;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.common.IRestServiceResponse;

public class EztracRestClient {
	static final String CLASS_NAME = "RestClient";

	@SuppressWarnings("unused")
	public static IRestServiceResponse invokeRestService(IRestServiceRequest requestObject, String requestService, String responseObjectType) {
		final String methodName = "invokeRestService";
		String defaultRestServiceMethod = "POST";
		String serviceMethodType = "";
		HttpMethod serviceMethod = null;

		if (null == serviceMethodType) {
			serviceMethod = HttpMethod.valueOf(serviceMethodType);
		} else {
			serviceMethod = HttpMethod.valueOf(defaultRestServiceMethod);
		}
		
		MultiValueMap<String, Object> headers = new LinkedMultiValueMap<String, Object>();
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/json");
		HttpEntity request = new HttpEntity(requestObject, headers);

		ResponseEntity<?> response = null;
		try {
			RestTemplate restTemplateObj = new RestTemplate();
			response = restTemplateObj.exchange(requestService, HttpMethod.valueOf(defaultRestServiceMethod), request, Class.forName(responseObjectType));
			System.out.println("********************************************************"+response);
		} catch (Exception execption) {

		}
		IRestServiceResponse respObj = null;
		if (null != response) {
			respObj = (IRestServiceResponse) response.getBody();
			return respObj;
		}
		
		return respObj;
}
}
