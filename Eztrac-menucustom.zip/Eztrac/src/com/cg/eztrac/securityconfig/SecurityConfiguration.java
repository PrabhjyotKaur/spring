 package com.cg.eztrac.securityconfig;

//@Configuration
//@EnableWebSecurity
/*
public class SecurityConfiguration extends WebSecurityConfigurerAdapter{
	
	@Autowired
    @Qualifier("customUserDetailsService")
    UserDetailsService userDetailsService;

	@Autowired
	public void configureGlobalSecurity(AuthenticationManagerBuilder auth) throws Exception{
		auth.userDetailsService(userDetailsService);
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http.authorizeRequests()
		.antMatchers("/home").access("hasAnyRole('USER','ADMIN')")
		.antMatchers("/admin/**").access("hasRole('ADMIN')")
		.and().formLogin().loginPage("/login").
		loginProcessingUrl("/home").
		usernameParameter("username").
		passwordParameter("password").
		defaultSuccessUrl("/home").
		and().exceptionHandling().accessDeniedPage("/access_denied");
		and().logout().
		logoutUrl("");
	}

	private HttpSecurity and() {
		// TODO Auto-generated method stub
		return null;
	}

}
 */
