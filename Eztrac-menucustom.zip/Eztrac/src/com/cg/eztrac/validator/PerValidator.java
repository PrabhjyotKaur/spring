package com.cg.eztrac.validator;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.PerVO;

@Component(value="perValidator")
public class PerValidator implements Validator {
	
	private static final String CLASS_NAME = "PerValidator";
	
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object perObj, Errors errors) {
		String methodName = "validate";
		
		PerVO perVo = (PerVO)perObj;
		
		//perNumber
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perNumber", "error.per.perNumber.required");
		
		//currentPhase
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "currentPhase", "error.per.currentPhase.required");
		
		//description
		if(StringUtils.isEmpty(perVo.getDescription())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "description", "error.per.description.required");
		} else {
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "description", "error.per.description.minMaxLength", perVo.getDescription().length(), 10, 200);
		}
		
		//perReceiptDt
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perReceiptDt", "error.per.perReceiptDt.required");
		
		//parNumber
		if(!StringUtils.isEmpty(perVo.getParNum())) {
			EztracValidationUtil.rejectIfLengthMismatch(errors, "parNum", "error.per.parNumber.length", perVo.getParNum().length(), 10);
		}
	}
}
