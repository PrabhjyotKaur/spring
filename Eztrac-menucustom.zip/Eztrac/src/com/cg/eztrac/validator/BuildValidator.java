package com.cg.eztrac.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.vo.BuildVO;

@Component(value="buildValidator")
public class BuildValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return false;
	}

	@Override
	public void validate(Object build, Errors errors) {
		
		BuildVO buildVo = (BuildVO) build;
		//ValidationUtils.rejectIfEmpty(errors, "currentBuildPhaseList", "Current Phase field cannot be empty");

	}

}

