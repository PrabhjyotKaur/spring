package com.cg.eztrac.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.validator.PerValidator;
import com.cg.eztrac.vo.PerVO;

/*
 * @Author Vamshi
 * */
@Controller
public class PerController {
	
	private static final String CLASS_NAME = "PerController";
	
	@Autowired
	PerValidator perValidator;
	
	@RequestMapping(value = "/per_new", method = RequestMethod.GET)
	public ModelAndView perNew() {
		final String METHOD_NAME = "perNew";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, METHOD_NAME, METHOD_NAME);
		
		PerVO perVo = new PerVO();
		
		perVo.setPerNumber("PR123456");
		
		List<String> currentPerPhaseList = new ArrayList<String>();
		currentPerPhaseList.add("Requirement");
		currentPerPhaseList.add("Design");
		currentPerPhaseList.add("Construction");
		currentPerPhaseList.add("Testing");
		currentPerPhaseList.add("Release");

		perVo.setCurrentPerPhaseList(currentPerPhaseList);
		
		String restrictionPattern = ICommonConstants.PER_PERNEW_RESTRICTION_PATTERN;
		
		//TODO - Below Logic to be replaced from getAllSubSectionList details that we receive from Login Service Starts
		String perEditRestrictionPattern = ICommonConstants.PER_PEREDIT_RESTRICTION_PATTERN;
		String buildNewRestrictionPattern = ICommonConstants.BUILD_BUILDNEW_RESTRICTION_PATTERN;
		String buildEditRestrictionPattern = ICommonConstants.BUILD_BUILDEDIT_RESTRICTION_PATTERN;
		
		List<String> allSubSectionNameList = new ArrayList<String>();
		allSubSectionNameList.add(restrictionPattern+"perNumber");
		allSubSectionNameList.add(restrictionPattern+"currentPhase");
		allSubSectionNameList.add(buildNewRestrictionPattern+"perNumber");
		allSubSectionNameList.add(buildNewRestrictionPattern+"currentPhase");
		allSubSectionNameList.add(buildEditRestrictionPattern+"perNumber");
		allSubSectionNameList.add(buildEditRestrictionPattern+"currentPhase");
		allSubSectionNameList.add(perEditRestrictionPattern+"perNumber");
		allSubSectionNameList.add(perEditRestrictionPattern+"currentPhase");
		//TODO - Below Logic to be replaced from getAllSubSectionList details that we receive from Login Service Ends
		
		//RestrictionMatrix Logic for UI
		Map<String, String> restrictionMatrixMap = CommonUtility.getRestrictionMatrixMap(allSubSectionNameList, restrictionPattern);
		perVo.setRestrictionMatrixMap(restrictionMatrixMap);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "perNumber:"+perVo.getRestrictionMatrixMap().get("perNumber")+":", "");
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "currentPhase:"+perVo.getRestrictionMatrixMap().get("currentPhase")+":", "");
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "parNum:"+perVo.getRestrictionMatrixMap().get("parNum")+":", "");
		
		ModelAndView mav = new ModelAndView("per");
		mav.addObject("perVo", perVo);
		return mav;
	}
	
	@RequestMapping(value = "/per_submit", method = RequestMethod.POST)
	public ModelAndView perSubmit(@ModelAttribute("perVo") @Valid PerVO perVo, BindingResult result) {
		
		final String METHOD_NAME = "perSubmit";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, METHOD_NAME, METHOD_NAME);
		
		//Invoke Validator for Server Side Validations
		perValidator.validate(perVo, result);
		
		ModelAndView mav = new ModelAndView("per");
		mav.addObject("perVo", perVo);
		return mav;
	}
}
