package com.cg.eztrac.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.vo.BuildVO;

@Controller
public class BuildController {

	
	/*@Autowired
	BuildValidator buildValidator;*/

	@RequestMapping(value = {"/build_new" }, method = RequestMethod.GET)
	public ModelAndView buildNew() {

		LoggerManager.writeInfoLog("BuildController","buildNew","Build New", "Entering Build New Page");

		
		BuildVO buildVo = new BuildVO();
		
		//TODO
		List<String> currentBuildPhaseList = new ArrayList<String>();
		currentBuildPhaseList.add("Kick-Off");
		currentBuildPhaseList.add("Requirement");
		currentBuildPhaseList.add("Design");
		currentBuildPhaseList.add("Construction");
		buildVo.setCurrentBuildPhaseList(currentBuildPhaseList);
		
		List<String> projectHealthList = new ArrayList<String>();
		projectHealthList.add("Immediate Action Required");
		projectHealthList.add("Not Meeting Completion Date");
		projectHealthList.add("Meeting Completion Date");
		projectHealthList.add("On Hold");
		buildVo.setProjectHealthList(projectHealthList);
		
		List<String> assignedToList = new ArrayList<String>();
		assignedToList.add("Employee1");
		assignedToList.add("Employee2");
		assignedToList.add("Employee3");
		assignedToList.add("Employee4");
		assignedToList.add("Employee5");
		buildVo.setAssignedToList(assignedToList);
		
		ModelAndView mav = new ModelAndView("build");
		mav.addObject("buildVo", buildVo);
		return mav;
	}
	
	@RequestMapping(value = "/build_submit", method=RequestMethod.POST)
	public ModelAndView buildSubmit(ModelAndView mv,@ModelAttribute("buildVo") @Valid BuildVO buildVo,BindingResult result ) {
		
		LoggerManager.writeInfoLog("BuildController", "buildSubmit", "Entered build submit controller", "Before server side validations");
		System.out.println("planning req Loe"+buildVo.getPlanningReqLoe());	
		System.out.println(buildVo);
		//buildValidator.validate(buildVo, result);
		
		if(result.hasErrors())
		{
			System.out.println("Error occured");
			return new ModelAndView("build");
		}
		else
		{
			System.out.println("success");
			//System.out.println(buildVo);
			return null;
			
		}
	}
	/*
	@RequestMapping(value = { "/", "/build" }, method = RequestMethod.POST)
	public ModelAndView processForm(@ModelAttribute(value = "buildVo") BuildVO buildVo) {
		System.out.println("save - post");
		buildService = new BuildServiceImpl();
		buildService.buildSave(buildVo);

		ModelAndView mav = new ModelAndView("build", "buildVo", buildVo);

		return mav;
	}
	*/

}
