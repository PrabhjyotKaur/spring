package com.cg.eztrac.sessionmanager;

public interface DataPersistence {
	
	public Object persitData(String key, Object obj);
	public Object getPersistData();
	public Object removePersistData();
	

}
