package com.cg.eztrac.util;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

public class EztracValidationUtil {
	
	private static final String CLASS_NAME = "EztracValidationUtil";

	public static void rejectIfEmptyOrWhitespace(Errors errors, String fieldName, String fieldErrorMessage) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, fieldName, fieldErrorMessage);
	}
	
	public static void rejectIfLengthMismatch(Errors errors, String fieldName, String fieldErrorMessage, int fieldLength, int requiredLength) {
		if(fieldLength != requiredLength) {
			errors.rejectValue(fieldName, fieldErrorMessage);
		}
	}
	
	public static void rejectIfMinMaxLengthMismatch(Errors errors, String fieldName, String fieldErrorMessage, int fieldLength, int requiredMinLength, int requiredMaxLength) {
		if(fieldLength < requiredMinLength || fieldLength > requiredMaxLength) {
			errors.rejectValue(fieldName, fieldErrorMessage);
		}
	}
}
