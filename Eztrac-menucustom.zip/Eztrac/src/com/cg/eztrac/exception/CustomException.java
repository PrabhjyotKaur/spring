package com.cg.eztrac.exception;

public class CustomException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3119319123542213589L;

}
