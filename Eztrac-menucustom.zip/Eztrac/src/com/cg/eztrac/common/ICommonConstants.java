package com.cg.eztrac.common;

public interface ICommonConstants {

	String STRING_TRUE = "true";
	String STRING_FALSE = "false";
	
	String PIPE_SEPARATOR="|";
	
	String loginService = "loginWS_URL";
	String USERDETAILS = "UserDetails";
	String ROLEPERMISSION = "RolePermission";
	String ALLSUBSECTIONDETAILS = "AllSubSectionDetails";
	String LOGIN_SERVICE_LOG_KEY = " - LOGINFLOW - ";
	String DISABLE_STR = "DISABLE";
	String ENABLE_STR = "ENABLE";
	
	String PER_PERNEW_RESTRICTION_PATTERN = "Per~PerNew~";
	String PER_PEREDIT_RESTRICTION_PATTERN = "Per~PerEdit~";
	
	String BUILD_BUILDNEW_RESTRICTION_PATTERN = "Build~BuildNew~";
	String BUILD_BUILDEDIT_RESTRICTION_PATTERN = "Build~BuildEdit~";
	
}
