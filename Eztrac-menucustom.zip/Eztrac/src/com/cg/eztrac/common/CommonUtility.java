package com.cg.eztrac.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommonUtility {

	public static String formatMessage(String className, String methodName, String message,
			String additionalLogDetails) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append("class=");
		sb.append(className);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append("Method=");
		sb.append(methodName);
		if (additionalLogDetails != null) {
			sb.append(ICommonConstants.PIPE_SEPARATOR);
			sb.append(additionalLogDetails);

		}

		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(message);
		return sb.toString();
	}
	
	public static Map<String, String> getRestrictionMatrixMap(List<String> allSubSectionNameList, String restrictionMatrixPattern) {
		Map<String, String> restrictionMatrixMap = new HashMap<String, String>();
		if(null != allSubSectionNameList && !allSubSectionNameList.isEmpty()) {
			for(String allSubSectionName: allSubSectionNameList) {
				if(allSubSectionName.contains(restrictionMatrixPattern)) {
					restrictionMatrixMap.put(allSubSectionName.substring(restrictionMatrixPattern.length()), ICommonConstants.STRING_TRUE);
				}
			}
		}
		return restrictionMatrixMap;
	}

}
