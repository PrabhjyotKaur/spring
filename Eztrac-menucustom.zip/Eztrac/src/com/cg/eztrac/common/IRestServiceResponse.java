package com.cg.eztrac.common;
public interface IRestServiceResponse {
	
	String getTokenId();
	
	String getCannelId();
	
	String getResponseCode();
	
	String getResponseDescription(); 

} 