package com.cg.eztrac.vo;

import java.util.List;

public class BuildVO {

	// general tab variables
	private String perNumber;
	private String system;
	private String subSystem;
	private String currentBuildPhase;
	private String projectHealth;
	private String onsiteLeverage;
	private String onsiteTimesheetLeverage;
	private int phaseCompletion;

	private String cancelDate;
	private String assignedTo;
	private String comments;
	private List<String> assignedToList;
	public List<String> getAssignedToList() {
		return assignedToList;
	}
	public void setAssignedToList(List<String> assignedToList) {
		this.assignedToList = assignedToList;
	}
	public String getProjectHealth() {
		return projectHealth;
	}

	private List<String> projectHealthList;
	private List<String> currentBuildPhaseList;

	// loe tab variables - Planning LOE
	private int planningReqLoe;
	private int planningDesignLoe;
	private int planningConLoe;
	private int planningTestingLoe;
	private int planningReleaseLoe;
	private String planningEstDate;

	// loe tab variables - Execution LOE

	private int executionReqLoe;
	private int executionDesignLoe;
	private int executionConLoe;
	private int executionTestingLoe;
	private int executionReleaseLoe;
	private String executionEstDate;

	// loe tab variables - Total execution CC LOE

	private int totalCcReqLoe;
	private int totalCcDesignLoe;
	private int totalCcConLoe;
	private int totalCcTestingLoe;
	private int totalCcReleaseLoe;
	private String totalCcEstDate;

	// loe tab variables - Actual Days

	private int actualReqLoe;
	private int actualDesignLoe;
	private int actualConLoe;
	private int actualTestingLoe;
	private int actualReleaseLoe;
	private String actualEstDate;

	// phase time line variables - Requirement phase
	
	
	private String plannedReqStartDate;
	private String plannedReqEndDate;
	private String actualReqStartDate;
	private String actualReqEndDate;

	// phase time line variables - Design phase

	private String plannedDesignStartDate;
	private String plannedDesignEndDate;
	private String actualDesignStartDate;
	private String actualDesignEndDate;

	// phase time line variables - Construction phase

	private String plannedConStartDate;
	private String plannedConEndDate;
	private String actualConStartDate;
	private String actualConEndDate;

	// phase time line variables - Testing phase

	private String plannedTestingStartDate;
	private String plannedTestingEndDate;
	private String actualTestingStartDate;
	private String actualTestingEndDate;

	// phase time line variables - Release phase

	private String plannedReleaseStartDate;
	private String plannedReleaseEndDate;
	private String actualReleseStartDate;
	private String actualReleaseEndDate;
	
	public String getPerNumber() {
		return perNumber;
	}
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getSubSystem() {
		return subSystem;
	}
	public void setSubSystem(String subSystem) {
		this.subSystem = subSystem;
	}
	public String getCurrentBuildPhase() {
		return currentBuildPhase;
	}
	public void setCurrentBuildPhase(String currentBuildPhase) {
		this.currentBuildPhase = currentBuildPhase;
	}
	public List<String> getProjectHealthList() {
		return projectHealthList;
	}
	public void setProjectHealthList(List<String> projectHealthList) {
		this.projectHealthList = projectHealthList;
	}
	public void setProjectHealth(String projectHealth) {
		this.projectHealth = projectHealth;
	}
	public String getOnsiteLeverage() {
		return onsiteLeverage;
	}
	public void setOnsiteLeverage(String onsiteLeverage) {
		this.onsiteLeverage = onsiteLeverage;
	}
	public String getOnsiteTimesheetLeverage() {
		return onsiteTimesheetLeverage;
	}
	public void setOnsiteTimesheetLeverage(String onsiteTimesheetLeverage) {
		this.onsiteTimesheetLeverage = onsiteTimesheetLeverage;
	}
	public int getPhaseCompletion() {
		return phaseCompletion;
	}
	public void setPhaseCompletion(int phaseCompletion) {
		this.phaseCompletion = phaseCompletion;
	}
	public String getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(String cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public List<String> getCurrentBuildPhaseList() {
		return currentBuildPhaseList;
	}
	public void setCurrentBuildPhaseList(List<String> currentBuildPhaseList) {
		this.currentBuildPhaseList = currentBuildPhaseList;
	}
	public int getPlanningReqLoe() {
		return planningReqLoe;
	}
	public void setPlanningReqLoe(int planningReqLoe) {
		this.planningReqLoe = planningReqLoe;
	}
	public int getPlanningDesignLoe() {
		return planningDesignLoe;
	}
	public void setPlanningDesignLoe(int planningDesignLoe) {
		this.planningDesignLoe = planningDesignLoe;
	}
	public int getPlanningConLoe() {
		return planningConLoe;
	}
	public void setPlanningConLoe(int planningConLoe) {
		this.planningConLoe = planningConLoe;
	}
	public int getPlanningTestingLoe() {
		return planningTestingLoe;
	}
	public void setPlanningTestingLoe(int planningTestingLoe) {
		this.planningTestingLoe = planningTestingLoe;
	}
	public int getPlanningReleaseLoe() {
		return planningReleaseLoe;
	}
	public void setPlanningReleaseLoe(int planningReleaseLoe) {
		this.planningReleaseLoe = planningReleaseLoe;
	}
	public String getPlanningEstDate() {
		return planningEstDate;
	}
	public void setPlanningEstDate(String planningEstDate) {
		this.planningEstDate = planningEstDate;
	}
	public int getExecutionReqLoe() {
		return executionReqLoe;
	}
	public void setExecutionReqLoe(int executionReqLoe) {
		this.executionReqLoe = executionReqLoe;
	}
	public int getExecutionDesignLoe() {
		return executionDesignLoe;
	}
	public void setExecutionDesignLoe(int executionDesignLoe) {
		this.executionDesignLoe = executionDesignLoe;
	}
	public int getExecutionConLoe() {
		return executionConLoe;
	}
	public void setExecutionConLoe(int executionConLoe) {
		this.executionConLoe = executionConLoe;
	}
	public int getExecutionTestingLoe() {
		return executionTestingLoe;
	}
	public void setExecutionTestingLoe(int executionTestingLoe) {
		this.executionTestingLoe = executionTestingLoe;
	}
	public int getExecutionReleaseLoe() {
		return executionReleaseLoe;
	}
	public void setExecutionReleaseLoe(int executionReleaseLoe) {
		this.executionReleaseLoe = executionReleaseLoe;
	}
	public String getExecutionEstDate() {
		return executionEstDate;
	}
	public void setExecutionEstDate(String executionEstDate) {
		this.executionEstDate = executionEstDate;
	}
	public int getTotalCcReqLoe() {
		return totalCcReqLoe;
	}
	public void setTotalCcReqLoe(int totalCcReqLoe) {
		this.totalCcReqLoe = totalCcReqLoe;
	}
	public int getTotalCcDesignLoe() {
		return totalCcDesignLoe;
	}
	public void setTotalCcDesignLoe(int totalCcDesignLoe) {
		this.totalCcDesignLoe = totalCcDesignLoe;
	}
	public int getTotalCcConLoe() {
		return totalCcConLoe;
	}
	public void setTotalCcConLoe(int totalCcConLoe) {
		this.totalCcConLoe = totalCcConLoe;
	}
	public int getTotalCcTestingLoe() {
		return totalCcTestingLoe;
	}
	public void setTotalCcTestingLoe(int totalCcTestingLoe) {
		this.totalCcTestingLoe = totalCcTestingLoe;
	}
	public int getTotalCcReleaseLoe() {
		return totalCcReleaseLoe;
	}
	public void setTotalCcReleaseLoe(int totalCcReleaseLoe) {
		this.totalCcReleaseLoe = totalCcReleaseLoe;
	}
	public String getTotalCcEstDate() {
		return totalCcEstDate;
	}
	public void setTotalCcEstDate(String totalCcEstDate) {
		this.totalCcEstDate = totalCcEstDate;
	}
	public int getActualReqLoe() {
		return actualReqLoe;
	}
	public void setActualReqLoe(int actualReqLoe) {
		this.actualReqLoe = actualReqLoe;
	}
	public int getActualDesignLoe() {
		return actualDesignLoe;
	}
	public void setActualDesignLoe(int actualDesignLoe) {
		this.actualDesignLoe = actualDesignLoe;
	}
	public int getActualConLoe() {
		return actualConLoe;
	}
	public void setActualConLoe(int actualConLoe) {
		this.actualConLoe = actualConLoe;
	}
	public int getActualTestingLoe() {
		return actualTestingLoe;
	}
	public void setActualTestingLoe(int actualTestingLoe) {
		this.actualTestingLoe = actualTestingLoe;
	}
	public int getActualReleaseLoe() {
		return actualReleaseLoe;
	}
	public void setActualReleaseLoe(int actualReleaseLoe) {
		this.actualReleaseLoe = actualReleaseLoe;
	}
	public String getActualEstDate() {
		return actualEstDate;
	}
	public void setActualEstDate(String actualEstDate) {
		this.actualEstDate = actualEstDate;
	}
	public String getPlannedReqStartDate() {
		return plannedReqStartDate;
	}
	public void setPlannedReqStartDate(String plannedReqStartDate) {
		this.plannedReqStartDate = plannedReqStartDate;
	}
	public String getPlannedReqEndDate() {
		return plannedReqEndDate;
	}
	public void setPlannedReqEndDate(String plannedReqEndDate) {
		this.plannedReqEndDate = plannedReqEndDate;
	}
	public String getActualReqStartDate() {
		return actualReqStartDate;
	}
	public void setActualReqStartDate(String actualReqStartDate) {
		this.actualReqStartDate = actualReqStartDate;
	}
	public String getActualReqEndDate() {
		return actualReqEndDate;
	}
	public void setActualReqEndDate(String actualReqEndDate) {
		this.actualReqEndDate = actualReqEndDate;
	}
	public String getPlannedDesignStartDate() {
		return plannedDesignStartDate;
	}
	public void setPlannedDesignStartDate(String plannedDesignStartDate) {
		this.plannedDesignStartDate = plannedDesignStartDate;
	}
	public String getPlannedDesignEndDate() {
		return plannedDesignEndDate;
	}
	public void setPlannedDesignEndDate(String plannedDesignEndDate) {
		this.plannedDesignEndDate = plannedDesignEndDate;
	}
	public String getActualDesignStartDate() {
		return actualDesignStartDate;
	}
	public void setActualDesignStartDate(String actualDesignStartDate) {
		this.actualDesignStartDate = actualDesignStartDate;
	}
	public String getActualDesignEndDate() {
		return actualDesignEndDate;
	}
	public void setActualDesignEndDate(String actualDesignEndDate) {
		this.actualDesignEndDate = actualDesignEndDate;
	}
	public String getPlannedConStartDate() {
		return plannedConStartDate;
	}
	public void setPlannedConStartDate(String plannedConStartDate) {
		this.plannedConStartDate = plannedConStartDate;
	}
	public String getPlannedConEndDate() {
		return plannedConEndDate;
	}
	public void setPlannedConEndDate(String plannedConEndDate) {
		this.plannedConEndDate = plannedConEndDate;
	}
	public String getActualConStartDate() {
		return actualConStartDate;
	}
	public void setActualConStartDate(String actualConStartDate) {
		this.actualConStartDate = actualConStartDate;
	}
	public String getActualConEndDate() {
		return actualConEndDate;
	}
	public void setActualConEndDate(String actualConEndDate) {
		this.actualConEndDate = actualConEndDate;
	}
	public String getPlannedTestingStartDate() {
		return plannedTestingStartDate;
	}
	public void setPlannedTestingStartDate(String plannedTestingStartDate) {
		this.plannedTestingStartDate = plannedTestingStartDate;
	}
	public String getPlannedTestingEndDate() {
		return plannedTestingEndDate;
	}
	public void setPlannedTestingEndDate(String plannedTestingEndDate) {
		this.plannedTestingEndDate = plannedTestingEndDate;
	}
	public String getActualTestingStartDate() {
		return actualTestingStartDate;
	}
	public void setActualTestingStartDate(String actualTestingStartDate) {
		this.actualTestingStartDate = actualTestingStartDate;
	}
	public String getActualTestingEndDate() {
		return actualTestingEndDate;
	}
	public void setActualTestingEndDate(String actualTestingEndDate) {
		this.actualTestingEndDate = actualTestingEndDate;
	}
	public String getPlannedReleaseStartDate() {
		return plannedReleaseStartDate;
	}
	public void setPlannedReleaseStartDate(String plannedReleaseStartDate) {
		this.plannedReleaseStartDate = plannedReleaseStartDate;
	}
	public String getPlannedReleaseEndDate() {
		return plannedReleaseEndDate;
	}
	public void setPlannedReleaseEndDate(String plannedReleaseEndDate) {
		this.plannedReleaseEndDate = plannedReleaseEndDate;
	}
	public String getActualReleseStartDate() {
		return actualReleseStartDate;
	}
	public void setActualReleseStartDate(String actualReleseStartDate) {
		this.actualReleseStartDate = actualReleseStartDate;
	}
	public String getActualReleaseEndDate() {
		return actualReleaseEndDate;
	}
	public void setActualReleaseEndDate(String actualReleaseEndDate) {
		this.actualReleaseEndDate = actualReleaseEndDate;
	}
	
	@Override
	public String toString() {
		return "BuildVO [perNumber=" + perNumber + ", system=" + system + ", subSystem=" + subSystem + ", currentBuildPhase="
				+ currentBuildPhase + ", projectHealth=" + projectHealth + ", onsiteLeverage=" + onsiteLeverage
				+ ", onsiteTimesheetLeverage=" + onsiteTimesheetLeverage + ", phaseCompletion=" + phaseCompletion
				+ ", cancelDate=" + cancelDate + ", assignedTo=" + assignedTo + ", comments=" + comments
				+ ", currentBuildPhaseList=" + currentBuildPhaseList + ", planningReqLoe=" + planningReqLoe
				+ ", planningDesignLoe=" + planningDesignLoe + ", planningConLoe=" + planningConLoe
				+ ", planningTestingLoe=" + planningTestingLoe + ", planningReleaseLoe=" + planningReleaseLoe
				+ ", planningEstDate=" + planningEstDate + ", executionReqLoe=" + executionReqLoe
				+ ", executionDesignLoe=" + executionDesignLoe + ", executionConLoe=" + executionConLoe
				+ ", executionTestingLoe=" + executionTestingLoe + ", executionReleaseLoe=" + executionReleaseLoe
				+ ", executionEstDate=" + executionEstDate + ", totalCcReqLoe=" + totalCcReqLoe + ", totalCcDesignLoe="
				+ totalCcDesignLoe + ", totalCcConLoe=" + totalCcConLoe + ", totalCcTestingLoe=" + totalCcTestingLoe
				+ ", totalCcReleaseLoe=" + totalCcReleaseLoe + ", totalCcEstDate=" + totalCcEstDate + ", actualReqLoe="
				+ actualReqLoe + ", actualDesignLoe=" + actualDesignLoe + ", actualConLoe=" + actualConLoe
				+ ", actualTestingLoe=" + actualTestingLoe + ", actualReleaseLoe=" + actualReleaseLoe
				+ ", actualEstDate=" + actualEstDate + ", plannedReqStartDate=" + plannedReqStartDate
				+ ", plannedReqEndDate=" + plannedReqEndDate + ", actualReqStartDate=" + actualReqStartDate
				+ ", actualReqEndDate=" + actualReqEndDate + ", plannedDesignStartDate=" + plannedDesignStartDate
				+ ", plannedDesignEndDate=" + plannedDesignEndDate + ", actualDesignStartDate=" + actualDesignStartDate
				+ ", actualDesignEndDate=" + actualDesignEndDate + ", plannedConStartDate=" + plannedConStartDate
				+ ", plannedConEndDate=" + plannedConEndDate + ", actualConStartDate=" + actualConStartDate
				+ ", actualConEndDate=" + actualConEndDate + ", plannedTestingStartDate=" + plannedTestingStartDate
				+ ", plannedTestingEndDate=" + plannedTestingEndDate + ", actualTestingStartDate="
				+ actualTestingStartDate + ", actualTestingEndDate=" + actualTestingEndDate
				+ ", plannedReleaseStartDate=" + plannedReleaseStartDate + ", plannedReleaseEndDate="
				+ plannedReleaseEndDate + ", actualReleseStartDate=" + actualReleseStartDate + ", actualReleaseEndDate="
				+ actualReleaseEndDate + "]";
	}

	
}
