package com.cg.eztrac.vo;

import java.util.List;
import java.util.Map;

public class PerVO {
	
	private String perNumber;
	private String currentPhase;
	private String[] managerToNotify;//Not sure
	private String description;
	private String prjctCordntr;
	private String parNum;
	private String perReceiptDt;
	private String projectType;
	private String projectHealth;
	private String poNum;
	private String poAmount;
	private String projComments;
	private String perAuditCreatedBy;
	private String perAuditCreatedOn;
	private String perAuditModifiedBy;
	private String perAuditModifiedOn;
	private String perAuditDeletedBy;
	private String perAuditDeletedOn;
	/*Schedule Updates*/
	private String schedulingCallDate;
	private String cancellationDate;
	private String currentScheduledStartDate;
	private String currentScheduledEndtDate;
	private String stopDate;
	private String restartDate;
	/*Schedule Updates*/
	/*Planning LOE*/
	private Integer planningReqLOE;
	private Integer planningDesignLOE;
	private Integer planningConsLOE;
	private Integer planningTestLOE;
	private Integer planningReleaseLOE;
	private Integer totalPlanningLOE;
	/*Planning LOE End*/
	/*Execution LOE*/
	private Integer execReqLOE;
	private Integer execDesignLOE;
	private Integer execConsLOE;
	private Integer execTestLOE;
	private Integer execReleaseLOE;
	private Integer totalexecLOE;
	/*Execution LOE End*/
	/*Actual LOE End*/
	private Integer actReqLOE;
	private Integer actDesignLOE;
	private Integer actConsLOE;
	private Integer actTestLOE;
	private Integer actReleaseLOE;
	private Integer totalActLOE;
	/*Phase Time Lines*/
	private String ptPlandReqStartDt;
	private String ptPlandReqEndDt;
	private String ptActReqStartDt;
	private String ptActReqEndDt;
	
	private String ptPlandDsgnStartDt;
	private String ptPlandDsgnEndDt;
	private String ptActDsgnStartDt;
	private String ptActDsgnEndDt;
	
	private String ptPlandConsStartDt;
	private String ptPlandConsEndDt;
	private String ptActConsStartDt;
	private String ptActConsEndDt;
	
	private String ptPlandTestStartDt;
	private String ptPlandTestEndDt;
	private String ptActTestStartDt;
	private String ptActTestEndDt;
	
	private String ptPlandRelStartDt;
	private String ptPlandRelEndDt;
	private String ptActRelStartDt;
	private String ptActRelEndDt;
	
	private List<String> currentPerPhaseList;
	
	private Map<String, String> restrictionMatrixMap;
	
	/*CC Occordion*/
	
	public String getPerNumber() {
		return perNumber;
	}
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	public String getCurrentPhase() {
		return currentPhase;
	}
	public void setCurrentPhase(String currentPhase) {
		this.currentPhase = currentPhase;
	}
	public String[] getManagerToNotify() {
		return managerToNotify;
	}
	public void setManagerToNotify(String[] managerToNotify) {
		this.managerToNotify = managerToNotify;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPrjctCordntr() {
		return prjctCordntr;
	}
	public void setPrjctCordntr(String prjctCordntr) {
		this.prjctCordntr = prjctCordntr;
	}
	public String getParNum() {
		return parNum;
	}
	public void setParNum(String parNum) {
		this.parNum = parNum;
	}
	public String getPerReceiptDt() {
		return perReceiptDt;
	}
	public void setPerReceiptDt(String perReceiptDt) {
		this.perReceiptDt = perReceiptDt;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public String getProjectHealth() {
		return projectHealth;
	}
	public void setProjectHealth(String projectHealth) {
		this.projectHealth = projectHealth;
	}
	public String getPoNum() {
		return poNum;
	}
	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	public String getPoAmount() {
		return poAmount;
	}
	public void setPoAmount(String poAmount) {
		this.poAmount = poAmount;
	}
	public String getProjComments() {
		return projComments;
	}
	public void setProjComments(String projComments) {
		this.projComments = projComments;
	}
	
	public String getPerAuditCreatedBy() {
		return perAuditCreatedBy;
	}
	public void setPerAuditCreatedBy(String perAuditCreatedBy) {
		this.perAuditCreatedBy = perAuditCreatedBy;
	}
	public String getPerAuditCreatedOn() {
		return perAuditCreatedOn;
	}
	public void setPerAuditCreatedOn(String perAuditCreatedOn) {
		this.perAuditCreatedOn = perAuditCreatedOn;
	}
	public String getPerAuditModifiedBy() {
		return perAuditModifiedBy;
	}
	public void setPerAuditModifiedBy(String perAuditModifiedBy) {
		this.perAuditModifiedBy = perAuditModifiedBy;
	}
	public String getPerAuditModifiedOn() {
		return perAuditModifiedOn;
	}
	public void setPerAuditModifiedOn(String perAuditModifiedOn) {
		this.perAuditModifiedOn = perAuditModifiedOn;
	}
	public String getPerAuditDeletedBy() {
		return perAuditDeletedBy;
	}
	public void setPerAuditDeletedBy(String perAuditDeletedBy) {
		this.perAuditDeletedBy = perAuditDeletedBy;
	}
	public String getPerAuditDeletedOn() {
		return perAuditDeletedOn;
	}
	public void setPerAuditDeletedOn(String perAuditDeletedOn) {
		this.perAuditDeletedOn = perAuditDeletedOn;
	}
	public String getSchedulingCallDate() {
		return schedulingCallDate;
	}
	public void setSchedulingCallDate(String schedulingCallDate) {
		this.schedulingCallDate = schedulingCallDate;
	}
	public String getCancellationDate() {
		return cancellationDate;
	}
	public void setCancellationDate(String cancellationDate) {
		this.cancellationDate = cancellationDate;
	}
	public String getCurrentScheduledStartDate() {
		return currentScheduledStartDate;
	}
	public void setCurrentScheduledStartDate(String currentScheduledStartDate) {
		this.currentScheduledStartDate = currentScheduledStartDate;
	}
	public String getCurrentScheduledEndtDate() {
		return currentScheduledEndtDate;
	}
	public void setCurrentScheduledEndtDate(String currentScheduledEndtDate) {
		this.currentScheduledEndtDate = currentScheduledEndtDate;
	}
	public String getStopDate() {
		return stopDate;
	}
	public void setStopDate(String stopDate) {
		this.stopDate = stopDate;
	}
	public String getRestartDate() {
		return restartDate;
	}
	public void setRestartDate(String restartDate) {
		this.restartDate = restartDate;
	}
	public Integer getPlanningReqLOE() {
		return planningReqLOE;
	}
	public void setPlanningReqLOE(Integer planningReqLOE) {
		this.planningReqLOE = planningReqLOE;
	}
	public Integer getPlanningDesignLOE() {
		return planningDesignLOE;
	}
	public void setPlanningDesignLOE(Integer planningDesignLOE) {
		this.planningDesignLOE = planningDesignLOE;
	}
	public Integer getPlanningConsLOE() {
		return planningConsLOE;
	}
	public void setPlanningConsLOE(Integer planningConsLOE) {
		this.planningConsLOE = planningConsLOE;
	}
	public Integer getPlanningTestLOE() {
		return planningTestLOE;
	}
	public void setPlanningTestLOE(Integer planningTestLOE) {
		this.planningTestLOE = planningTestLOE;
	}
	public Integer getPlanningReleaseLOE() {
		return planningReleaseLOE;
	}
	public void setPlanningReleaseLOE(Integer planningReleaseLOE) {
		this.planningReleaseLOE = planningReleaseLOE;
	}
	public Integer getTotalPlanningLOE() {
		return totalPlanningLOE;
	}
	public void setTotalPlanningLOE(Integer totalPlanningLOE) {
		this.totalPlanningLOE = totalPlanningLOE;
	}
	public Integer getExecReqLOE() {
		return execReqLOE;
	}
	public void setExecReqLOE(Integer execReqLOE) {
		this.execReqLOE = execReqLOE;
	}
	public Integer getExecDesignLOE() {
		return execDesignLOE;
	}
	public void setExecDesignLOE(Integer execDesignLOE) {
		this.execDesignLOE = execDesignLOE;
	}
	public Integer getExecConsLOE() {
		return execConsLOE;
	}
	public void setExecConsLOE(Integer execConsLOE) {
		this.execConsLOE = execConsLOE;
	}
	public Integer getExecTestLOE() {
		return execTestLOE;
	}
	public void setExecTestLOE(Integer execTestLOE) {
		this.execTestLOE = execTestLOE;
	}
	public Integer getExecReleaseLOE() {
		return execReleaseLOE;
	}
	public void setExecReleaseLOE(Integer execReleaseLOE) {
		this.execReleaseLOE = execReleaseLOE;
	}
	public Integer getTotalexecLOE() {
		return totalexecLOE;
	}
	public void setTotalexecLOE(Integer totalexecLOE) {
		this.totalexecLOE = totalexecLOE;
	}
	public Integer getActReqLOE() {
		return actReqLOE;
	}
	public void setActReqLOE(Integer actReqLOE) {
		this.actReqLOE = actReqLOE;
	}
	public Integer getActDesignLOE() {
		return actDesignLOE;
	}
	public void setActDesignLOE(Integer actDesignLOE) {
		this.actDesignLOE = actDesignLOE;
	}
	public Integer getActConsLOE() {
		return actConsLOE;
	}
	public void setActConsLOE(Integer actConsLOE) {
		this.actConsLOE = actConsLOE;
	}
	public Integer getActTestLOE() {
		return actTestLOE;
	}
	public void setActTestLOE(Integer actTestLOE) {
		this.actTestLOE = actTestLOE;
	}
	public Integer getActReleaseLOE() {
		return actReleaseLOE;
	}
	public void setActReleaseLOE(Integer actReleaseLOE) {
		this.actReleaseLOE = actReleaseLOE;
	}
	public Integer getTotalActLOE() {
		return totalActLOE;
	}
	public void setTotalActLOE(Integer totalActLOE) {
		this.totalActLOE = totalActLOE;
	}
	public String getPtPlandReqStartDt() {
		return ptPlandReqStartDt;
	}
	public void setPtPlandReqStartDt(String ptPlandReqStartDt) {
		this.ptPlandReqStartDt = ptPlandReqStartDt;
	}
	public String getPtPlandReqEndDt() {
		return ptPlandReqEndDt;
	}
	public void setPtPlandReqEndDt(String ptPlandReqEndDt) {
		this.ptPlandReqEndDt = ptPlandReqEndDt;
	}
	public String getPtActReqStartDt() {
		return ptActReqStartDt;
	}
	public void setPtActReqStartDt(String ptActReqStartDt) {
		this.ptActReqStartDt = ptActReqStartDt;
	}
	public String getPtActReqEndDt() {
		return ptActReqEndDt;
	}
	public void setPtActReqEndDt(String ptActReqEndDt) {
		this.ptActReqEndDt = ptActReqEndDt;
	}
	public String getPtPlandDsgnStartDt() {
		return ptPlandDsgnStartDt;
	}
	public void setPtPlandDsgnStartDt(String ptPlandDsgnStartDt) {
		this.ptPlandDsgnStartDt = ptPlandDsgnStartDt;
	}
	public String getPtPlandDsgnEndDt() {
		return ptPlandDsgnEndDt;
	}
	public void setPtPlandDsgnEndDt(String ptPlandDsgnEndDt) {
		this.ptPlandDsgnEndDt = ptPlandDsgnEndDt;
	}
	public String getPtActDsgnStartDt() {
		return ptActDsgnStartDt;
	}
	public void setPtActDsgnStartDt(String ptActDsgnStartDt) {
		this.ptActDsgnStartDt = ptActDsgnStartDt;
	}
	public String getPtActDsgnEndDt() {
		return ptActDsgnEndDt;
	}
	public void setPtActDsgnEndDt(String ptActDsgnEndDt) {
		this.ptActDsgnEndDt = ptActDsgnEndDt;
	}
	public String getPtPlandConsStartDt() {
		return ptPlandConsStartDt;
	}
	public void setPtPlandConsStartDt(String ptPlandConsStartDt) {
		this.ptPlandConsStartDt = ptPlandConsStartDt;
	}
	public String getPtPlandConsEndDt() {
		return ptPlandConsEndDt;
	}
	public void setPtPlandConsEndDt(String ptPlandConsEndDt) {
		this.ptPlandConsEndDt = ptPlandConsEndDt;
	}
	public String getPtActConsStartDt() {
		return ptActConsStartDt;
	}
	public void setPtActConsStartDt(String ptActConsStartDt) {
		this.ptActConsStartDt = ptActConsStartDt;
	}
	public String getPtActConsEndDt() {
		return ptActConsEndDt;
	}
	public void setPtActConsEndDt(String ptActConsEndDt) {
		this.ptActConsEndDt = ptActConsEndDt;
	}
	public String getPtPlandTestStartDt() {
		return ptPlandTestStartDt;
	}
	public void setPtPlandTestStartDt(String ptPlandTestStartDt) {
		this.ptPlandTestStartDt = ptPlandTestStartDt;
	}
	public String getPtPlandTestEndDt() {
		return ptPlandTestEndDt;
	}
	public void setPtPlandTestEndDt(String ptPlandTestEndDt) {
		this.ptPlandTestEndDt = ptPlandTestEndDt;
	}
	public String getPtActTestStartDt() {
		return ptActTestStartDt;
	}
	public void setPtActTestStartDt(String ptActTestStartDt) {
		this.ptActTestStartDt = ptActTestStartDt;
	}
	public String getPtActTestEndDt() {
		return ptActTestEndDt;
	}
	public void setPtActTestEndDt(String ptActTestEndDt) {
		this.ptActTestEndDt = ptActTestEndDt;
	}
	public String getPtPlandRelStartDt() {
		return ptPlandRelStartDt;
	}
	public void setPtPlandRelStartDt(String ptPlandRelStartDt) {
		this.ptPlandRelStartDt = ptPlandRelStartDt;
	}
	public String getPtPlandRelEndDt() {
		return ptPlandRelEndDt;
	}
	public void setPtPlandRelEndDt(String ptPlandRelEndDt) {
		this.ptPlandRelEndDt = ptPlandRelEndDt;
	}
	public String getPtActRelStartDt() {
		return ptActRelStartDt;
	}
	public void setPtActRelStartDt(String ptActRelStartDt) {
		this.ptActRelStartDt = ptActRelStartDt;
	}
	public String getPtActRelEndDt() {
		return ptActRelEndDt;
	}
	public void setPtActRelEndDt(String ptActRelEndDt) {
		this.ptActRelEndDt = ptActRelEndDt;
	}
	public List<String> getCurrentPerPhaseList() {
		return currentPerPhaseList;
	}
	public void setCurrentPerPhaseList(List<String> currentPerPhaseList) {
		this.currentPerPhaseList = currentPerPhaseList;
	}
	public Map<String, String> getRestrictionMatrixMap() {
		return restrictionMatrixMap;
	}
	public void setRestrictionMatrixMap(Map<String, String> restrictionMatrixMap) {
		this.restrictionMatrixMap = restrictionMatrixMap;
	}
	@Override
	public String toString() {
		return "PerVO [perNumber=" + perNumber + ", currentPhase=" + currentPhase + ", managerToNotify=" + managerToNotify
				+ ", description=" + description + ", prjctCordntr=" + prjctCordntr + ", parNum=" + parNum + ", perReceiptDt="
				+ perReceiptDt + ", projectType=" + projectType + ", projectHealth=" + projectHealth + ", poNum="
				+ poNum + ", poAmount=" + poAmount + ", projComments=" + projComments + ", perAuditCreatedBy="
				+ perAuditCreatedBy + ", perAuditCreatedOn=" + perAuditCreatedOn + ", perAuditModifiedBy="
				+ perAuditModifiedBy + ", perAuditModifiedOn=" + perAuditModifiedOn + ", perAuditDeletedBy="
				+ perAuditDeletedBy + ", perAuditDeletedOn=" + perAuditDeletedOn + ", schedulingCallDate="
				+ schedulingCallDate + ", cancellationDate=" + cancellationDate + ", currentScheduledStartDate="
				+ currentScheduledStartDate + ", currentScheduledEndtDate=" + currentScheduledEndtDate + ", stopDate="
				+ stopDate + ", restartDate=" + restartDate + ", planningReqLOE=" + planningReqLOE
				+ ", planningDesignLOE=" + planningDesignLOE + ", planningConsLOE=" + planningConsLOE
				+ ", planningTestLOE=" + planningTestLOE + ", planningReleaseLOE=" + planningReleaseLOE
				+ ", totalPlanningLOE=" + totalPlanningLOE + ", execReqLOE=" + execReqLOE + ", execDesignLOE="
				+ execDesignLOE + ", execConsLOE=" + execConsLOE + ", execTestLOE=" + execTestLOE + ", execReleaseLOE="
				+ execReleaseLOE + ", totalexecLOE=" + totalexecLOE + ", actReqLOE=" + actReqLOE + ", actDesignLOE="
				+ actDesignLOE + ", actConsLOE=" + actConsLOE + ", actTestLOE=" + actTestLOE + ", actReleaseLOE="
				+ actReleaseLOE + ", totalActLOE=" + totalActLOE + ", ptPlandReqStartDt=" + ptPlandReqStartDt
				+ ", ptPlandReqEndDt=" + ptPlandReqEndDt + ", ptActReqStartDt=" + ptActReqStartDt + ", ptActReqEndDt="
				+ ptActReqEndDt + ", ptPlandDsgnStartDt=" + ptPlandDsgnStartDt + ", ptPlandDsgnEndDt="
				+ ptPlandDsgnEndDt + ", ptActDsgnStartDt=" + ptActDsgnStartDt + ", ptActDsgnEndDt=" + ptActDsgnEndDt
				+ ", ptPlandConsStartDt=" + ptPlandConsStartDt + ", ptPlandConsEndDt=" + ptPlandConsEndDt
				+ ", ptActConsStartDt=" + ptActConsStartDt + ", ptActConsEndDt=" + ptActConsEndDt
				+ ", ptPlandTestStartDt=" + ptPlandTestStartDt + ", ptPlandTestEndDt=" + ptPlandTestEndDt
				+ ", ptActTestStartDt=" + ptActTestStartDt + ", ptActTestEndDt=" + ptActTestEndDt
				+ ", ptPlandRelStartDt=" + ptPlandRelStartDt + ", ptPlandRelEndDt=" + ptPlandRelEndDt
				+ ", ptActRelStartDt=" + ptActRelStartDt + ", ptActRelEndDt=" + ptActRelEndDt + "]";
	}
	
	
}

