package com.cg.eztrac.vo;

import java.util.HashMap;

import com.google.gson.Gson;

public class HomePageVO {
	
	private HashMap<String, HashMap<String, String>> userMenuAccebiltiyMap = new HashMap<String, HashMap<String, String>>();

	Gson customizeGsonMenu = new Gson();
	String customizeJsonMenu = "";

	public String getCustomizeJsonMenu() {
		return customizeJsonMenu;
	}

	public void setCustomizeJsonMenu(String customizeJsonMenu) {
		this.customizeJsonMenu = customizeJsonMenu;
	}

	public Gson getCustomizeGsonMenu() {
		return customizeGsonMenu;
	}

	public void setCustomizeGsonMenu(Gson customizeGsonMenu) {
		this.customizeGsonMenu = customizeGsonMenu;
	}

	public HashMap<String, HashMap<String, String>> getUserMenuAccebiltiyMap() {
		return userMenuAccebiltiyMap;
	}

	public void setUserMenuAccebiltiyMap(HashMap<String, HashMap<String, String>> userMenuAccebiltiyMap) {
		this.userMenuAccebiltiyMap = userMenuAccebiltiyMap;
	}
}
