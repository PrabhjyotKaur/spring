package com.cg.eztrac.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.SignInService;
import com.cg.eztrac.service.domainobject.RolePersmission;
import com.cg.eztrac.service.domainobject.SubSections;
import com.cg.eztrac.service.impl.SignInImpl;
import com.cg.eztrac.service.request.LoginInfoReq;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.response.LoginInfoRes;
import com.cg.eztrac.service.response.SectionDetailResponse;
import com.cg.eztrac.vo.LoginVO;

public class LoginHelper {
	String className=LoginHelper.class.getSimpleName();
	
	public boolean callSignInService(LoginVO loginVo, HttpSession httpSession) {
		String methodName="callSignInService";
		boolean result = false;
		try {
			SignInService signInService = new SignInImpl();
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "Before calling (service)-loginSignIn()");
//			LoginInfoRes loginresponse = signInService.loginSignIn(populateSignInRequest(loginVo));
			LoginInfoRes loginresponse = null;
			/** parse response from sign in service to allow/deny user login permission */
			result = checkLoginResponse(loginresponse);
			if(!result){
				loginresponse = hardcodeLoginresponse();
			}
//			if(result){
				/** menu and rolepermission and getuserdetails mapping */
				httpSession.setAttribute(ICommonConstants.ROLEPERMISSION, loginresponse.getRolepermission());
				httpSession.setAttribute(ICommonConstants.USERDETAILS, loginresponse.getUserDedail());
//			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After calling (service)-loginSignIn()");
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e , " Exception while callSignInService ");
		}
		
		return true;
	}

	private boolean checkLoginResponse(LoginInfoRes loginresponse) {
		boolean result = true;
		if(null== loginresponse ){
			result = false;
//			object mapping
		}
		return result;
	}
	public SectionDetailRequest populateSectionDetailRequest() {
		SectionDetailRequest request = new SectionDetailRequest();
		request.setChannelId("");
		request.setTokenId("12345");
		return request;
	}

	private LoginInfoReq populateSignInRequest(LoginVO loginVo) throws Exception {
		LoginInfoReq request = new LoginInfoReq();
		request.setLoginId(loginVo.getUserName());
//		request.setPassword(AESEncryption.encrypt(loginVo.getPassword()));
		request.setPassowrd(loginVo.getPassword());
		return request;
	}

	public HashMap<String, HashMap<String, String>> customizeMenu(List<SectionDetailResponse> sectionDetailResponseList, HttpSession httpSession) {
		List<RolePersmission> rolePermissionDetails = (List<RolePersmission>)httpSession.getAttribute(ICommonConstants.ROLEPERMISSION);
		HashMap<String, HashMap<String, String>> userMenuAccebiltiy = null;
		if(null != rolePermissionDetails) {
			userMenuAccebiltiy = getUserMenuAccebiltiy(rolePermissionDetails, sectionDetailResponseList);
		}
		
		return userMenuAccebiltiy;
	}

	private HashMap<String, HashMap<String, String>> getUserMenuAccebiltiy(List<RolePersmission> rolePermissionDetails,
			List<SectionDetailResponse> sectionDetailResponseList) {
		HashMap<String, String> sectionSubSectionMap = null;
		HashMap<String, HashMap<String, String>> roleIdMap = new HashMap<String, HashMap<String, String>>();
		/** Get SubsectionId from ROLEPERMISSSIONS 
		 * Key - RoleID
		 * Value - List<SubSectionId> */
		
		for(RolePersmission rolePersmission:rolePermissionDetails){
			
			sectionSubSectionMap = new HashMap<String, String>();
			rolePersmission.getRoleId();
			ArrayList<Integer> roleSubSectionIdList = new ArrayList<Integer>();
			for(SubSections roleSubSection : rolePersmission.getSubSection()){
				roleSubSectionIdList.add(roleSubSection.getSubSectionId());
			}
			for(SectionDetailResponse sectionDetailResponse : sectionDetailResponseList){
				List<SubSections> subsectionList = sectionDetailResponse.getSubsection();
				String sectionSubSecMapKey = "", sectionSubSecMapValue = sectionDetailResponse.getSectionName()+"$";
				for(SubSections secDetSubSection :subsectionList){
					if(roleSubSectionIdList.contains(secDetSubSection.getSubSectionId())){
						sectionSubSecMapKey = sectionDetailResponse.getSectionId();
						sectionSubSecMapValue += secDetSubSection.getSubSectionName()+"#"+ICommonConstants.ENABLE_STR+ "," ;
					} else {
						sectionSubSecMapValue+= secDetSubSection.getSubSectionName()+"#"+ICommonConstants.DISABLE_STR+ "," ;
					}
				}
				sectionSubSectionMap.put(sectionSubSecMapKey, sectionSubSecMapValue);
			}
			
			roleIdMap.put(rolePersmission.getRoleId()+" "+rolePersmission.getRoleName(), sectionSubSectionMap );
		}
		return roleIdMap;
	}

	public List<SectionDetailResponse> hardcodeSectionDetailsResponse() {
		
		List<SectionDetailResponse> sectionDetailResponseList=new ArrayList<SectionDetailResponse>();
		
		SectionDetailResponse sectionDetailResponse=new SectionDetailResponse();
		
		sectionDetailResponse.setSectionId("11");
		sectionDetailResponse.setSectionName("PROJECTS|PER");
		sectionDetailResponse.setSectionType("1");
		List<SubSections> subectionlist=new ArrayList<SubSections>();
		SubSections subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(102);
		subSection.setSubSectionName("UPLOAD");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubsection(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		sectionDetailResponse=new SectionDetailResponse();
		sectionDetailResponse.setSectionId("12");
		sectionDetailResponse.setSectionName("PROJECTS|BUILD");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(104);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubsection(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		sectionDetailResponse=new SectionDetailResponse();
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		sectionDetailResponse.setSectionId("13");
		sectionDetailResponse.setSectionName("Projects|TimeSheet");
		/*subSection.setSubSectionId(105);
		subSection.setSubSectionName("TIMESHEET");*/
		subectionlist.add(subSection);
		sectionDetailResponse.setSubsection(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		return sectionDetailResponseList;
	}
	
	private LoginInfoRes hardcodeLoginresponse() {
		LoginInfoRes loginInfoResponse=new LoginInfoRes();
		RolePersmission rolePermissionDetails=new RolePersmission();
		List<SubSections> subSectionList=new ArrayList<SubSections>();
		SubSections subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(106);
		subSectionList.add(subSection);
		subSection=new SubSections();
		/*subSection.setSubSectionId(102);
		subSectionList.add(subSection);*/
		subSection=new SubSections();
		subSection.setSubSectionId(109);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(104);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(105);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(107);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(108);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSectionList.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(110);
		subSectionList.add(subSection);
		rolePermissionDetails.setSubSection(subSectionList);
		rolePermissionDetails.setRoleId(1);
		rolePermissionDetails.setRoleName("PMO");
		
		List<RolePersmission> rolePersmissions=new ArrayList<RolePersmission>();
		
		
		rolePersmissions.add(rolePermissionDetails);
		loginInfoResponse.setRolepermission(rolePersmissions);
		//loginInfoResponse.setResponseCode("000");
		return loginInfoResponse;
	}
	
	/*public static void main(String[] args) {
		ArrayList<Integer> checker = new ArrayList<Integer>();
		
		checker.add(101);
		checker.add(102);
		checker.add(103);
		checker.add(104);
		System.out.println(checker.contains(104));
	}*/
}
