	package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.service.domainobject.SubSections;

public class SectionDetailResponse implements IRestServiceResponse{

	String sectionId = "";
	String sectionName = "";
	String sectionType = "";
	List<SubSections> subsection;
	String tokenId = "";
	String responseCode = "";
	String responseDescription = "";
	
	public String getSectionId() {
		return sectionId;	
	}
	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public String getSectionType() {
		return sectionType;
	}
	public void setSectionType(String sectionType) {
		this.sectionType = sectionType;
	}
	
	public List<SubSections> getSubsection() {
		return subsection;
	}
	public void setSubsection(List<SubSections> subsection) {
		this.subsection = subsection;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	
	@Override
	public String getCannelId() {
		// TODO Auto-generated method stub
		return null;
	}

}
