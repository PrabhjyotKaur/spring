package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.service.domainobject.HomePageData;
import com.cg.eztrac.service.domainobject.RolePersmission;
import com.cg.eztrac.service.domainobject.UserDetail;

public class LoginInfoRes implements IRestServiceResponse{
	private UserDetail userDedail;
	private HomePageData homePageData;
	private List<RolePersmission> rolepermission;
	private String responseDescription;
	private String responseCode;
	public UserDetail getUserDedail() {
		return userDedail;
	}
	public void setUserDedail(UserDetail userDedail) {
		this.userDedail = userDedail;
	}
	public HomePageData getHomePageData() {
		return homePageData;
	}
	public void setHomePageData(HomePageData homePageData) {
		this.homePageData = homePageData;
	}
	public List<RolePersmission> getRolepermission() {
		return rolepermission;
	}
	public void setRolepermission(List<RolePersmission> rolepermission) {
		this.rolepermission = rolepermission;
	}

	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getCannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getResponseCode() {
		// TODO Auto-generated method stub
		return responseCode;
	}
	@Override
	public String getResponseDescription() {
		// TODO Auto-generated method stub
		return responseDescription;
	}




}
