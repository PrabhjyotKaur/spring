package com.cg.eztrac.service.impl;

import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.AllSectionDetailService;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.response.SectionDetailResponse;

public class AllSectionDetailServiceImpl implements AllSectionDetailService{

	@Override
	public SectionDetailResponse getAllSectionDetails(SectionDetailRequest sectionDetailRequest) {
		// TODO: logger
		SectionDetailResponse response=(SectionDetailResponse) EztracRestClient.invokeRestService(sectionDetailRequest, "", SectionDetailResponse.class.getName());
		if(null == response){
			
		}
		return response;
	}

}
