package com.cg.eztrac.service.domainobject;

import java.io.Serializable;
import java.util.List;

public class RolePersmission implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1169467925519412183L;
	Integer roleId;
	String roleName;
	List<SubSections> subSection;
//	String token;
//	String sessionId;
//	String channel;
	private String responseCode;
	private String responseDescription;
	/**
	 * @return the roleId
	 */
	public Integer getRoleId() {
		return roleId;
	}
	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	/**
	 * @return the roleName
	 */
	public String getRoleName() {
		return roleName;
	}
	/**
	 * @param roleName the roleName to set
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	/**
	 * @return the subSection
	 */
	public List<SubSections> getSubSection() {
		return subSection;
	}
	/**
	 * @param subSection the subSection to set
	 */
	public void setSubSection(List<SubSections> subSection) {
		this.subSection = subSection;
	}
	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	/**
	 * @return the responseDescription
	 */
	public String getResponseDescription() {
		return responseDescription;
	}
	/**
	 * @param responseDescription the responseDescription to set
	 */
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}


}
