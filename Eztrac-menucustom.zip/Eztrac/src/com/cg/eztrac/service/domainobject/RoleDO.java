package com.cg.eztrac.service.domainobject;

import java.util.List;



public class RoleDO {

	private Integer id;
	private String rolename;
	private List<UserDO> user;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	public List<UserDO> getUser() {
		return user;
	}
	public void setUser(List<UserDO> user) {
		this.user = user;
	}
	
	
}
