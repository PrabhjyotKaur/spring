package com.cg.eztrac.service.domainobject;

public class SubSections {
	private int subSectionId;
	//private ParamValue paramValue;
	//private Section section;
	private String subSectionName;
	private String statusCd;
	/**
	 * @return the subSectionId
	 */
	public int getSubSectionId() {
		return subSectionId;
	}
	/**
	 * @param subSectionId the subSectionId to set
	 */
	public void setSubSectionId(int subSectionId) {
		this.subSectionId = subSectionId;
	}
	/**
	 * @return the subSectionName
	 */
	public String getSubSectionName() {
		return subSectionName;
	}
	/**
	 * @param subSectionName the subSectionName to set
	 */
	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}
	/**
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	/**
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
}
