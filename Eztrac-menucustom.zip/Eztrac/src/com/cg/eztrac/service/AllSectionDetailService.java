package com.cg.eztrac.service;

import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.response.SectionDetailResponse;

public interface AllSectionDetailService {
	public SectionDetailResponse getAllSectionDetails(SectionDetailRequest sectionDetailRequest);
}
