package com.cg.eztrac.config;

/*public class WebXmlConfig extends AbstractSecurityWebApplicationInitializer {

}
*/