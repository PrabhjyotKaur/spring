console.log('%c Proudly Crafted with ZiOn.', 'background: #222; color: #bada55');




/* ---------------------------------------------- /*
 * Preloader
 /* ---------------------------------------------- */
(function(){
	
    $(document).ready(function() {
    	if($(".custom-menu-ul").length){
    		buildCustomMenu();
    	}
    	function buildCustomMenu(){
    		buildProjectsTab();
    	}
    	
    	function buildProjectsTab(){
    		var customMenuVal = $("#customizeJsonMenu").val();
    		$.each(JSON.parse(customMenuVal), function(key, value) {
    			$.each(value, function(i) {
    				console.log(value[i]);
    				var subSecArr = value[i].split("|");
    				var subMenu = subSecArr[1].split("$");
    				if(subMenu.length ==2){
    					var dropdownMenuUL = ".dropdown-menu_"+subMenu[0];//dropdown-menu_PER
    					var subMennuLevel3 = subMenu[1].split(",");
        				var len = subMennuLevel3.length;
        				var anchor;
        				var li ;
        				for (var inc = 0; inc < len; inc++) {
        					if(subMennuLevel3[inc].trim!=""){
        						li = $("<li>");
        						var submenuEnDis=subMennuLevel3[inc].split("#");
        						
        						anchor = $("<a>").addClass(submenuEnDis[1]).attr({"th:href": subMennuLevel3[inc], "href": "#"}).text(submenuEnDis[0]);
        						li.prepend(anchor);
        						$( "ul" ).find( dropdownMenuUL ).append(li);
        					}
        				};
    				}
    			});
    			
    		});
    	}
    });
})(jQuery);
//{1 PMO={11=PROJECTS|PER$NEW#ENABLE,EDIT#ENABLE,UPLOAD#DISABLE,, 12=PROJECTS|BUILD$NEW#ENABLE,EDIT#ENABLE,, 13=PROJECTS|TIMESHEET,}}

