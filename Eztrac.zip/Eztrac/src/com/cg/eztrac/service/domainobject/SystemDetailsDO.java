package com.cg.eztrac.service.domainobject;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.SystemDetailsResponse;
import com.google.gson.Gson;

public class SystemDetailsDO {

	String className = SystemDetailsDO.class.getSimpleName();
	private int subAccountId;
	private int systemID;
	private String systemName;
	private List<SubSystemDO> subsystemDetails;
	
	public List<SystemDetailsDO> callSystemDetailService(SystemDetailsDO systemDetailsDO) {
		
		String methodName="callSystemDetailService";
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In callSystemDetailService", "Before populating the systemDetailsRequest from DO");
		SystemDetailsRequest systemDetailsRequest  = populateSystemRequestFromDO(systemDetailsDO);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In SystemDetailsDO", "Details are populated into systemDetailsRequest");
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In SystemDetailsDO", "Before calling the getSystemDetails() to get systemDetailResponseList ");
		OnLoadCommonService onLoadCommonServcie = new OnLoadCommonServiceImpl();
		List<SystemDetailsResponse> systemDetailsListResponse = onLoadCommonServcie.getSystemDetails(systemDetailsRequest);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.SYSTEM_SERVICE_LOG_KEY+"In SystemDetailsDO", "getAllSystemDetails() is called and got systemDetailServiceResponseList");
		List<SystemDetailsDO> systemDetailsDOList = populateResponseToDO(systemDetailsListResponse);
		
		return systemDetailsDOList;
	}
	
	private SystemDetailsRequest populateSystemRequestFromDO(SystemDetailsDO systemDetailsDO) {
		
		String methodName = "populateSystemRequestFromDO";
		SystemDetailsRequest systemDetailsRequest = new SystemDetailsRequest();
		systemDetailsRequest.setSubAccountId(1);
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.SYSTEM_SERVICE_LOG_KEY + "In populateSystemRequestFromDO", "systemDetailsRequest populated from DO");
		
		return systemDetailsRequest;
	}

	private List<SystemDetailsDO> populateResponseToDO(List<SystemDetailsResponse> systemDetailResponseList) {
		String methodName="populateResponseToDO";
		List<SystemDetailsDO> systemDetailsDOList = new ArrayList<SystemDetailsDO>();
		
		try {
			SystemDetailsDO systemDetailsDO = null;
			Gson gson = new Gson();
			for (int i = 0; i < systemDetailResponseList.size(); i++) {
				systemDetailsDO = new SystemDetailsDO();
				String systemDetailDOJson = gson.toJson(systemDetailResponseList.get(i));
				systemDetailsDO = gson.fromJson(systemDetailDOJson, SystemDetailsDO.class);
				systemDetailsDOList.add(systemDetailsDO);
			}
			LoggerManager.writeInfoLog(className, methodName, ICommonConstants.SYSTEM_SERVICE + "In systemDetailsDO", "Setting SystemDetailsDO from systemDetailsDetailResponse");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDetailsDOList;
	}

	/**
	 * @return the className
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * @param className the className to set
	 */
	public void setClassName(String className) {
		this.className = className;
	}

	/**
	 * @return the subAccountId
	 */
	public int getSubAccountId() {
		return subAccountId;
	}

	/**
	 * @param subAccountId the subAccountId to set
	 */
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}

	/**
	 * @return the systemID
	 */
	public int getSystemID() {
		return systemID;
	}

	/**
	 * @param systemID the systemID to set
	 */
	public void setSystemID(int systemID) {
		this.systemID = systemID;
	}

	/**
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}

	/**
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	/**
	 * @return the subsystemDetails
	 */
	public List<SubSystemDO> getSubsystemDetails() {
		return subsystemDetails;
	}

	/**
	 * @param subsystemDetails the subsystemDetails to set
	 */
	public void setSubsystemDetails(List<SubSystemDO> subsystemDetails) {
		this.subsystemDetails = subsystemDetails;
	}
	
}