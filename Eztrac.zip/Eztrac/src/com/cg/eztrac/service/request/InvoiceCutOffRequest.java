package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class InvoiceCutOffRequest  implements IRestServiceRequest{
	
	Integer subAccountId;
	String tokenId;
	String channel;
	
	
	
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	@Override
	public String getTokenId() {
		return tokenId;
	}
	
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public Integer getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(Integer subAccountId) {
		this.subAccountId = subAccountId;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
