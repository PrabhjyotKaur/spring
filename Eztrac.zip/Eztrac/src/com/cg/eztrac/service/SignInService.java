package com.cg.eztrac.service;

import com.cg.eztrac.service.request.LoginInfoReq;
import com.cg.eztrac.service.response.LoginInfoRes;

public interface SignInService {
	public LoginInfoRes loginSignIn(LoginInfoReq loginInfoReq)  throws Exception;
}
