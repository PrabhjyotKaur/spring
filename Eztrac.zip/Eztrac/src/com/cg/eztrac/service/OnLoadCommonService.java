package com.cg.eztrac.service;

import java.util.List;

import com.cg.eztrac.service.request.ParamDetailsRequest;
import com.cg.eztrac.service.request.RolePermissionRequest;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.ParamDetailsResponse;
import com.cg.eztrac.service.response.RolePermissionRes;
import com.cg.eztrac.service.response.SectionsRes;
import com.cg.eztrac.service.response.SystemDetailsResponse;

public interface OnLoadCommonService {
	
	public List<ParamDetailsResponse> getAllParamDetails(ParamDetailsRequest paramDetailsRequest);
	public SectionsRes getAllSectionDetails(SectionDetailRequest sectionDetailRequest);
	public RolePermissionRes getAllRolePermissionDetails(RolePermissionRequest rolePermissionRequest);
	public List<SystemDetailsResponse> getSystemDetails(SystemDetailsRequest systemDetailsRequest);
}
