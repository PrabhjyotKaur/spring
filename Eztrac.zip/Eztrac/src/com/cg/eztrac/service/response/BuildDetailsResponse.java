package com.cg.eztrac.service.response;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.BuildDO;

@Component(value="buildDetailsResponse")
public class BuildDetailsResponse implements IRestServiceResponse {
	
	private BuildDO build;
	
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	public BuildDO getBuild() {
		return build;
	}
	public String getTokenId() {
		return tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	@Override
	public String toString() {
		return "BuildDetailsResponse [build=" + build + ", tokenId=" + tokenId + ", channelId=" + channelId
				+ ", responseCode=" + responseCode + ", responseDescription=" + responseDescription + ", getBuild()="
				+ getBuild() + ", getTokenId()=" + getTokenId() + ", getChannelId()=" + getChannelId()
				+ ", getResponseCode()=" + getResponseCode() + ", getResponseDescription()=" + getResponseDescription()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	
}