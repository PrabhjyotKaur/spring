package com.cg.eztrac.service.response;

import java.util.Date;

public class UserLocations {
	
	
	private int locationId;
	private String onsiteFlag;
	private Date startDate;
	private Date endDate;
	private String location;
	
	
	
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getOnsiteFlag() {
		return onsiteFlag;
	}
	public void setOnsiteFlag(String onsiteFlag) {
		this.onsiteFlag = onsiteFlag;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}

}
