package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.ParamDO;

public class ParamDetailsResponse implements IRestServiceResponse {
	
	private static final String CLASS_NAME = ParamDetailsResponse.class.getSimpleName();
	
	private int paramTypeID;
	
	private String paramTypeName;
	
	private List<ParamDO> paramValue;
	
	public int getParamTypeID() {
		return paramTypeID;
	}

	public void setParamTypeID(int paramTypeID) {
		this.paramTypeID = paramTypeID;
	}

	public String getParamTypeName() {
		return paramTypeName;
	}

	public void setParamTypeName(String paramTypeName) {
		this.paramTypeName = paramTypeName;
	}

	public List<ParamDO> getParamValue() {
		return paramValue;
	}

	public void setParamValue(List<ParamDO> paramValue) {
		this.paramValue = paramValue;
	}

	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getResponseCode() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getResponseDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toString() {
		return "ParamDetailsResponse [paramTypeID=" + paramTypeID + ", paramTypeName=" + paramTypeName + ", paramValue="
				+ paramValue + "]";
	}
	
}
