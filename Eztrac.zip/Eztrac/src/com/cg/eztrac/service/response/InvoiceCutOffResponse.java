package com.cg.eztrac.service.response;

import java.util.List;

public class InvoiceCutOffResponse {
	

	 List<InvoiceCutOffDetail> invoiceCutOffDetail;
		private String tokenId;
		private String channelId;
		private String responseCode;
		private String responseDescription;
		
		public List<InvoiceCutOffDetail> getInvoiceCutOffDetail() {
			return invoiceCutOffDetail;
		}
		public void setInvoiceCutOffDetail(List<InvoiceCutOffDetail> invoiceCutOffDetail) {
			this.invoiceCutOffDetail = invoiceCutOffDetail;
		}
		public String getTokenId() {
			return tokenId;
		}
		public void setTokenId(String tokenId) {
			this.tokenId = tokenId;
		}
		public String getChannelId() {
			return channelId;
		}
		public void setChannelId(String channelId) {
			this.channelId = channelId;
		}
		public String getResponseCode() {
			return responseCode;
		}
		public void setResponseCode(String responseCode) {
			this.responseCode = responseCode;
		}
		public String getResponseDescription() {
			return responseDescription;
		}
		public void setResponseDescription(String responseDescription) {
			this.responseDescription = responseDescription;
		}
	
}
