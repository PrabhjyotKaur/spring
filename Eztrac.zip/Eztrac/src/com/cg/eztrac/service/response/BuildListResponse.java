package com.cg.eztrac.service.response;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.BuildDO;

@Component(value="buildListResponse")
public class BuildListResponse implements IRestServiceResponse {
	
	private List<BuildDO> buildDetails;
	
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	
	public List<BuildDO> getBuildDetails() {
		return buildDetails;
	}
	public String getTokenId() {
		return tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	@Override
	public String toString() {
		return "BuildListResponse [buildDetails=" + buildDetails + ", tokenId=" + tokenId + ", channelId=" + channelId
				+ ", responseCode=" + responseCode + ", responseDescription=" + responseDescription + "]";
	}
	
}
