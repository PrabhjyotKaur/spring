package com.cg.eztrac.service.response;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceResponse;

@Component(value="perCCInsertResponse")
public class PerCCInsertResponse implements IRestServiceResponse{
	
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	@Override
	public String toString() {
		return "PerCCInsertResponse [tokenId=" + tokenId + ", channelId=" + channelId + ", responseCode=" + responseCode
				+ ", responseDescription=" + responseDescription + "]";
	}
	
}
