package com.cg.eztrac.service.impl;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.BuildService;
import com.cg.eztrac.service.request.BuildDetailsRequest;
import com.cg.eztrac.service.request.BuildInsertRequest;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.response.BuildDetailsResponse;
import com.cg.eztrac.service.response.BuildInsertResponse;
import com.cg.eztrac.service.response.BuildListResponse;

@Component(value="buildServiceImpl")
public class BuildServiceImpl implements BuildService {
	
	private static final String CLASS_NAME = BuildServiceImpl.class.getName();
	
	@Override
	public BuildListResponse getBuildList(BuildListRequest buildListRequest) throws Exception {
		final String methodName = "getBuildList";
		BuildListResponse buildListresponse;
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
		try {
			buildListresponse= (BuildListResponse) EztracRestClient.invokeRestService(buildListRequest, "http://localhost:8093/getBuildList", BuildListResponse.class.getName());
			System.out.println(buildListresponse.getResponseDescription());
		}
		catch (Exception e) {
			System.out.println("BuildSericeImpl catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, methodName, "BuildListResponse Exception", e, "Service error");
			throw new Exception();
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return buildListresponse;
	}

	@Override
	public BuildDetailsResponse getBuildDetails(BuildDetailsRequest buildDetailsRequest) throws Exception {
		final String methodName = "getBuildDetails";
		BuildDetailsResponse buildDetailsResponse; 
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
		try {
			//String s=(String) EztracRestClient.invokeRestService(buildDetailsRequest, "http://localhost:8082/getBuildDetails", String.class.getName());
			//buildDetailsResponse = new Gson().fromJson(s, BuildDetailsResponse.class);
			buildDetailsResponse= (BuildDetailsResponse) EztracRestClient.invokeRestService(buildDetailsRequest, "http://localhost:8093/getBuildDetails", BuildDetailsResponse.class.getName());
		}
		catch (Exception e) {
			LoggerManager.writeErrorLog(CLASS_NAME, methodName, "BuildDetailsResponse Exception", e, "Service error");
			throw new Exception();
		}
		//System.out.println("BuildDetailsResponse : ========================"+buildDetailsResponse);
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return buildDetailsResponse;
	}

	@Override
	public BuildInsertResponse insertBuildDetails(BuildInsertRequest buildInsertRequest) throws Exception {
		final String methodName = "insertBuildDetails";
		BuildInsertResponse buildInsertResponse;
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
		try {
			buildInsertResponse = (BuildInsertResponse) EztracRestClient.invokeRestService(buildInsertRequest, "http://10.147.254.11:8080/build", BuildInsertResponse.class.getName());
		}
		catch (Exception e) {
			System.out.println("ServiceImpl - BuildInsert Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, methodName, "BuildInsertResponse Exception", e, "Service error");
			throw new Exception();
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return buildInsertResponse;
		
	}
	
}
