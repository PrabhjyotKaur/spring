package com.cg.eztrac.service.impl;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.SignInService;
import com.cg.eztrac.service.request.LoginInfoReq;
import com.cg.eztrac.service.response.LoginInfoRes;

public class SignInImpl implements SignInService {
	String classname =SignInImpl.class.getName();
	@Override
	public LoginInfoRes loginSignIn(LoginInfoReq loginInfoReq) throws Exception {
		String methodName = "loginSignIn";
		LoginInfoRes response = null;
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "Before calling rest service invocation");
		response = (LoginInfoRes) EztracRestClient.invokeRestService(loginInfoReq, "http://10.219.13.101:8091/login", LoginInfoRes.class.getName());
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After rest service invocation");
		return response;
	}
}
