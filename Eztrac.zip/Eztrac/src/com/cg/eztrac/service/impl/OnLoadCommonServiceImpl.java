package com.cg.eztrac.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.request.ParamDetailsRequest;
import com.cg.eztrac.service.request.RolePermissionRequest;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.ParamDetailsResponse;
import com.cg.eztrac.service.response.RolePermissionRes;
import com.cg.eztrac.service.response.SectionsRes;
import com.cg.eztrac.service.response.SystemDetailsResponse;

public class OnLoadCommonServiceImpl implements OnLoadCommonService {
	
	String className = OnLoadCommonServiceImpl.class.getSimpleName();
	
	@SuppressWarnings("unchecked")
    @Override
    public List<SystemDetailsResponse> getSystemDetails(SystemDetailsRequest systemDetailsRequest) {
		String methodName = "getSystemDetails";
		List<SystemDetailsResponse> systemDetailsListresponse = null;
		try {
			LoggerManager.writeInfoLog(className, methodName, ICommonConstants.SYSTEM_SERVICE_LOG_KEY + "call to restClient-getSystemDetails ", "(before)call made to restClient to get all getSystemDetails");
			systemDetailsListresponse = (List<SystemDetailsResponse>) EztracRestClient.invokeRestService(systemDetailsRequest, "http://10.219.13.101:8083/getAllSystemDetailsPost", List.class.getName());
			LoggerManager.writeInfoLog(className, methodName, ICommonConstants.SYSTEM_SERVICE_LOG_KEY + "call to restClient-getSystemDetails ", "(after)call made to restClient to get all getSystemDetails");
			if (null == systemDetailsListresponse) {
				LoggerManager.writeWaringLog(className, methodName, ICommonConstants.SYSTEM_SERVICE_LOG_KEY + "call to restClient-getSystemDetails ", null, "null response is received from restClient-getSystemDetails ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDetailsListresponse;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ParamDetailsResponse> getAllParamDetails(ParamDetailsRequest paramDetailsRequest) {
		String methodName = "getAllParamDetails";
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-ParamDetails ", "(before)calling  restClient to getAllParamDetails");
		List<ParamDetailsResponse> paramDetailsResponseList = new ArrayList<ParamDetailsResponse>();
		try {
			paramDetailsResponseList = (List<ParamDetailsResponse>) EztracRestClient.invokeRestService(paramDetailsRequest, "http://10.219.13.101:8083/getAllParamDetailsPost", List.class.getName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-ParamDetails ", "(after)call made to restClient to getAllParamDetails");
		if(null == paramDetailsResponseList){
			LoggerManager.writeWaringLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-getAllParamDetails ",null ,"null response is received from restClient-getAllParamDetails ");
		}
		return paramDetailsResponseList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public SectionsRes getAllSectionDetails(SectionDetailRequest sectionDetailRequest) {
		SectionsRes sectionDetailsResponse = null;
		String methodName="getAllSectionDetails";
		try {
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"call to restClient-SectionDetail ",ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+ "(before)calling  restClient to get all SectionDetail");
			sectionDetailsResponse = (SectionsRes) EztracRestClient.invokeRestService(sectionDetailRequest, "http://10.219.13.101:8084/getAllSectionDetailsPost", SectionsRes.class.getName());
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"call to restClient-SectionDetail ", ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+"(after)call made to restClient to get all SectionDetail");
			if(null == sectionDetailsResponse){
				LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"call to restClient-SectionDetail ",ICommonConstants.SECTION_DETAILS_SERVICES_FLOW+ "null response is received from restClient-SectionDetail ");
			}
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e ,ICommonConstants.APPLICATION_CONTEXT+ " exception while calling service of sectionDetails");
			throw new CustomException(ICommonConstants.SERVICE_UNAVAIL_ERROR_CD, ICommonConstants.SERVICE_UNAVAIL_ERROR_DESC);
		}
		return sectionDetailsResponse;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public RolePermissionRes getAllRolePermissionDetails(RolePermissionRequest rolePermissionRequest) {
		String methodName="getAllRolePermissionDetails";
		RolePermissionRes roleDetailsResponse = null;
		try {
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"call to restClient-rolePermission ",ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ "(before)calling  restClient to get all rolePermission");
			roleDetailsResponse = (RolePermissionRes) EztracRestClient.invokeRestService(rolePermissionRequest, "http://10.219.13.101:8084/getAllRolePermissionPost", RolePermissionRes.class.getName());
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"call to restClient-rolePermission ", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"(after)call made to restClient to get all rolePermission");
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e , " exception while calling service of roleDetails");
			throw new CustomException(ICommonConstants.SERVICE_UNAVAIL_ERROR_CD, ICommonConstants.SERVICE_UNAVAIL_ERROR_DESC);
		}
		if(null == roleDetailsResponse){
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"call to restClient-SectionDetail ", "null response is received from restClient-rolePermission  ");
		}
		return roleDetailsResponse;
	}

}
