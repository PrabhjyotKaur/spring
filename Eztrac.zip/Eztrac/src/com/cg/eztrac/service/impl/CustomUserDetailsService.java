package com.cg.eztrac.service.impl;

/*
 * @Author:Vamshi
 * 
 * UserDetailsService to produce customized SpringSecurityUser object with roles
 * 
 * */

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cg.eztrac.common.UserStatus;
import com.cg.eztrac.service.UserService;
import com.cg.eztrac.vo.RoleVO;
import com.cg.eztrac.vo.UserVO;

@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private UserService userService;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		UserVO user = userService.findByUserName(userName);

		// Creating Spring Security User object

		if (user != null) {

			org.springframework.security.core.userdetails.User secureUser = new org.springframework.security.core.userdetails.User(
					userName, user.getPassword(), user.getStatus().equals(UserStatus.ACTIVE),
					user.getStatus().equals(UserStatus.ACTIVE), user.getStatus().equals(UserStatus.ACTIVE),
					user.getStatus().equals(UserStatus.ACTIVE), buildUserAuthority(user));
			return secureUser;
		} else {
			throw new UsernameNotFoundException("User Not Found");
		}

	}

	private List<GrantedAuthority> buildUserAuthority(UserVO user) {
		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();

		// Getting User Role

		for (RoleVO userRole : user.getRoles()) {
			setAuths.add(new SimpleGrantedAuthority("ROLE_" + userRole.getRolename()));
		}

		List<GrantedAuthority> result = new ArrayList<GrantedAuthority>(setAuths);

		return result;
	}

}
