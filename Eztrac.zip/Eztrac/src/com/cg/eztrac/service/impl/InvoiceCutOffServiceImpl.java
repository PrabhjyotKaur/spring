package com.cg.eztrac.service.impl;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.InvoiceCutOffService;
import com.cg.eztrac.service.request.InvoiceCutOffRequest;
import com.cg.eztrac.service.response.InvoiceCutOffResponse;

public class InvoiceCutOffServiceImpl implements InvoiceCutOffService {
	String classname =SignInImpl.class.getName();

	@SuppressWarnings("unchecked")
	@Override
	public InvoiceCutOffResponse  invoiceService(InvoiceCutOffRequest invoiceCutOffRequest) throws Exception {
		String methodName = "invoiceService";
		InvoiceCutOffResponse response = null;
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "Before calling rest service invocation");
		response = (InvoiceCutOffResponse) EztracRestClient.invokeRestService(invoiceCutOffRequest, "http://10.219.13.101:8084/getInvoiceCutOff", InvoiceCutOffResponse.class.getName());
	//	System.out.println(response);
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After rest service invocation");
		return response;
	}


}
