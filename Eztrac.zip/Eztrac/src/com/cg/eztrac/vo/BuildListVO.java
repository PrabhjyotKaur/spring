package com.cg.eztrac.vo;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value="buildListVO")
public class BuildListVO extends EstimationListVO{
	
	private BuildVO buildVO;
	private List<BuildVO> buildVOList;
	
	public BuildVO getBuildVO() {
		return buildVO;
	}
	public void setBuildVO(BuildVO buildVO) {
		this.buildVO = buildVO;
	}
	public List<BuildVO> getBuildVOList() {
		return buildVOList;
	}
	public void setBuildVOList(List<BuildVO> buildVOList) {
		this.buildVOList = buildVOList;
	}
	@Override
	public String toString() {
		return "BuildListVO [buildVO=" + buildVO + ", buildVOList=" + buildVOList + "]";
	}
	
}