package com.cg.eztrac.vo;

import java.util.List;
import java.util.Map;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;

public class CommonVO  extends BaseVO{
	
	//DropdownMap
	private Map<String, List<ParamVO>> paramDetailsMap;
		
	//RoleRestrictionMatrixMap
	private Map<String, String> roleRestrictionMatrixMap;
	
	//RoleRestrictionMatrixPattern
	private String roleRestrictionMatrixPattern;
	
	//RoleRestrictionMatrixFlag
	private String roleRestrictionMatrixFlag;
	
	public Map<String, List<ParamVO>> getParamDetailsMap() {
		return CommonUtility.getParamDetailsMap();
	}

	public Map<String, String> getRoleRestrictionMatrixMap() {
		return CommonUtility.getRoleRestrictionMatrixMap();
	}
	
	public String getRoleRestrictionMatrixPattern() {
		return roleRestrictionMatrixPattern;
	}

	public void setRoleRestrictionMatrixPattern(String roleRestrictionMatrixPattern) {
		this.roleRestrictionMatrixPattern = roleRestrictionMatrixPattern;
	}

	public String getRoleRestrictionMatrixFlag(String fieldName) {
		return getRoleRestrictionMatrixMap().get(fieldName);
	}
	
	public List<ParamVO> getDropDownCurrentPhase() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_CURRENT_PHASE);
	}
	
	public List<ParamVO> getDropDownProjectType() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_PROJECT_TYPE);
	}
	
	public List<ParamVO> getDropDownHealthOfProject() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_HEALTH_OF_PROJECT);
	}
	public List<ParamVO> getDropDownLocationCode() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_LOCATION_CD);
	}
	public List<ParamVO> getDropDownSectionType() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_SECTION_TYPE);
	}
	public List<ParamVO> getDropDownSubSectionType() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_SUB_SECTION_TYPE);
	}
	public List<ParamVO> getDropDownCCCategoryId() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_CC_CATEGORY_ID);
	}
	public List<ParamVO> getDropDownCCCurrentPhase() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_CC_CURRENT_PHASE);
	}
	public List<ParamVO> getDropDownStakeHolderTypeId() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_STAKEHOLDER_TYPE_ID);
	}
	public List<ParamVO> getDropDownTaskId() {
		return getParamDetailsMap().get(ICommonConstants.DROPDOWN_TASK_ID);
	}
}
