package com.cg.eztrac.vo;

public class LoeVO {
	
	private Float planningLOEReq;
	private Float planningLOEDesign;
	private Float planningLOECons;
	private Float planningLOETest;
	private Float planningLOERelease;
	
	private Float executionLOEReq;
	private Float executionLOEDesign;
	private Float executionLOECons;
	private Float executionLOETest;
	private Float executionLOERelease;
	
	private Float actualDaysLOEReq;
	private Float actualDaysLOEDesign;
	private Float actualDaysLOECons;
	private Float actualDaysLOETest;
	private Float actualDaysLOERelease;
	
	private boolean sendLOEEmailFlag;

	public Float getPlanningLOEReq() {
		return planningLOEReq;
	}

	public void setPlanningLOEReq(Float planningLOEReq) {
		this.planningLOEReq = planningLOEReq;
	}

	public Float getPlanningLOEDesign() {
		return planningLOEDesign;
	}

	public void setPlanningLOEDesign(Float planningLOEDesign) {
		this.planningLOEDesign = planningLOEDesign;
	}

	public Float getPlanningLOECons() {
		return planningLOECons;
	}

	public void setPlanningLOECons(Float planningLOECons) {
		this.planningLOECons = planningLOECons;
	}

	public Float getPlanningLOETest() {
		return planningLOETest;
	}

	public void setPlanningLOETest(Float planningLOETest) {
		this.planningLOETest = planningLOETest;
	}

	public Float getPlanningLOERelease() {
		return planningLOERelease;
	}

	public void setPlanningLOERelease(Float planningLOERelease) {
		this.planningLOERelease = planningLOERelease;
	}

	public Float getExecutionLOEReq() {
		return executionLOEReq;
	}

	public void setExecutionLOEReq(Float executionLOEReq) {
		this.executionLOEReq = executionLOEReq;
	}

	public Float getExecutionLOEDesign() {
		return executionLOEDesign;
	}

	public void setExecutionLOEDesign(Float executionLOEDesign) {
		this.executionLOEDesign = executionLOEDesign;
	}

	public Float getExecutionLOECons() {
		return executionLOECons;
	}

	public void setExecutionLOECons(Float executionLOECons) {
		this.executionLOECons = executionLOECons;
	}

	public Float getExecutionLOETest() {
		return executionLOETest;
	}

	public void setExecutionLOETest(Float executionLOETest) {
		this.executionLOETest = executionLOETest;
	}

	public Float getExecutionLOERelease() {
		return executionLOERelease;
	}

	public void setExecutionLOERelease(Float executionLOERelease) {
		this.executionLOERelease = executionLOERelease;
	}

	public Float getActualDaysLOEReq() {
		return actualDaysLOEReq;
	}

	public void setActualDaysLOEReq(Float actualDaysLOEReq) {
		this.actualDaysLOEReq = actualDaysLOEReq;
	}

	public Float getActualDaysLOEDesign() {
		return actualDaysLOEDesign;
	}

	public void setActualDaysLOEDesign(Float actualDaysLOEDesign) {
		this.actualDaysLOEDesign = actualDaysLOEDesign;
	}

	public Float getActualDaysLOECons() {
		return actualDaysLOECons;
	}

	public void setActualDaysLOECons(Float actualDaysLOECons) {
		this.actualDaysLOECons = actualDaysLOECons;
	}

	public Float getActualDaysLOETest() {
		return actualDaysLOETest;
	}

	public void setActualDaysLOETest(Float actualDaysLOETest) {
		this.actualDaysLOETest = actualDaysLOETest;
	}

	public Float getActualDaysLOERelease() {
		return actualDaysLOERelease;
	}

	public void setActualDaysLOERelease(Float actualDaysLOERelease) {
		this.actualDaysLOERelease = actualDaysLOERelease;
	}

	public boolean isSendLOEEmailFlag() {
		return sendLOEEmailFlag;
	}

	public void setSendLOEEmailFlag(boolean sendLOEEmailFlag) {
		this.sendLOEEmailFlag = sendLOEEmailFlag;
	}

	@Override
	public String toString() {
		return "LoeVO [planningLOEReq=" + planningLOEReq + ", planningLOEDesign=" + planningLOEDesign
				+ ", planningLOECons=" + planningLOECons + ", planningLOETest=" + planningLOETest
				+ ", planningLOERelease=" + planningLOERelease + ", executionLOEReq=" + executionLOEReq
				+ ", executionLOEDesign=" + executionLOEDesign + ", executionLOECons=" + executionLOECons
				+ ", executionLOETest=" + executionLOETest + ", executionLOERelease=" + executionLOERelease
				+ ", actualDaysLOEReq=" + actualDaysLOEReq + ", actualDaysLOEDesign=" + actualDaysLOEDesign
				+ ", actualDaysLOECons=" + actualDaysLOECons + ", actualDaysLOETest=" + actualDaysLOETest
				+ ", actualDaysLOERelease=" + actualDaysLOERelease + ", sendLOEEmailFlag=" + sendLOEEmailFlag + "]";
	}

}
