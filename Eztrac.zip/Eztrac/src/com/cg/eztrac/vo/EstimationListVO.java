package com.cg.eztrac.vo;

import java.util.Map;

import org.springframework.stereotype.Component;

@Component(value="estimationListVO")
public class EstimationListVO {
	
	//Response Code and Description Map
	private Map<String,String> responseMap;

	public Map<String, String> getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map<String, String> responseMap) {
		this.responseMap = responseMap;
	}

	@Override
	public String toString() {
		return "EstimationListVO [responseMap=" + responseMap + "]";
	}

}
