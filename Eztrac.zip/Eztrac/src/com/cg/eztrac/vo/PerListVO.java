package com.cg.eztrac.vo;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value="perListVO")
public class PerListVO extends EstimationListVO{
	
	private PerVO perVO;
	private List<PerVO> perVOList;
	
	public PerVO getPerVO() {
		return perVO;
	}
	public void setPerVO(PerVO perVO) {
		this.perVO = perVO;
	}
	public List<PerVO> getPerVOList() {
		return perVOList;
	}
	public void setPerVOList(List<PerVO> perVOList) {
		this.perVOList = perVOList;
	}
	
	@Override
	public String toString() {
		return "PerListVO [perVO=" + perVO + ", perVOList=" + perVOList + "]";
	}
	
}
