package com.cg.eztrac.common;

import com.cg.eztrac.common.ICommonConstants;

public class CommonUtility {

	public static String formatMessage(String className, String methodName, String message,
			String additionalLogDetails) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append("class=");
		sb.append(className);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append("Method=");
		sb.append(methodName);
		if (additionalLogDetails != null) {
			sb.append(ICommonConstants.PIPE_SEPARATOR);
			sb.append(additionalLogDetails);

		}

		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(message);
		System.out.println(sb+"in common utility");
		return sb.toString();
	}

}
