package com.cg.eztrac.common;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletContext;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.eztrac.domain.RolePermissionDO;
import com.cg.eztrac.domain.SectionDetailDO;
import com.cg.eztrac.domain.SectionSubSectionDetailsDO;
import com.cg.eztrac.domain.SubSectionDO;
import com.cg.eztrac.vo.ParamVO;
import com.cg.eztrac.vo.SectionVO;
import com.cg.eztrac.vo.SubSectionVO;

public abstract class CommonUtility {
	
	private static final String CLASS_NAME = CommonUtility.class.getSimpleName();
	
	private static ServletContext servletContext;
	
	public static ServletContext getServletContext() {
		return servletContext;
	}
	
	public static void setServletContext(ServletContext servletContext) {
		CommonUtility.servletContext = servletContext;
	}
	
	public static DozerBeanMapper getDozerBeanMapper() {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		return (DozerBeanMapper) applicationContext.getBean("dozerBeanMapper");		
	}
	
	public static void copyBeanProperties(Object source, Object target) {
		getDozerBeanMapper().map(source, target);
	}

	final static String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	
	public static String formatMessage(String className, String methodName, String message,
			String additionalLogDetails) {
				StringBuffer sb = new StringBuffer();
				sb.append(ICommonConstants.PIPE_SEPARATOR);
				sb.append("class=");
				sb.append(className);
				sb.append(ICommonConstants.PIPE_SEPARATOR);
				sb.append("Method=");
				sb.append(methodName);
				if (additionalLogDetails != null) {
					sb.append(ICommonConstants.PIPE_SEPARATOR);
					sb.append(additionalLogDetails);
				}
				sb.append(ICommonConstants.PIPE_SEPARATOR);
				sb.append(message);
				return sb.toString();
			}
	
	public static String formatServiceMessage(String serviceURL, String tokenId, String beforeTimeStamp,
			String afterTimeStamp, String status) {
		StringBuffer sb = new StringBuffer();
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" SERVICE: ");
		sb.append(serviceURL);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - TOKENID: ");
		sb.append(tokenId);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - TIMESTAMP BEFORE CALLING SERVICE: ");
		sb.append(beforeTimeStamp);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - TIMESTAMP AFTER CALLING SERVICE: ");
		sb.append(afterTimeStamp);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - SERVICE RESPONSE STATUS: ");
		sb.append(status);
		return sb.toString();
	}
	
	//Token id generation
	public static String getTokenId() {
		String methodName="getTokenId";
		String className=CommonUtility.class.getSimpleName();
		int len=10;
		StringBuilder sb = new StringBuilder(len);
		SecureRandom rnd = new SecureRandom();
		try {
			rnd = SecureRandom.getInstance("SHA1PRNG");
			for (int i = 0; i < len; i++)
				sb.append(AB.charAt(rnd.nextInt(AB.length())));
		} catch (NoSuchAlgorithmException e) {
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while generating the token_id");
			sb =null;
		}
		return sb.toString();
	}
	
	public static Date getDateFromString(String dateString, String dateFormat) {
		try {
			return new SimpleDateFormat(dateFormat).parse(dateString);
		} catch (ParseException e) {
			return null;
		}
	}
	//Converting Date To String
		public static String getStringFromDate(Date date,String format){
			return new SimpleDateFormat(format).format(date);
		}

	@SuppressWarnings("unchecked")
	public static Map<Integer,Map<Integer, List<SectionVO>>> getUserMenuAccebiltiy(Object rolePermission,
			Object sectionDetails) {
		
		List<RolePermissionDO> contextRolePerDetails=(List<RolePermissionDO>)rolePermission;
		List<SectionDetailDO> contextSectionDetails=(List<SectionDetailDO>)sectionDetails;
		contextRolePerDetails = populateMenuRoleDetailsFromContext(contextRolePerDetails);
//		contextSectionDetails = populateMenuSectionDetailsFromContext(contextSectionDetails);
		String methodName="getUserMenuAccebiltiy ";
		Map<Integer,Map<Integer, List<SectionVO>>> menuRoleMap=new HashMap<Integer,Map<Integer, List<SectionVO>>>();
		Map<Integer, List<SectionVO>> menuMap=new TreeMap<Integer, List<SectionVO>>();
		Map <Integer, List<Integer>> singleRoleMap = new HashMap<Integer, List<Integer>>();
		
		try {
			for(RolePermissionDO rolePersmission:contextRolePerDetails){
				menuMap=new TreeMap<Integer, List<SectionVO>>();
				if(null != rolePersmission.getSections() && !rolePersmission.getSections().isEmpty()){
					for(SectionDetailDO scDO:rolePersmission.getSections()){
						ArrayList<Integer> roleSubSectionIDs =new ArrayList<Integer> ();
						for(SubSectionDO subSecVO: scDO.getSubSection()){
							roleSubSectionIDs.add(subSecVO.getSubSectionID());
						}
						Collections.sort(roleSubSectionIDs);
						singleRoleMap.put(scDO.getSectionID(),roleSubSectionIDs );
					}
				}
				List<SectionVO> sectionVOList=new ArrayList<SectionVO>();
				for(SectionDetailDO sectionDetail : contextSectionDetails){
					if(( sectionDetail.getSectionType() ) != 2){
						List<Integer> roleSubSections = singleRoleMap.get(sectionDetail.getSectionID());
						SectionVO sectionVO = new SectionVO();
						sectionVOList=new ArrayList<SectionVO>();
							sectionVO = new SectionVO();
							sectionVO.setSectionId(sectionDetail.getSectionID());
							sectionVO.setSectionName(sectionDetail.getSectionName());
							Map<Integer, String> subSectionMap = new TreeMap<Integer, String>();
							for(SubSectionDO subSection : sectionDetail.getSubSection()){
								subSectionMap.put(subSection.getSubSectionID(), subSection.getSubSectionName());
							}
							List<SubSectionVO> subSectionVOList=new ArrayList<SubSectionVO>();
							for(Integer subSectionID : subSectionMap.keySet()){
								SubSectionVO subSectionVO = new SubSectionVO();
								if(null != roleSubSections && !rolePersmission.getSections().isEmpty() && roleSubSections.contains(subSectionID)){
									subSectionVO.setElligbleFlag(false);
								}
								subSectionVO.setSubSectionId(subSectionID);
								subSectionVO.setSubSectionName(subSectionMap.get(subSectionID));
								subSectionVOList.add(subSectionVO);
							}
							sectionVO.getSubSectionVO().addAll(subSectionVOList);
							sectionVO.setSectionId(sectionDetail.getSectionID());
							sectionVO.setSectionName(sectionDetail.getSectionName());
						sectionVOList.add(sectionVO);
						menuMap.put(sectionVO.getSectionId(), sectionVOList);
					}
				}
				menuRoleMap.put(rolePersmission.getRoleId(), menuMap);
			}
		} catch (Exception e) {
			LoggerManager.writeErrorLog(CLASS_NAME,methodName,e.getMessage(), e,"exception while making the map for getUserMenuAccebiltiy");
			menuRoleMap = null;
		}
		return menuRoleMap;
	}
	
	private static List<RolePermissionDO> populateMenuRoleDetailsFromContext(List<RolePermissionDO> rolePermissionDOList){
		List<SectionSubSectionDetailsDO> sectionSubSectionDOList=new ArrayList<SectionSubSectionDetailsDO>();
		SubSectionDO subSectionDO;
		List<SubSectionDO> subSectionDOList;
		List<SectionDetailDO> sectionDetailDOList;
		List<RolePermissionDO> rolePermissionDOListNew=new ArrayList<RolePermissionDO>();
		RolePermissionDO RolePermissionDO;
		for(RolePermissionDO rolePermission : rolePermissionDOList){
			SectionDetailDO sectionDetailDO = null;
			RolePermissionDO=new RolePermissionDO();
			sectionDetailDOList = new ArrayList<SectionDetailDO>();
			subSectionDOList = new ArrayList<SubSectionDO>();
			int sectionID=0;
			sectionSubSectionDOList=rolePermission.getSubSections();
			for(SectionSubSectionDetailsDO sectionSubSection:sectionSubSectionDOList){
				if(sectionSubSection.getSectionType()!=2){
					subSectionDO = new SubSectionDO();
					if(sectionID==0 || sectionID!=sectionSubSection.getSectionID()){
						if(sectionDetailDO!=null ){
							sectionDetailDOList.add(sectionDetailDO);
						}
						sectionDetailDO=new SectionDetailDO();
						subSectionDOList = new ArrayList<SubSectionDO>();
						sectionDetailDO.setSectionID(sectionSubSection.getSectionID());
						sectionDetailDO.setSectionName(sectionSubSection.getSectionName());
						sectionDetailDO.setSectionType(sectionSubSection.getSectionType());
						subSectionDO.setSubSectionID(sectionSubSection.getSubSectionID());
						subSectionDO.setSubSectionName(sectionSubSection.getSubSectionName());
						subSectionDO.setSubSectionType(sectionSubSection.getSubSectionType());
						subSectionDOList.add(subSectionDO);
						sectionDetailDO.setSubSection(subSectionDOList);
					} else if(sectionID==sectionSubSection.getSectionID()){
						subSectionDO.setSubSectionID(sectionSubSection.getSubSectionID());
						subSectionDO.setSubSectionName(sectionSubSection.getSubSectionName());
						subSectionDO.setSubSectionType(sectionSubSection.getSubSectionType());
						subSectionDOList.add(subSectionDO);
						sectionDetailDO.setSubSection(subSectionDOList);
					}
					sectionID=sectionSubSection.getSectionID();
				}
			}
			if(null != sectionDetailDO){
				sectionDetailDOList.add(sectionDetailDO);
			}
			RolePermissionDO.setChannelId(rolePermission.getChannelId());
			RolePermissionDO.setResponseCode(rolePermission.getResponseCode());
			RolePermissionDO.setResponseDescription(rolePermission.getResponseDescription());
			RolePermissionDO.setRoleDesc(rolePermission.getRoleDesc());
			RolePermissionDO.setRoleId(rolePermission.getRoleId());
			RolePermissionDO.setRoleName(rolePermission.getRoleName());
			RolePermissionDO.setSections(sectionDetailDOList);
			RolePermissionDO.setTokenId(rolePermission.getTokenId());
			rolePermissionDOListNew.add(RolePermissionDO);
 		}
		return rolePermissionDOListNew;
	}
	
	
	
	/*private static List<RolePermissionDO> populateMenuRoleDetailsFromContext(List<RolePermissionDO> rolePermissionDOList){
		List<SectionSubSectionDetailsDO> sectionSubSectionDOList=new ArrayList<SectionSubSectionDetailsDO>();
		List<SubSectionDO> subSectionDOList;
		List<SectionDetailDO> sectionDetailDOList;
		List<RolePermissionDO> rolePermissionDOListNew=new ArrayList<RolePermissionDO>();
		RolePermissionDO rolePermissionDO;
		SectionDetailDO sectionDetailDO;
		SubSectionDO subSectionDO;
		for(RolePermissionDO rolePermission : rolePermissionDOList){
			rolePermissionDO=new RolePermissionDO();
			sectionDetailDOList = new ArrayList<SectionDetailDO>();
			subSectionDOList = new ArrayList<SubSectionDO>();
			int sectionID=0;
			sectionSubSectionDOList=rolePermission.getSubSections();
			for(SectionSubSectionDetailsDO sectionSubSection:sectionSubSectionDOList){
				if(sectionSubSection.getSectionType()!=2){
						sectionDetailDO=new SectionDetailDO();
						subSectionDO = new SubSectionDO();
						if(sectionID==0 || sectionID!=sectionSubSection.getSectionID()){
							subSectionDOList = new ArrayList<SubSectionDO>();
							sectionDetailDO.setSectionID(sectionSubSection.getSectionID());
							sectionDetailDO.setSectionName(sectionSubSection.getSectionName());
							sectionDetailDO.setSectionType(sectionSubSection.getSectionType());
							sectionDetailDOList.add(sectionDetailDO);
							sectionID=sectionSubSection.getSectionID();
						}
						subSectionDO.setSubSectionID(sectionSubSection.getSubSectionID());
						subSectionDO.setSubSectionName(sectionSubSection.getSubSectionName());
						subSectionDO.setSubSectionType(sectionSubSection.getSubSectionType());
						subSectionDOList.add(subSectionDO);
						sectionDetailDO.setSubSection(subSectionDOList);
				}	
			}
			rolePermissionDO.setChannelId(rolePermission.getChannelId());
			rolePermissionDO.setResponseCode(rolePermission.getResponseCode());
			rolePermissionDO.setResponseDescription(rolePermission.getResponseDescription());
			rolePermissionDO.setRoleDesc(rolePermission.getRoleDesc());
			rolePermissionDO.setRoleId(rolePermission.getRoleId());
			rolePermissionDO.setRoleName(rolePermission.getRoleName());
			rolePermissionDO.setSections(sectionDetailDOList);
			rolePermissionDO.setTokenId(rolePermission.getTokenId());
			rolePermissionDOListNew.add(rolePermissionDO);
 		}
		return rolePermissionDOListNew;
	}
	*/
	
	
	// Retrieve Dropdown data from Servlet Context
	public static Map<String, List<ParamVO>> getParamDetailsMap() {
		Map<String, List<ParamVO>> mapOfParamVOList = (Map<String, List<ParamVO>>) servletContext.getAttribute(ICommonConstants.ALL_PARAM_DETAILS_CONTEXT);
		return mapOfParamVOList;
	}
	
	// Form RoleRestrictionMatrix data
	public static void formRoleRestrictionMatrix(int roleId) {
		final String METHOD_NAME = "formRoleRestrictionMatrix";
		Map<String, String> roleRestrictionMatrixMap = new HashMap<String, String>();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleId  --->" + roleId, "");
		List<RolePermissionDO> rolePermissionDOList = (List<RolePermissionDO>) servletContext.getAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT);
		for(RolePermissionDO rolePermissionDO : rolePermissionDOList) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleId  --->" + roleId + "  rolePermissionDO.getRoleId()  --->" + rolePermissionDO.getRoleId(), "");
			if(roleId == rolePermissionDO.getRoleId()) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleId  --->" + roleId + "  rolePermissionDO.getRoleId()  --->" + rolePermissionDO.getRoleId() + " ROLE MATCHING --> FETCH ROLE NAME --> " + rolePermissionDO.getRoleName(), "");
				for(SectionSubSectionDetailsDO sectionSubSectionDetailsDO : rolePermissionDO.getSubSections()) {
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "  sectionSubSectionDetailsDO.getSectionID()   --->" + sectionSubSectionDetailsDO.getSectionID() + "" + " sectionSubSectionDetailsDO.getSectionName()   --->" + sectionSubSectionDetailsDO.getSectionName() + " sectionSubSectionDetailsDO.getSubSectionID()  --->" + sectionSubSectionDetailsDO.getSubSectionID() + " FETCH SUB-SECTION NAME --> " + sectionSubSectionDetailsDO.getSubSectionName(), "");
					// Form RoleMatrix for All Sections
					String sectionName = sectionSubSectionDetailsDO.getSectionName();
					String delimiter = ICommonConstants.RESTRICTION_PATTERN_DELIMITER;
					String subSectionName = sectionSubSectionDetailsDO.getSubSectionName();
					roleRestrictionMatrixMap.put(sectionName + delimiter + subSectionName, ICommonConstants.STRING_TRUE);
				}
			}
		}
		servletContext.setAttribute(ICommonConstants.ALL_ROLE_RESTRICTION_MATRIX_CONTEXT, roleRestrictionMatrixMap);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleRestrictionMatrixMap --->" + roleRestrictionMatrixMap, "");
	}
	
	// Retrieve RoleRestrictionMatrix data from Servlet Context
	public static Map<String, String> getRoleRestrictionMatrixMap() {
		Map<String, String> roleRestrictionMatrixMap = (Map<String, String>) servletContext.getAttribute(ICommonConstants.ALL_ROLE_RESTRICTION_MATRIX_CONTEXT);
		return roleRestrictionMatrixMap;
	}
	
}
