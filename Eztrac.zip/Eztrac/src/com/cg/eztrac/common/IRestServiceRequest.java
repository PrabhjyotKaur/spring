package com.cg.eztrac.common;
public interface IRestServiceRequest {

String getChannelId();
String getTokenId();
//void setTokenId(String tokenId);
}
