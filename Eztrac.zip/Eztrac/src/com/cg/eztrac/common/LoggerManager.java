package com.cg.eztrac.common;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class LoggerManager {

	private static final Logger log = LogManager.getLogger("LoggerManager");
	
	public static void writeDebugLog(final String className, final String methodName, final String message,
			final String additionalLogDetails) {
		if (log.isDebugEnabled()) {
			final String messageObject = CommonUtility.formatMessage(className, methodName, message,
					additionalLogDetails);
			log.info(messageObject);
		}

	}

	public static void writeDebugLog(final String className, final String methodName, final String message) {
		if (log.isDebugEnabled()) {
			final String messageObject = CommonUtility.formatMessage(className, methodName, message, null);
			log.info(messageObject);
		}

	}

	public static void writeInfoLog(final String className, final String methodName, final String message,
			final String additionalLogDetails) {
		System.out.println("in write info log ");
		if (log.isInfoEnabled()) {
			final String messageObject = CommonUtility.formatMessage(className, methodName, message,
					additionalLogDetails);
			System.out.println(messageObject);
			log.info(messageObject);
		}

	}

	public static void writeWaringLog(final String className, final String methodName, final String message,
			final Exception exceptionObj, final String additionalLogDetails) {
		final String messageObject = CommonUtility.formatMessage(className, methodName, message, additionalLogDetails);
		if (exceptionObj == null) {
			log.error(messageObject);
		} else {
			log.error(messageObject, exceptionObj);
		}

	}

	public static void writeErrorLog(final String className, final String methodName, final String message,
			final Exception exceptionObj, final String additionalLogDetails) {
		
		final String messageObject = CommonUtility.formatMessage(className, methodName, message, additionalLogDetails);
		if (exceptionObj == null) {
			log.error(messageObject);
		} else {
			log.error(messageObject, exceptionObj);
		}
	}

	public static void writeFatalLog(final String className, final String methodName, final String message,
			final Exception exceptionObj, final String additionalLogDetails) {
		final String messageObject = CommonUtility.formatMessage(className, methodName, message, additionalLogDetails);
		if (exceptionObj == null) {
			log.error(messageObject);
		} else {
			log.error(messageObject, exceptionObj);
		}
	}
}
