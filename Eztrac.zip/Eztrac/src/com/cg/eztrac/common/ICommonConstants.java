package com.cg.eztrac.common;

public interface ICommonConstants {
	
	String PIPE_SEPARATOR="|";
	
	String loginService = "loginWS_URL"; 

}
