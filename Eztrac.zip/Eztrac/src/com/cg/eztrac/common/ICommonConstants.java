package com.cg.eztrac.common;

public interface ICommonConstants {

	public static final String STRING_TRUE = "true";
	public static final String STRING_FALSE = "false";
	
	//TODO - It is supposed to be coming as 2 for sectionType
	public static final String STRING_TWO = "2.0";
	
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	
	public static final String PIPE_SEPARATOR = "|";
	
	public static final String loginService = "loginWS_URL";
	public static final String USERDETAILS = "UserDetails";
	public static final String LOGIN = "login";
	public static final String ROLEPERMISSION = "RolePermission";
	public static final String ALL_SUB_SEC_DETAILS_STR = "AllSubSectionDetails";
	public static final String ALL_SEC_DETAILS_STR = "allSectionDetails";
	public static final String ALL_PARAM_DETAILS_CONTEXT = "ALL_PARAM_DETAILS_SERVICE";
	public static final String ALL_SEC_DETAILS_CONTEXT = "ALL_SEC_DETAILS_SERVICE";
	public static final String ALL_ROLE_DETAILS_CONTEXT = "ALL_ROLE_DETAILS_SERVICE";
	public static final String ALL_ROLE_RESTRICTION_MATRIX_CONTEXT = "ALL_ROLE_RESTRICTION_MATRIX";
	public static final String All_ROLE_MENU_ACCESS_CONTEXT = "All_ROLE_MENU_ACCESSIBILITY";
	public static final String USER_DETAILS="USER_DETAILS";
	public static final String INVOICELIST="INVOICE_LIST";
	
	
	public static final String DISABLE_STR = "DISABLE";
	public static final String ENABLE_STR = "ENABLE";
	
	public static final String App = " - LOGINFLOW - ";
	public static final String sec = " - LOGINFLOW - ";
	public static final String role = " - LOGINFLOW - ";
	
	public static final String LOGIN_SERVICE_LOG_KEY = " - LOGINFLOW - ";
	public static final String BUILD_SERVICE_LOG_KEY = "BUILDFLOW";
	public static final String PER_SERVICE_LOG_KEY = "PERFLOW";
	public static final String SPRING_FILTER_LOG_KEY = " - AUTHFILTER FLOW -  ";
	public static final String AUTHORITIES_OBJS = "AUTHORITIES_OBJECT";
	public static final String APPLICATION_CONTEXT = " - APPLICATIONCONTEXT - ";
	public static final String SECTION_DETAILS_SERVICES_FLOW = " - SECTION_DETAILS_SERVICES - ";
	public static final String ROLE_PERMISSION_SERVICES_FLOW = " - ROLE_PERMISSION_SERVICES - ";
	
	public static final String MODULE_PER = "Per";
	public static final String SUB_MODULE_NEW = "New";
	public static final String SUB_MODULE_EDIT = "Edit";
	public static final String SUB_MODULE_CC_EDIT = "CCEdit";
	public static final String MODULE_BUILD = "Build";
	public static final String RESTRICTION_PATTERN_DELIMITER = "~";
	public static final String PER_NEW_RESTRICTION_PATTERN = MODULE_PER + PIPE_SEPARATOR + SUB_MODULE_NEW + RESTRICTION_PATTERN_DELIMITER;
	public static final String PER_EDIT_RESTRICTION_PATTERN = MODULE_PER + PIPE_SEPARATOR + SUB_MODULE_EDIT + RESTRICTION_PATTERN_DELIMITER;
	public static final String PER_CCEDIT_RESTRICTION_PATTERN = MODULE_PER + PIPE_SEPARATOR + SUB_MODULE_CC_EDIT + RESTRICTION_PATTERN_DELIMITER;
	public static final String BUILD_NEW_RESTRICTION_PATTERN = MODULE_BUILD + PIPE_SEPARATOR + SUB_MODULE_NEW + RESTRICTION_PATTERN_DELIMITER;
	public static final String BUILD_EDIT_RESTRICTION_PATTERN = MODULE_BUILD + PIPE_SEPARATOR + SUB_MODULE_EDIT + RESTRICTION_PATTERN_DELIMITER;
	public static final String BUILD_CCEDIT_RESTRICTION_PATTERN = MODULE_BUILD + PIPE_SEPARATOR + SUB_MODULE_CC_EDIT + RESTRICTION_PATTERN_DELIMITER;
	
	public static final String TOKEN_ID_STR = "TOKEN_ID";
	public static final String PERMISSIABLE_ROLEID_SESSION = "ROLEPERMISSION_USER_ROLES";
	public static final int SUB_ACCOUN_ID = 1;
	public static final String SERVICE_UNAVAIL_ERROR_DESC = "SYSTEM DOWN. PLEASE TRY AFTER SOMETIME";
	public static final String SERVICE_UNAVAIL_ERROR_CD = "111";
	
	public static final String DROPDOWN_CURRENT_PHASE = "CURRENT_PHASE";
	public static final String DROPDOWN_PROJECT_TYPE = "PROJECT_TYPE";
	public static final String DROPDOWN_HEALTH_OF_PROJECT = "HEALTH_OF_PROJECT";
	public static final String DROPDOWN_LOCATION_CD = "LOCATION_CD";
	public static final String DROPDOWN_SUB_SECTION_TYPE = "SUB_SECTION_TYPE";
	public static final String DROPDOWN_SECTION_TYPE = "SECTION_TYPE";
	public static final String DROPDOWN_CC_CATEGORY_ID = "CC_CATEGORY_ID";
	public static final String DROPDOWN_CC_CURRENT_PHASE = "CC_CURRENT_PHASE";
	public static final String DROPDOWN_STAKEHOLDER_TYPE_ID = "STAKEHOLDER_TYPE_ID";
	public static final String DROPDOWN_TASK_ID = "TASK_ID";
	
	public static final String BUILD_INSERT_RESPONSE = "BuildInsertResponse";
	
	public static final Integer ADMIN_ROLE_ID = 1;
	public static final Integer PMO_ROLE_ID = 2;
	public static final Integer PM_ROLE_ID = 3;
	public static final Integer PL_ROLE_ID = 4;
	public static final Integer TM_ROLE_ID = 5;
	public static final Integer SYFITPM_ROLE_ID = 6;
	
	public static final String EMPTY_URL_STRING = "";
	
	public static final String ADMIN_ROLE_NAME = "hasRole('Admin')";
	public static final String PMO_ROLE_NAME = "hasRole('PMO')";
	public static final String PM_ROLE_NAME = "hasRole('PM')";
	public static final String PL_ROLE_NAME = "hasRole('PL')";
	public static final String TM_ROLE_NAME = "hasRole('TM')";
	public static final String SYFITPM_ROLE_NAME = "hasRole('SYFITPM')";

	public static final String SUCCESS_LOGIN_RESPONSE_CODE = "100";
	public static final String OR_STRING_WITH_SPACE_BEFORE_AFTER = " or ";
	public static final String ROLE_STRING = "ROLE_";
	public static final String ADMIN_STRING = "ADMIN";
	public static final String PMO_STRING = "PMO";
	public static final String PM_STRING = "PM";
	public static final String PL_STRING = "PL";
	public static final String TM_STRING = "TM";
	public static final String SYFITPM_STRING = "SYFITPM";
	public static final String Y_STRING = "Y";
	
	public static final String SYSTEM_SUBSYSTEM_DETAILS_CONTEXT = "SYSTEM_SUBSYSTEM_DETAILS";
	public static final String SYSTEM_SERVICE_LOG_KEY = " - SYSTEM_SERVICE_FLOW - ";
	public static final String SYSTEM_SERVICE = "systemWS_url";
	public static final String TIME_SHEET_SERVICE = "systemWS_url";
	public static final String TIMESHEET_TYPE_SAVE = "save";
	public static final String TIMESHEET_TYPE_SUBMIT = "submit";

}
