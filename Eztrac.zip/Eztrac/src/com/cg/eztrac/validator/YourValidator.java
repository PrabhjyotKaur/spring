package com.cg.eztrac.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;


public class YourValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return false;
		// TODO Auto-generated method stub
		//return YourDao.class.isAssignableFrom(arg0);
	}
   // Using Built in Validator
	@Override
	public void validate(Object e, Errors result) {
		
		
		ValidationUtils.rejectIfEmptyOrWhitespace(result, "empName", null, "Employee Name  should not be empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(result, "empId", null, "Emp ID   should not be empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(result, "empDesignation", null, "empDesignation  should not be empty");
		
		
	}
// Use Custom methods for Validating
	/*	@Override
	public void validate(Object student, Errors result) {
		// TODO Auto-generated method stub
		
		Student stud = (Student) student;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(result, "studName", null, "Student name should not be empty");
		
		if(stud.getStudId().isEmpty())
		{
			result.rejectValue("studId",null, "Student ID cannot be empty");
		}
		else if (stud.getStudId().matches("st\\d{1,3}")==false)
		{
			result.rejectValue("studId",null, "Please enter valid Student ID Eg: st12");
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(result, "subject", null, "subject name should not be empty");
		
		if(stud.getScore()<0)
		{
			//result.rejectValue("score", "Negative score not allowed");
			result.rejectValue("score",null, "Negative score not allowed");
		}
		else if (stud.getScore()>100) {
			//result.rejectValue("score","Score cannot exceed 100");
			result.rejectValue("score",null, "Score cannot exceed 100");
		}
	}
*/
	
	/* 
	 * 
	 * */
}
