package com.cg.eztrac.validator;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.PerVO;

@Component(value="perValidator")
public class PerValidator implements Validator {
	
	private static final String CLASS_NAME = "PerValidator";
	
	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public void validate(Object perObj, Errors errors) {
		String methodName = "validate";
		
		PerVO perVo = (PerVO)perObj;
		
		//perNumber
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perNumber", "error.per.perNumber.required");
		
		//currentPhase
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "currentPhaseName", "error.per.currentPhaseName.required");
		
		//perDescription
		if(StringUtils.isEmpty(perVo.getPerDescription())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perDescription", "error.per.perDescription.required");
		} else {
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "perDescription", "error.per.perDescription.minMaxLength", perVo.getPerDescription().length(), 10, 200);
		}
		
		//perReceiptDateString
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perReceiptDateString", "error.per.perReceiptDateString.required");
		
		//parNumber
		if(!StringUtils.isEmpty(perVo.getParNumber())) {
			//EztracValidationUtil.rejectIfLengthMismatch(errors, "parNumber", "error.per.parNumber.length", perVo.getParNumber().length(), 10);
			EztracValidationUtil.rejectIfPatternMismatch(errors, "parNumber", "error.per.parNumber.pattenMismatch", perVo.getParNumber(), "^[A-Z]{4}[0-9]{4}$");
		}
		
		//scheduleCallDateString and cancellationDateString
		if(!StringUtils.isEmpty(perVo.getScheduleCallDate()) && !StringUtils.isEmpty(perVo.getCancellationDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "cancellationDateString", "error.per.cancellationDateString.invalid", perVo.getScheduleCallDate(), perVo.getCancellationDate());
		} else if(StringUtils.isEmpty(perVo.getScheduleCallDate()) && !StringUtils.isEmpty(perVo.getCancellationDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "scheduleCallDateString", "error.per.scheduleCallDateString.required");
		}
		
		//currentScheduleStartDateString and currentScheduleEndDateString
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleStartDate()) && !StringUtils.isEmpty(perVo.getCurrentScheduleEndDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "currentScheduleEndDateString", "error.per.currentScheduleEndDateString.invalid", perVo.getCurrentScheduleStartDate(), perVo.getCurrentScheduleEndDate());
		} else if(StringUtils.isEmpty(perVo.getCurrentScheduleStartDate()) && !StringUtils.isEmpty(perVo.getCurrentScheduleEndDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "currentScheduleStartDateString", "error.per.currentScheduleStartDateString.required");
		}
		
		//stopDateString and restartDateString
		if(!StringUtils.isEmpty(perVo.getStopDate()) && !StringUtils.isEmpty(perVo.getRestartDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "restartDateString", "error.per.restartDateString.invalid", perVo.getStopDate(), perVo.getRestartDate());
		} else if(StringUtils.isEmpty(perVo.getStopDate()) && !StringUtils.isEmpty(perVo.getRestartDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "stopDateString", "error.per.stopDateString.required");
		}
		
		//SceduleStartDAte and ScheduleCallDate
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleStartDate()) && !StringUtils.isEmpty(perVo.getScheduleCallDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "currentScheduleStartDateString", "error.per.scheduleStartDateString.invalid", perVo.getScheduleCallDate(), perVo.getCurrentScheduleStartDate());
		} else if(StringUtils.isEmpty(perVo.getScheduleCallDate()) && !StringUtils.isEmpty(perVo.getCurrentScheduleStartDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "scheduleCallDateString", "error.per.scheduleCallDateString.required");
		}
		
		//Phase Timelines
		//actualReqStartDateString and actualReqEndDateString
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqEndDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "phaseTimelinesVO.actualReqEndDateString", "error.per.actualRequirementEndDate.invalid", perVo.getPhaseTimelines().getActualReqStartDate(), perVo.getPhaseTimelines().getActualReqEndDate());
		} else if(StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqEndDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "phaseTimelinesVO.actualReqStartDateString", "error.per.actualRequirementStartDate.required");
		}
		
		//ActualDesignValidation
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignEndDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "phaseTimelinesVO.actualDesignEndDateString", "error.per.actualDesignEndDate.invalid", perVo.getPhaseTimelines().getActualDesignStartDate(), perVo.getPhaseTimelines().getActualDesignEndDate());
		} else if(StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignEndDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "phaseTimelinesVO.actualDesignStartDateString", "error.per.actualDesignStartDate.required");
		}
		
		//ActualDesignValidation
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConEndDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "phaseTimelinesVO.actualConEndDateString", "error.per.actualConstructionEndDate.invalid", perVo.getPhaseTimelines().getActualConStartDate(), perVo.getPhaseTimelines().getActualConEndDate());
		} else if(StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConEndDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "phaseTimelinesVO.actualConStartDateString", "error.per.actualConstructionStartDate.required");
		}
		//ActualDesignValidation
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingEndDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "phaseTimelinesVO.actualTestingEndDateString", "error.per.actualTestingEndDate.invalid", perVo.getPhaseTimelines().getActualTestingStartDate(), perVo.getPhaseTimelines().getActualTestingEndDate());
		} else if(StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingEndDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "phaseTimelinesVO.actualTestingStartDateString", "error.per.actualTestingStartDate.required");
		}
		
		//ActualDesignValidation
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseEndDate())) {
			EztracValidationUtil.rejectIfDateComparisonFails(errors, "phaseTimelinesVO.actualReleaseEndDateString", "error.per.actualReleaseEndDate.invalid", perVo.getPhaseTimelines().getActualReleaseStartDate(), perVo.getPhaseTimelines().getActualReleaseEndDate());
		} else if(StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseStartDate()) && !StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseEndDate())) {
			EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "phaseTimelinesVO.actualReleaseStartDateString", "error.per.actualReleaseStartDate.required");
		}
		
	}
}
