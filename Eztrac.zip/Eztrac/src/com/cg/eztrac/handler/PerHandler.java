package com.cg.eztrac.handler;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.vo.PerListVO;
import com.cg.eztrac.vo.PerVO;

@Component(value="perHandler")
public class PerHandler {
	
	private static final String CLASS_NAME = PerHandler.class.getSimpleName();
	
	private static final String DATE_FORMAT_YYYY_MM_DD = ICommonConstants.DATE_FORMAT_YYYY_MM_DD;
	
	@Autowired
	PerDO perDO;
	
	public void convertStringToDateFields(PerVO perVo) {
		
		String METHOD_NAME = "convertStringToDateFields";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerController.perList:", perVo.toString());
		
		if(!StringUtils.isEmpty(perVo.getPerReceiptDateString())) {
			perVo.setPerReceiptDate(getDateFromString(perVo.getPerReceiptDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getScheduleCallDateString())) {
			perVo.setScheduleCallDate(getDateFromString(perVo.getScheduleCallDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCancellationDateString())) {
			perVo.setCancellationDate(getDateFromString(perVo.getCancellationDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleStartDateString())) {
			perVo.setCurrentScheduleStartDate(getDateFromString(perVo.getCurrentScheduleStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleEndDateString())) {
			perVo.setCurrentScheduleEndDate(getDateFromString(perVo.getCurrentScheduleEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getStopDateString())) {
			perVo.setStopDate(getDateFromString(perVo.getStopDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getRestartDateString())) {
			perVo.setRestartDate(getDateFromString(perVo.getRestartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqStartDateString())) {
			perVo.getPhaseTimelines().setActualReqStartDate(getDateFromString(perVo.getPhaseTimelines().getActualReqStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReqEndDateString())) {
			perVo.getPhaseTimelines().setActualReqEndDate(getDateFromString(perVo.getPhaseTimelines().getActualReqEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignStartDateString())) {
			perVo.getPhaseTimelines().setActualDesignStartDate(getDateFromString(perVo.getPhaseTimelines().getActualDesignStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualDesignEndDateString())) {
			perVo.getPhaseTimelines().setActualDesignEndDate(getDateFromString(perVo.getPhaseTimelines().getActualDesignEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConStartDateString())) {
			perVo.getPhaseTimelines().setActualConStartDate(getDateFromString(perVo.getPhaseTimelines().getActualConStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualConEndDateString())) {
			perVo.getPhaseTimelines().setActualConEndDate(getDateFromString(perVo.getPhaseTimelines().getActualConEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingStartDateString())) {
			perVo.getPhaseTimelines().setActualTestingStartDate(getDateFromString(perVo.getPhaseTimelines().getActualTestingStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualTestingEndDateString())) {
			perVo.getPhaseTimelines().setActualTestingEndDate(getDateFromString(perVo.getPhaseTimelines().getActualTestingEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseStartDateString())) {
			perVo.getPhaseTimelines().setActualReleaseStartDate(getDateFromString(perVo.getPhaseTimelines().getActualReleaseStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getPhaseTimelines().getActualReleaseEndDateString())) {
			perVo.getPhaseTimelines().setActualReleaseEndDate(getDateFromString(perVo.getPhaseTimelines().getActualReleaseEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
	}
	
	private Date getDateFromString(String dateString, String dateFormat) {
		return CommonUtility.getDateFromString(dateString, dateFormat);
	}
	
	private void convertDateToStringFields(PerVO perVO) {
		if(null != perVO.getPerReceiptDate()) {
			perVO.setPerReceiptDateString(getStringFromDate(perVO.getPerReceiptDate(), DATE_FORMAT_YYYY_MM_DD));
		}
	}
	
	private String getStringFromDate(Date date,String format) {
		return CommonUtility.getStringFromDate(date, format);
	}

	public void getPerList(PerListVO perListVO, HttpSession httpSession) throws Exception {
		
		final String METHOD_NAME = "getPerList";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerList:", perListVO.getPerVO().toString());
		
		// Dozer Copy Bean Properties from Model Object to Domain Object
		CommonUtility.copyBeanProperties(perListVO.getPerVO(), perDO);
		
		//TODO
		//getting current roleDO of User
		RoleDO roleDO = null;
		if(null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)){
			UserDO userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
			List<RoleDO> roleDOList = userDO.getRoles();
			roleDO = roleDOList.get(0);
		}
		
		try {
			roleDO.getPerList(perDO, httpSession);
		} catch(Exception e){
			throw new Exception();
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerList::::::::", perListVO.getPerVO().toString());
		List<PerVO> perVOList = new ArrayList<PerVO>();
		if(null != httpSession.getAttribute("perListDO")) {
			List<PerDO> perDOList = (List<PerDO>) httpSession.getAttribute("perListDO");
			
			// Dozer Copy Bean Properties from Model Object to Domain Object
			CommonUtility.copyBeanProperties(perDOList, perVOList);
		}
		perListVO.setPerVOList(perVOList);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerList::", perListVO.toString());
	}
	
	public void insertPerDetails(PerVO perVO) throws Exception {
		final String METHOD_NAME = "insertPerDetails";
		
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.insertPerDetails:", perDO.toString());
		
		perDO.insertPerDetails(perDO);
	}
	
	public PerVO getPerDetails(int perId,HttpSession httpSession) throws Exception {
		final String METHOD_NAME = "getPerDetails";
		//CommonUtility.copyBeanProperties(perVO, perDO);
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerDetails:", perId+"");
		try{
			perDO.getPerDetails(perId,httpSession);
		}catch(Exception e){
			throw new Exception();
		}
		
		if(null!=httpSession.getAttribute("perDetails")){
			perDO = (PerDO) httpSession.getAttribute("perDetails");
		}
		PerVO perVO = new PerVO();
		CommonUtility.copyBeanProperties(perDO, perVO);
		convertDateToStringFields(perVO);
		return perVO;
	}
	
	//TODO
	public void insertPerCCDetails(PerVO perVO){
		final String METHOD_NAME = "insertChangeControl";
		//TODO
		//Is this Correct
		CommonUtility.copyBeanProperties(perVO,perDO);
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.insertPerDetails:", perDO.toString());
		perDO.insertPerCCDetails(perDO);
	}
}
