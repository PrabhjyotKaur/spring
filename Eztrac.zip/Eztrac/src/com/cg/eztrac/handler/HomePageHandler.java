package com.cg.eztrac.handler;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.domain.InvoiceDO;
import com.cg.eztrac.domain.MenuDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.vo.InvoiceVO;
import com.cg.eztrac.vo.MenuVO;
import com.cg.eztrac.vo.SectionVO;
import com.google.gson.Gson;

public class HomePageHandler {

	public InvoiceVO switchRoleMenuHandler(HttpSession httpSession, MenuVO menuVO, ServletContextImpl servletContextImpl) {
		int roleId=menuVO.getRoleId();
		MenuDO menuDO = new MenuDO();
		Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = (Map<Integer, Map<Integer, List<SectionVO>>>) servletContextImpl.getObjectFromServletContext(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT);
		Map<Integer, List<SectionVO>> menuBasedOnRole = allRoleMenuAccebiltiy.get(roleId);
		UserDO userDO=(UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
		String menuMapJson = new Gson().toJson(menuBasedOnRole);
		menuDO.setCustomizeJsonMap(menuMapJson);
		menuDO.setSwitchRoles(userDO.getMenuDO().getSwitchRoles());
		userDO.setMenuDO(menuDO);
		List<InvoiceDO> invoiceDOList=(List<InvoiceDO>)httpSession.getAttribute(ICommonConstants.INVOICELIST);
		menuBasedOnRole = null;
		InvoiceDO invoiceDO=new InvoiceDO();
		InvoiceVO invoiceVO=new InvoiceVO(); 
		for (int i=0;i<invoiceDOList.size();i++){
			invoiceDO=invoiceDOList.get(i);
			invoiceVO.setInvoiceMonth(invoiceDO.getInvoiceMonth());
			invoiceVO.setInvoiceDt(invoiceDO.getInvoiceDt());
			invoiceVO.setInvoiceYear(invoiceDO.getInvoiceYear());
		}
		return invoiceVO;
	}
	
}
