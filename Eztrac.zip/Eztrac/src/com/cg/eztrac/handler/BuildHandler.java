package com.cg.eztrac.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.BuildDO;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.vo.BuildListVO;
import com.cg.eztrac.vo.BuildVO;

@Component(value="buildHandler")
public class BuildHandler {
	
	private static final String CLASS_NAME = BuildHandler.class.getSimpleName();
	
	@Autowired
	BuildDO buildDO;
	
	@Autowired
	PerDO perDO;
	
	public void getBuildList(BuildListVO buildListVO, HttpSession httpSession) throws Exception {

		final String METHOD_NAME = "getBuildList";
		BuildDO buildDO = new BuildDO();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.getBuildList:", buildListVO.getBuildVO().toString());
		
		CommonUtility.copyBeanProperties(buildListVO.getBuildVO(), buildDO);
		
		try {
			perDO.getBuildList(buildDO, httpSession);
		}
		catch (Exception e) {
			System.out.println("BuildHandler-buildlist catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildListResponse Exception", e, "");
			throw new Exception();
		}
		
		List<BuildVO> buildVOList = new ArrayList<BuildVO>();
		if(null != httpSession.getAttribute("buildListDO")) {
			List<BuildDO> buildDOList = (List<BuildDO>) httpSession.getAttribute("buildListDO");
			// Dozer Copy Bean Properties from Model Object to Domain Object
			CommonUtility.copyBeanProperties(buildDOList, buildVOList);
		}
		buildListVO.setBuildVOList(buildVOList);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "BuildHandler.getBuildList::", buildListVO.toString());
	}

	public void getBuildDetails(BuildVO buildVO, HttpSession httpSession) throws Exception {
		
		final String METHOD_NAME = "getBuildDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.getBuildDetails:", buildVO.toString());
		
		CommonUtility.copyBeanProperties(buildVO, buildDO);
		
		try {
			buildDO.getBuildDetails(buildDO, httpSession);
		}
		catch (Exception e) {
			System.out.println("BuildHandler - builddetails catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildDetailsResponse Exception", e, "");
			throw new Exception();
		}
		if(null != httpSession.getAttribute("buildDODetails")) {
			BuildDO buildDODetails = (BuildDO) httpSession.getAttribute("buildDODetails");
			System.out.println("before copying");
			CommonUtility.copyBeanProperties(buildDODetails, buildVO);
			System.out.println("After copying");
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "BuildHandler.getBuildDetails::", buildVO.toString());
	}
	
	public void insertBuildDetails(BuildVO buildVO, HttpSession httpSession) throws Exception {
		final String METHOD_NAME = "insertBuildDetails";
		BuildDO buildDO = new BuildDO();
		CommonUtility.copyBeanProperties(buildVO, buildDO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.buildSubmit:", buildDO.toString());
		
		try {
			buildDO.insertBuildDetails(buildDO,httpSession);
		}
		catch (Exception e) {
			System.out.println("BuildHandler - insertBuildDetails Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildInsertResponse Exception", e, "");
			throw new Exception();
		}
		buildDO = (BuildDO) httpSession.getAttribute(ICommonConstants.BUILD_INSERT_RESPONSE);
		CommonUtility.copyBeanProperties(buildDO, buildVO);
		
	}
	
}
