package com.cg.eztrac.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.exception.CustomException;
//import com.cg.eztrac.exception.PerListNotFoundException;
import com.cg.eztrac.handler.PerHandler;
import com.cg.eztrac.validator.PerValidator;
import com.cg.eztrac.vo.PerListVO;
import com.cg.eztrac.vo.PerVO;

@Controller
@PropertySource("classpath:appurlcontroller.properties")
public class PerController {
	
	private static final String CLASS_NAME = "PerController";
	
	@Autowired
	HttpSession httpSession;
	
	@Autowired
	PerValidator perValidator;
	
	@Autowired
	PerHandler perHandler;
	
	@Autowired
	PerListVO perListVO;
	
	@Autowired
	ServletContextImpl servletContextImpl;
	
	@RequestMapping(value = "${eztrack.postlogin.per.new.url}", method = RequestMethod.POST)
	public ModelAndView perNew() throws Exception {
		final String METHOD_NAME = "perNew";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, METHOD_NAME, METHOD_NAME);
		
		PerVO perVo = new PerVO();
		
		// Role Restriction Matrix
		// Set Role Restriction Matrix Pattern based on operation for Field Restriction Purpose
		perVo.setRoleRestrictionMatrixPattern(ICommonConstants.PER_NEW_RESTRICTION_PATTERN);
		
		ModelAndView mav = new ModelAndView("per");
		mav.addObject("perVo", perVo);
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.per.submit.url}", method = RequestMethod.POST)
	public ModelAndView perSubmit(@ModelAttribute("perVo") @Valid PerVO perVo, BindingResult result) throws Exception {
		final String METHOD_NAME = "perSubmit";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, METHOD_NAME, METHOD_NAME);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, perVo.toString(), "Inside PerController.perSubmit:");
		
		//Invoke Validator for convertStringToDateFields
		perHandler.convertStringToDateFields(perVo);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, perVo.toString(), "Inside PerController.perSubmit::");
		
		//Invoke Validator for Server Side Validations
		perValidator.validate(perVo, result);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, result.hasErrors()+"", "Inside PerController.perSubmit:::");
		
		ModelAndView mav = new ModelAndView("per");
		
		if(!result.hasErrors()) {
			//Invoke Handler
			perHandler.insertPerDetails(perVo);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerController.perSubmit:", "");
			
			mav.addObject("perVo", perVo);
		} else {
			mav.addObject("perVo", perVo);
		}
		
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.per.edit.url}", method = RequestMethod.POST)
	public ModelAndView perEdit(@ModelAttribute("perListVO") PerListVO perListVO) throws Exception {
		PerVO perVO = new PerVO();
		String METHOD_NAME = "perEdit";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, METHOD_NAME, METHOD_NAME);
		// Role Restriction Matrix Starts
		// Set Role Restriction Matrix Pattern based on operation for Field Restriction Purpose
		perVO.setRoleRestrictionMatrixPattern(ICommonConstants.PER_NEW_RESTRICTION_PATTERN);
		perListVO.setPerVO(perVO);
		ModelAndView mav = new ModelAndView("perList");
		return mav;
	}
	@RequestMapping(value = "${eztrack.postlogin.per.perList.url}", method = RequestMethod.POST)
	public ModelAndView perList(@ModelAttribute("perListVO") @Valid PerListVO perListVO, BindingResult result) throws Exception {
		final String METHOD_NAME = "perList";
		
		PerVO perVO = perListVO.getPerVO();
		perListVO.setPerVO(perVO);
		
		ModelAndView mav = new ModelAndView("perList");
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Befoer Calling PerHandler", METHOD_NAME);
		// TODO
		try {
			perHandler.getPerList(perListVO, httpSession);
		} catch(Exception e) {
			throw new CustomException(ICommonConstants.SERVICE_UNAVAIL_ERROR_CD, ICommonConstants.SERVICE_UNAVAIL_ERROR_DESC);
		}
		//Setting Response code and description
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After Calling PerHandler", METHOD_NAME);
		Map<String, String> responseMap=new HashMap<String, String>();
		responseMap=(Map<String, String>) httpSession.getAttribute("responseMap");
		perListVO.setResponseMap(responseMap);
		mav.addObject("perListVO", perListVO);
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.postlogin.per.perDetails.url}", method = RequestMethod.GET)
	public ModelAndView perDetails() throws Exception {
		System.out.println("In PerDetails");
		
		final String METHOD_NAME = "perDetails";
		
		// TODO
		Integer perId = 1;
		PerVO perVO = null;
		try {
			perVO = perHandler.getPerDetails(perId, httpSession);
		} catch (Exception e) {
			throw new CustomException(ICommonConstants.SERVICE_UNAVAIL_ERROR_CD, ICommonConstants.SERVICE_UNAVAIL_ERROR_DESC);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After Calling PerHandler", perVO.toString());
		ModelAndView mav = new ModelAndView("per");
		mav.addObject("perVo",perVO);
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.per.perCC}", method = RequestMethod.GET)
	public ModelAndView perChangeControl() {
		PerVO perVo = new PerVO();
		ModelAndView mav = new ModelAndView("perChangeControl");
		mav.addObject("perVO", perVo);
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.per.perCCSubmit}", method = RequestMethod.POST)
	public ModelAndView perCcSubmit(@ModelAttribute("perVO") @Valid PerVO perVO, BindingResult result) {
		final String METHOD_NAME = "perCcSubmit";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerController.perCcSubmit:", perVO.toString());
		perHandler.insertPerCCDetails(perVO);
		ModelAndView mav = new ModelAndView("per");
		String perCcSuccess="Change Control \""+perVO.getPerChangeControl().getCcNumber()+"\" is saved successfully";
		mav.addObject("perCcSuccess", perCcSuccess);
		mav.addObject("perVo", perVO);
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.per.perCCAccordianClick}", method = RequestMethod.POST)
	public ModelAndView ccAccordianClick() {
		PerVO perVo = new PerVO();
		ModelAndView mav = new ModelAndView("perChangeControl");
		mav.addObject("perVO", perVo);
		return mav;
	}
	

}
