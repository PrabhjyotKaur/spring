package com.cg.eztrac.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.handler.BuildHandler;
import com.cg.eztrac.validator.BuildValidator;
import com.cg.eztrac.vo.AttachmentVO;
import com.cg.eztrac.vo.BuildListVO;
import com.cg.eztrac.vo.BuildVO;
import com.cg.eztrac.vo.CommentVO;

@Controller
@PropertySource("classpath:appurlcontroller.properties")
public class BuildController {

	
private static final String CLASS_NAME = "BuildController";
	
	/*@Autowired
	BuildValidator buildValidator;*/
	
	@Autowired
	BuildHandler buildHandler;
	
	@Autowired
	HttpSession httpSession;

	@RequestMapping(value = "${eztrack.build.new.url}", method = RequestMethod.POST)
	public ModelAndView buildNew() throws Exception {
		
		final String METHOD_NAME = "buildNew";
		LoggerManager.writeInfoLog(CLASS_NAME,METHOD_NAME,"Build New", "Entering Build New Page");

		
		BuildVO buildVO = new BuildVO();
		
		//TODO
		List<String> perNumberList = new ArrayList<String>();
		perNumberList.add("PR001122");
		perNumberList.add("PR001124");
		perNumberList.add("PR001125");
		perNumberList.add("PR001127");
		buildVO.setPerNumberList(perNumberList);

		List<String> assignedToList = new ArrayList<String>();
		assignedToList.add("Employee1");
		assignedToList.add("Employee2");
		assignedToList.add("Employee3");
		assignedToList.add("Employee4");
		assignedToList.add("Employee5");
		assignedToList.add("Employee6");
		assignedToList.add("Employee7");
		buildVO.setAssignedToList(assignedToList);
		
		
		// Role Restriction Matrix Starts
		buildVO.setRoleRestrictionMatrixPattern(ICommonConstants.BUILD_NEW_RESTRICTION_PATTERN);
		
		ModelAndView mav = new ModelAndView("build");
		mav.addObject("buildVO", buildVO);
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.build.submit.url}", method=RequestMethod.POST)
	public ModelAndView buildSubmit(ModelAndView mv,@ModelAttribute("buildVO") @Valid BuildVO buildVO,BindingResult result ) throws Exception{
		final String METHOD_NAME = "buildSubmit";
		BuildValidator buildValidator = new BuildValidator();
		ModelAndView mav = new ModelAndView("build");
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before invoking server side valdator", "");
		try {
		buildValidator.validate(buildVO, result);
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Server Side Validator Exception");
			e.printStackTrace();
		}
		if(result.hasErrors())
		{
			System.out.println("error occured"+result.getAllErrors());
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Server side error occured", "");
			return new ModelAndView("build");
		}
		else
		{
			System.out.println(buildHandler);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildController.buildSubmit:Before Handler Call",buildVO.toString());
			try {
				buildHandler.insertBuildDetails(buildVO,httpSession);
			}
			catch (Exception e) {
				System.out.println("BuildController - Insert Build Catch Block");
				e.printStackTrace();
				LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildInsertResponse Exception", e, "Redirecting to custom exception");
				throw new CustomException(ICommonConstants.SERVICE_UNAVAIL_ERROR_CD, ICommonConstants.SERVICE_UNAVAIL_ERROR_DESC);
			}
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildController.buildSubmit: After Handler Call",buildVO.toString());
			
			mav.addObject("buildVO", buildVO);
			return mav;
		}
	}
	
	@RequestMapping(value = "${eztrack.build.edit.url}", method = RequestMethod.POST)
	public ModelAndView buildEdit(@ModelAttribute("buildListVO") BuildListVO buildListVO) throws Exception {
		final String METHOD_NAME = "buildEdit";
		ModelAndView mav = new ModelAndView("buildList");
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.build.list.url}", method = RequestMethod.POST)
	public ModelAndView buildList(@ModelAttribute("buildListVO") @Valid BuildListVO buildListVO, BindingResult result) throws Exception {
		
		final String METHOD_NAME = "buildList";
		ModelAndView mav = new ModelAndView("buildList");
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildController.buildList:", buildListVO.toString());
		
		try {
			buildHandler.getBuildList(buildListVO, httpSession);
		}
		catch (Exception e) {
			System.out.println("BuildController catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildListResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(ICommonConstants.SERVICE_UNAVAIL_ERROR_CD, ICommonConstants.SERVICE_UNAVAIL_ERROR_DESC);
		}
		
		//Setting Response code and description
		Map<String, String> responseMap=new HashMap<String, String>();
		responseMap=(Map<String, String>) httpSession.getAttribute("responseMap");
		buildListVO.setResponseMap(responseMap);
		mav.addObject("buildListVO", buildListVO);
		
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.build.details.url}")
	/*@RequestMapping(value = "/build_details/{id}")*/
	public ModelAndView buildDetails(@PathVariable("id") int id) throws Exception {
		final String METHOD_NAME = "buildDetails";
		int buildId=id;
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildController.buildDetails:","buildId="+buildId);
		
		BuildVO buildVO = new BuildVO();
		buildVO.setBuildId(buildId);
		
		ModelAndView mav = new ModelAndView("build");
		
		try {
			buildHandler.getBuildDetails(buildVO, httpSession);
		}
		catch (Exception e) {
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildDetailsResponse Exception", e, "Redirecting to custom exception");
			throw new CustomException(ICommonConstants.SERVICE_UNAVAIL_ERROR_CD, ICommonConstants.SERVICE_UNAVAIL_ERROR_DESC);
		}
		
		mav.addObject("buildVO", buildVO);
		
		return mav;
	}
	
	@RequestMapping(value = "${eztrack.build.cc.url}", method = RequestMethod.POST)
	public ModelAndView buildChangeControl() throws Exception {
		final String METHOD_NAME = "buildChangeControl";
		BuildVO buildVO=new BuildVO();
		
		ModelAndView mav = new ModelAndView("buildChangeControl");
		mav.addObject("buildVO", buildVO);
		return mav;
	}

	@RequestMapping(value = "${eztrack.build.cc.submit.url}", method = RequestMethod.POST)
	public ModelAndView buildCcSubmit(@ModelAttribute("buildVO") @Valid BuildVO buildVO,BindingResult result) throws Exception {
		final String METHOD_NAME = "buildCcSubmit";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, buildVO.toString(), "After retrieving RoleRestrictionMatrixMap from Servlet Context:");
		
		String buildCcSuccess="Details of Change Control \""+buildVO.getBuildChangeControl().getCcNumber()+"\" is saved successfully";
		ModelAndView mav = new ModelAndView("build");
		mav.addObject("buildCcSuccess", buildCcSuccess);
		mav.addObject("buildVO", buildVO);
		return mav;
	}

}
