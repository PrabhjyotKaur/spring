package com.cg.eztrac.config;

//Web.xml and SpringSecurityFilterChain configuration

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;


public class WebXmlConfig extends AbstractSecurityWebApplicationInitializer {

}
