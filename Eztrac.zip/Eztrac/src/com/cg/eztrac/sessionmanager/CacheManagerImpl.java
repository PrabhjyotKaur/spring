package com.cg.eztrac.sessionmanager;

public class CacheManagerImpl extends AbstractManager{

	public CacheManagerImpl() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public void getAppDetails() {
		System.out.println("CacheManagerImple:	getAppDetails");
		
	}


	@Override
	Object createSession() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	boolean addDataToSession(Object obj) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	boolean removeDataFromSession(String attributeName) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	boolean destroySession() {
		// TODO Auto-generated method stub
		return false;
	}

}