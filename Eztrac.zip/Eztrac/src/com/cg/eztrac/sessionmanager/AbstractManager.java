/**
 * 
 */
package com.cg.eztrac.sessionmanager;

import javax.servlet.http.HttpServlet;

/**
 * @author nageorge
 *
 */
public abstract class AbstractManager {

	/**
	 * 
	 */
	public AbstractManager() {
		// TODO Auto-generated constructor stub
	}

	abstract void getAppDetails();
	
	abstract Object createSession();
	abstract boolean addDataToSession(Object obj);
	abstract  boolean removeDataFromSession(String attributeName);
	abstract boolean destroySession();
	

}
