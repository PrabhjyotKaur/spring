package com.cg.eztrac.sessionmanager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SessionManagerImpl extends AbstractManager implements DataPersistence {

	HttpServletRequest request;
	HttpSession session;

	@Override
	public Object createSession() {
		session = request.getSession(true);
		return session;
	}

	public boolean addDataToSess(String name, Object obj) {
		session.setAttribute(name, obj);
		return true;
	}

	@Override
	public boolean removeDataFromSession(String attributeName) {
		session.removeAttribute(attributeName);// check
		return false;
	}

	@Override
	public boolean destroySession() {
		session.invalidate();
		return true;
	}

	@Override
	void getAppDetails() {

	}

	@Override
	public Object persitData(String key, Object obj) {
		addDataToSess(key,obj);
		return null;
	}

	@Override
	public Object getPersistData() {
		return null;
	}

	@Override
	public Object removePersistData() {
		return null;
	}

	@Override
	boolean addDataToSession(Object obj) {
		return false;
	}


}
