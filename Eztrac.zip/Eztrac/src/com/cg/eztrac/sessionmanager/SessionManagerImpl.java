package com.cg.eztrac.sessionmanager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SessionManagerImpl extends AbstractManager {

	HttpServletRequest request;
	HttpSession session;

	@Override
	public Object createSession() {
		session = request.getSession(true);
		return session;
	}

	@Override
	public boolean addDataToSession(Object name) {
		session.setAttribute("name", name);
		return true;
	}

	@Override
	public boolean removeDataFromSession(String attributeName) {
		session.removeAttribute(attributeName);// check
		return false;
	}

	@Override
	public boolean destroySession() {
		session.invalidate();
		return true;
	}

	@Override
	void getAppDetails() {
		// TODO Auto-generated method stub

	}

}
