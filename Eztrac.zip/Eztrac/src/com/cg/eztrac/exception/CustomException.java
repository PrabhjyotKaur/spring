package com.cg.eztrac.exception;

public class CustomException extends Exception{

}
