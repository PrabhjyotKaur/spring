package com.cg.eztrac.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.cg.eztrac.common.LoggerManager;

@ControllerAdvice
public class GlobalExceptionController {

	String class_name = GlobalExceptionController.class.getSimpleName();

	@ExceptionHandler(CustomException.class)
	public ModelAndView handleCustomException(CustomException ex) {
		String method_name = "handleCustomException";
		ModelAndView model = new ModelAndView();
		model.addObject("errCode", ex.getErrCode());
		model.addObject("errMsg", ex.getErrMsg());
		model.setViewName("genericerror");
		LoggerManager.writeErrorLog(class_name, method_name, "Error handled by handleCustomException", ex,
				ex.getErrMsg());
		return model;

	}

	@ExceptionHandler(NoHandlerFoundException.class)
	public ModelAndView handleNoHandlerFoundException(NoHandlerFoundException ex) {
		String method_name = "handleNoHandlerFoundException";
		ModelAndView model = new ModelAndView();
		model.addObject("errCode", "EXEXXX");
		model.addObject("errMsg", ex.getMessage());
		model.setViewName("genericerror");
		LoggerManager.writeErrorLog(class_name, method_name, "Error handled by handleNoHandlerFoundException", ex,
				ex.getMessage());
		return model;
	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex) {
		String method_name = "handleException";

		ModelAndView model = new ModelAndView();
		model.addObject("errCode", "EXEXXX");
		model.addObject("errMsg", ex.getMessage());
		model.setViewName("genericerror");
		LoggerManager.writeErrorLog(class_name, method_name, "Error handled by handleException", ex, ex.getMessage());
		return model;

	}

}
