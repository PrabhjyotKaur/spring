package com.cg.eztrac.context;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.cg.eztrac.common.CommonUtility;

@WebListener
public class AppServletContextListener implements ServletContextListener {
	
	@Override
	public void contextInitialized(ServletContextEvent servletContextEvent) {
		CommonUtility.setServletContext(servletContextEvent.getServletContext());
	}
	
}
