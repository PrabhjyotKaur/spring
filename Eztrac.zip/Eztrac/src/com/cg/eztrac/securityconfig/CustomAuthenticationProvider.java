package com.cg.eztrac.securityconfig;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;

@Service
@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	private static final String CLASS_NAME = CustomAuthenticationProvider.class.getSimpleName();

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String methodName = "authenticate";

		//System.out.println(supports(authentication.getClass()));

		String name = authentication.getName();
		String password = authentication.getCredentials().toString();

		// sign in service call
		try {
			authentication = authenticateUserSignInCallAuth(name, password, authentication);
		} catch (Exception exe) {
			exe.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, methodName, exe.getMessage(), exe,
					"Exception in " + methodName + " Could Not Authenticate USER");
			return null;
		}

		// use the credentials and authenticate against the third-party system
		if (authentication.isAuthenticated()) {
			return authentication;
		} else {
			LoggerManager.writeDebugLog(CLASS_NAME, methodName, "Authentication is not true",
					methodName + " Could Not Authenticate USER");
			return null;
		}
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

	public Authentication authenticateUserSignInCallAuth(String name, String password, Authentication authentication)
			throws Exception {

		UserDO userDO = new UserDO();
		userDO.setUsername(name);
		userDO.setPassword(password);

		userDO = userDO.callSignInService(userDO);
		// boolean signINFlag = true;

		if (null != userDO && userDO.getResponseCode().equals(ICommonConstants.SUCCESS_LOGIN_RESPONSE_CODE)) {

			// Roles Code Start
			List<RoleDO> roleDOList = userDO.getRoles();
			List<SimpleGrantedAuthority> authorities = new ArrayList<>();

			// (List<SimpleGrantedAuthority>)
			// servletContext.getAttribute(ICommonConstants.AUTHORITIES_OBJS);

			for (RoleDO roleDO : roleDOList) {
				
				String roleName = "";
				if (roleDO.getRoleId().equals(ICommonConstants.ADMIN_ROLE_ID)) {
					roleName = ICommonConstants.ADMIN_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.PMO_ROLE_ID)) {
					roleName = ICommonConstants.PMO_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.PM_ROLE_ID)) {
					roleName = ICommonConstants.PM_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.PL_ROLE_ID)) {
					roleName = ICommonConstants.PL_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.TM_ROLE_ID)) {
					roleName = ICommonConstants.TM_STRING;
				} else if (roleDO.getRoleId().equals(ICommonConstants.SYFITPM_ROLE_ID)) {
					roleName = ICommonConstants.SYFITPM_STRING;
				}
				
				authorities.add(new SimpleGrantedAuthority(ICommonConstants.ROLE_STRING + roleName));
				 //authorities.add(new SimpleGrantedAuthority(roleName));
			}

			authentication = new UsernamePasswordAuthenticationToken(name, null, authorities);
			// Roles code end

			return authentication;

		} else {
			throw new Exception("Not Successfull Login");
			// return null;
		}

	}

}
