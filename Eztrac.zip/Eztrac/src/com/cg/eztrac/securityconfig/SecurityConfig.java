package com.cg.eztrac.securityconfig;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.AuthDO;
import com.cg.eztrac.domain.RolePermissionDO;
import com.cg.eztrac.domain.SectionDetailDO;
import com.cg.eztrac.handler.OnLoadHandler;
import com.cg.eztrac.vo.SectionVO;
import com.cg.eztrac.vo.SubSectionVO;

@Configuration
@EnableWebSecurity
@ComponentScan("com.cg.eztrac")
@PropertySource("classpath:appurlcontroller.properties")
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	private static String CLASS_NAME = SecurityConfig.class.getName();

	@Autowired
	public ServletContext servletcontext;

	@Autowired
	private CustomAuthenticationProvider authProvider;
	
	OnLoadHandler onLoadHandler = new OnLoadHandler();

	/*
	 * @Value("${eztrack.postlogin.map}") private Map<String,Object> urlMap;
	 */

	/*
	 * private Map<String, String> fieldsMap;
	 * 
	 * @PostConstruct public void init() { fieldsMap = new HashMap<String,
	 * String>(); if (urlMap != null && urlMap.size() != 0) { for (String field :
	 * urlMap) { String[] splittedField = field.split(",");
	 * fieldsMap.put(splittedField[0], splittedField[1]); } } }
	 */

	@Autowired
	public Environment env;

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authProvider);
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		String methodName = "configure";

		if (env.getProperty("eztrack.security.enableflag").equalsIgnoreCase(ICommonConstants.Y_STRING)) {
			
			Map<String, Object> urlMap = getAllUrlProperties("appurlcontroller.properties");

			List<AuthDO> authObjs = new ArrayList<>();

			if (allRoleMenuAccebiltiy()) {

				Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = (Map<Integer, Map<Integer, List<SectionVO>>>) servletcontext
						.getAttribute(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT);

				for (Entry<Integer, Map<Integer, List<SectionVO>>> roleMap : allRoleMenuAccebiltiy.entrySet()) {
					Integer roleKey = roleMap.getKey();
					String rolename = setRoleName(roleKey);
					if (roleKey.equals(ICommonConstants.ADMIN_ROLE_ID) || roleKey.equals(ICommonConstants.PMO_ROLE_ID)
							|| roleKey.equals(ICommonConstants.PM_ROLE_ID)
							|| roleKey.equals(ICommonConstants.PL_ROLE_ID)
							|| roleKey.equals(ICommonConstants.TM_ROLE_ID)
							|| roleKey.equals(ICommonConstants.SYFITPM_ROLE_ID)) {
						Map<Integer, List<SectionVO>> sectionsMap = roleMap.getValue();

						for (Entry<Integer, List<SectionVO>> sectionMap : sectionsMap.entrySet()) {

							List<SectionVO> sectionsVO = sectionMap.getValue();
							for (SectionVO sectionVO : sectionsVO) {
								if (sectionVO != null) {
									authObjs.add(new AuthDO(roleKey, rolename, sectionVO.getSectionId(),
											sectionVO.getSectionName(), sectionVO.isElligbleFlag(),
											ICommonConstants.EMPTY_URL_STRING));

									for (SubSectionVO subSectionVO : sectionVO.getSubSectionVO()) {
										if (subSectionVO != null) {
											authObjs.add(new AuthDO(roleKey, rolename, subSectionVO.getSubSectionId(),
													subSectionVO.getSubSectionName(), subSectionVO.isElligbleFlag(),
													ICommonConstants.EMPTY_URL_STRING));
										}
									}
								}

							}
						}
					}
				}

				// Postlogin url's mapped with the roles from Service.
				for (Map.Entry<String, Object> entry : urlMap.entrySet()) {
					String roles = "";
					String sectionNameFromProp = entry.getKey().trim();
					String urlFromProp = ((String) entry.getValue()).trim();
					for (AuthDO authDO : authObjs) {
						if (sectionNameFromProp.equalsIgnoreCase(authDO.getSectionName().trim())
								&& authDO.isElligbleFlag()) {
							roles = addRoleString(roles, authDO.getRoleName().trim());
						}
					}
					roles = "hasRole('Admin') or hasRole('PMO') or hasRole('PM') or hasRole('PL') or hasRole('TM') or hasRole('SYFITPM')";
					http.authorizeRequests().antMatchers(urlFromProp).access(roles);
				}

				http.authorizeRequests()
					.antMatchers(env.getProperty("eztrack.generic.asset.url")).permitAll()
					.anyRequest().authenticated()
					.and().formLogin()
						.loginPage(env.getProperty("eztrack.prelogin.login.url"))
						.successHandler(authenticationSuccessHandler()).permitAll()
					.and().logout()
						.logoutUrl(env.getProperty("eztrack.postlogin.logout.url")).invalidateHttpSession(true)
					.and().exceptionHandling().accessDeniedPage(env.getProperty("eztrack.generic.error.html"));

			} else {
				throw new Exception("Could Not load Role Permissions to Context");
			}
		} else {
			http.authorizeRequests().antMatchers(env.getProperty("eztrack.generic.all.url")).permitAll();
		}
	}
	
	@Bean
	AuthenticationSuccessHandler authenticationSuccessHandler() {
		return new AuthenticationSuccessHandler() {
			@Override
			public void onAuthenticationSuccess(HttpServletRequest req, HttpServletResponse res, Authentication auth)
					throws IOException, ServletException {
				res.sendRedirect(req.getContextPath()+env.getProperty("eztrack.postlogin.home.url"));
			}
		};
	}

	public String addRoleString(String source, String roleToAppend) {
		String addOrStr = ICommonConstants.OR_STRING_WITH_SPACE_BEFORE_AFTER;

		if (source.length() < 1) {
			source = source.concat(roleToAppend);
		} else {
			source = source.concat(addOrStr);
			source = source.concat(roleToAppend);
		}
		return source;
	}

	public static Map<String, Object> getAllUrlProperties(String pathUrl) throws Exception {
		Properties properties = new Properties();
		Map<String, Object> map = new HashMap<>();

		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		InputStream is = classloader.getResourceAsStream(pathUrl);
		
		properties.load(is);
		is.close();

		for (String key : properties.stringPropertyNames()) {
			String value = properties.getProperty(key);
			String[] arg = value.split(",");

			if (arg != null && arg.length == 2) {
				map.put(arg[1], arg[0]);
			}
		}
		return map;
	}
	
	public String setRoleName(Integer roleKey) {
		String roleName = "";
		if (roleKey.equals(ICommonConstants.ADMIN_ROLE_ID)) {
			roleName = ICommonConstants.ADMIN_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.PMO_ROLE_ID)) {
			roleName = ICommonConstants.PMO_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.PM_ROLE_ID)) {
			roleName = ICommonConstants.PM_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.PL_ROLE_ID)) {
			roleName = ICommonConstants.PL_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.TM_ROLE_ID)) {
			roleName = ICommonConstants.TM_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.SYFITPM_ROLE_ID)) {
			roleName = ICommonConstants.SYFITPM_ROLE_NAME;
		}
		return roleName;
	}
	
	public static boolean loadRolePermissionsToContext(ServletContext servletcontext) {

		final String METHOD_NAME = "loadRolePermission";
		boolean status = false;
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"application context called upon application start-up");

		OnLoadHandler onLoadHandler = new OnLoadHandler();

		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
				ICommonConstants.SPRING_FILTER_LOG_KEY + "In application context",
				"Before calling the loadSectionDetails() from Application context");
		List<SectionDetailDO> loadSectionDetails = onLoadHandler.loadSectionDetails();
		if (null != loadSectionDetails && !loadSectionDetails.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.ALL_SEC_DETAILS_CONTEXT, loadSectionDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"loadSectionDetails() is called and data is added to servlet context");

		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"Before calling the loadRolePermissionDetails() from Application context");
		List<RolePermissionDO> loadRolePermissionDetails = onLoadHandler.loadRolePermissionDetails();
		if (null != loadRolePermissionDetails && !loadRolePermissionDetails.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT, loadRolePermissionDetails);

			/*
			 * // TODO - Need to get the roleId in which the user has logged in int roleId =
			 * 2; servletcontext.setAttribute(ICommonConstants.
			 * ALL_ROLE_RESTRICTION_MATRIX_CONTEXT,
			 * CommonUtility.formRoleRestrictionMatrix(loadRolePermissionDetails, roleId));
			 */
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"loadRolePermissionDetails() is called and data is added to servlet context");

		Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = CommonUtility
				.getUserMenuAccebiltiy(loadRolePermissionDetails, loadSectionDetails);
		if (null != allRoleMenuAccebiltiy && !allRoleMenuAccebiltiy.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT, allRoleMenuAccebiltiy);
			status = true;
		}
		return status;
	}

	public boolean allRoleMenuAccebiltiy() throws Exception {
		String methodName = "allRoleMenuAccebiltiy";
		boolean status = false;
		loadSectionDetailsIntoContext();
		loadRolePermissionDetailsIntoContext();
		Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = CommonUtility.getUserMenuAccebiltiy(
				servletcontext.getAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT),
				servletcontext.getAttribute(ICommonConstants.ALL_SEC_DETAILS_CONTEXT));
		if (null != allRoleMenuAccebiltiy && !allRoleMenuAccebiltiy.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT, allRoleMenuAccebiltiy);
			status = true;
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"All role menu accessbility data structure is created and data is added to servlet context");

		return status;
	}

	public void loadSectionDetailsIntoContext() throws Exception {
		String methodName = "loadSectionDetailsIntoContext";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + "In application context",
				"Before calling the loadSectionDetails() from Application context");
		List<SectionDetailDO> loadSectionDetails = onLoadHandler.loadSectionDetails();
		if (null != loadSectionDetails && !loadSectionDetails.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.ALL_SEC_DETAILS_CONTEXT, loadSectionDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"loadSectionDetails() is called and data is added to servlet context");
	}

	public void loadRolePermissionDetailsIntoContext() throws Exception {
		String methodName = "loadRolePermissionDetailsIntoContext";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"Before calling the loadRolePermissionDetails() from Application context");
		List<RolePermissionDO> loadRolePermissionDetails = onLoadHandler.loadRolePermissionDetails();
		if (null != loadRolePermissionDetails && !loadRolePermissionDetails.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT, loadRolePermissionDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"loadRolePermissionDetails() is called and data is added to servlet context");
	}

}