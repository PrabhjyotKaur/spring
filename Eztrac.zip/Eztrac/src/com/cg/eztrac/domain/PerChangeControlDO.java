package com.cg.eztrac.domain;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

@Component(value="perChangeControlDO")
public class PerChangeControlDO extends ChangeControlDO {
	
	private String perCCPhase;
	private Date perCCCancellationDate;
	private Date perCCCompletionDate;
	private String[] perCCTeamsInvolvedArray;
	
	private boolean perCCSendMailFlag;
	private boolean perCCOnsiteOnlyFlag;
	private boolean perCCMarkAllCCClosedFlag;
	
	private AttachmentDO perCCAttachmentDO;
	private List<AttachmentDO> attachmentList;

	public String getPerCCPhase() {
		return perCCPhase;
	}

	public void setPerCCPhase(String perCCPhase) {
		this.perCCPhase = perCCPhase;
	}

	public Date getPerCCCancellationDate() {
		return perCCCancellationDate;
	}

	public void setPerCCCancellationDate(Date perCCCancellationDate) {
		this.perCCCancellationDate = perCCCancellationDate;
	}

	public Date getPerCCCompletionDate() {
		return perCCCompletionDate;
	}

	public void setPerCCCompletionDate(Date perCCCompletionDate) {
		this.perCCCompletionDate = perCCCompletionDate;
	}

	public String[] getPerCCTeamsInvolvedArray() {
		return perCCTeamsInvolvedArray;
	}

	public void setPerCCTeamsInvolvedArray(String[] perCCTeamsInvolvedArray) {
		this.perCCTeamsInvolvedArray = perCCTeamsInvolvedArray;
	}

	public boolean isPerCCSendMailFlag() {
		return perCCSendMailFlag;
	}

	public void setPerCCSendMailFlag(boolean perCCSendMailFlag) {
		this.perCCSendMailFlag = perCCSendMailFlag;
	}

	public boolean isPerCCOnsiteOnlyFlag() {
		return perCCOnsiteOnlyFlag;
	}

	public void setPerCCOnsiteOnlyFlag(boolean perCCOnsiteOnlyFlag) {
		this.perCCOnsiteOnlyFlag = perCCOnsiteOnlyFlag;
	}

	public boolean isPerCCMarkAllCCClosedFlag() {
		return perCCMarkAllCCClosedFlag;
	}

	public void setPerCCMarkAllCCClosedFlag(boolean perCCMarkAllCCClosedFlag) {
		this.perCCMarkAllCCClosedFlag = perCCMarkAllCCClosedFlag;
	}

	public AttachmentDO getPerCCAttachmentDO() {
		return perCCAttachmentDO;
	}

	public void setPerCCAttachmentDO(AttachmentDO perCCAttachmentDO) {
		this.perCCAttachmentDO = perCCAttachmentDO;
	}
	
	public List<AttachmentDO> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<AttachmentDO> attachmentList) {
		this.attachmentList = attachmentList;
	}

	@Override
	public String toString() {
		return "PerChangeControlDO [perCCPhase=" + perCCPhase + ", perCCCancellationDate=" + perCCCancellationDate
				+ ", perCCCompletionDate=" + perCCCompletionDate + ", perCCTeamsInvolvedArray="
				+ Arrays.toString(perCCTeamsInvolvedArray) + ", perCCSendMailFlag=" + perCCSendMailFlag
				+ ", perCCOnsiteOnlyFlag=" + perCCOnsiteOnlyFlag + ", perCCMarkAllCCClosedFlag="
				+ perCCMarkAllCCClosedFlag + ", perCCAttachmentDO=" + perCCAttachmentDO + ", attachmentList="
				+ attachmentList + "]";
	}

}
