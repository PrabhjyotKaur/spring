package com.cg.eztrac.domain;

public class AuthDO {

	boolean elligbleFlag = false;
	private Integer sectionId;
	private String sectionName = "";
	private Integer roleId;
	private String isUrl;
	private String roleName;

	public AuthDO(Integer roleId, String roleName, Integer sectionId, String sectionName, boolean elligbleFlag,
			String isUrl) {
		this.setRoleId(roleId);
		this.setSectionId(sectionId);
		this.setSectionName(sectionName);
		this.setElligbleFlag(elligbleFlag);
		this.setIsUrl(isUrl);
		this.setRoleName(roleName);

	}

	public boolean isElligbleFlag() {
		return elligbleFlag;
	}

	public void setElligbleFlag(boolean elligbleFlag) {
		this.elligbleFlag = elligbleFlag;
	}

	public Integer getSectionId() {
		return sectionId;
	}

	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getIsUrl() {
		return isUrl;
	}

	public void setIsUrl(String isUrl) {
		this.isUrl = isUrl;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

}
