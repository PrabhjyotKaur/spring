package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.common.UserStatus;
import com.cg.eztrac.encryption.AESEncryption;
import com.cg.eztrac.service.SignInService;
import com.cg.eztrac.service.impl.SignInImpl;
import com.cg.eztrac.service.request.LoginInfoReq;
import com.cg.eztrac.service.response.LoginInfoRes;
import com.cg.eztrac.service.response.UserLocations;
import com.google.gson.Gson;


public class UserDO extends BaseDO {
	String className=UserDO.class.getSimpleName();
	private MenuDO menuDO = new MenuDO();
	private String responseDescription;
	private String responseCode;
	private String username;
	private String password;
	private String eventDate;
	private String emailId;
	//private String location;
	private List<UserLocations> location;
	

	
	private String employeeCode;
	private String unitAssigned;
	private String gdcName;
	private String accountName;
	private String subAccountName;
	private String sbu;
	private int userId;
	private String clientReportingFlag;
	private Integer clientSsoId;
	private String inductionFlag;
	private String telOfficeNum;
	private String telMobileNum;
	private int subAccountId;
	private List<RoleDO> roles;
	private UserStatus status;
	private HomePageDataDO homePageDataDO;
	private String currentRoleId;
//	getCurrentRole();
	public List<UserLocations> getLocation() {
		return location;
	}
	public void setLocation(List<UserLocations> location) {
		this.location = location;
	}
	public String getCurrentRoleId() {
		return currentRoleId;
	}
	public MenuDO getMenuDO() {
		return menuDO;
	}
	public void setMenuDO(MenuDO menuDO) {
		this.menuDO = menuDO;
	}
	public void setCurrentRoleId(String currentRoleId) {
		this.currentRoleId = currentRoleId;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public HomePageDataDO getHomePageDataDO() {
		return homePageDataDO;
	}
	public void setHomePageDataDO(HomePageDataDO homePageDataDO) {
		this.homePageDataDO = homePageDataDO;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getUnitAssigned() {
		return unitAssigned;
	}
	public void setUnitAssigned(String unitAssigned) {
		this.unitAssigned = unitAssigned;
	}
	public String getGdcName() {
		return gdcName;
	}
	public void setGdcName(String gdcName) {
		this.gdcName = gdcName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getSubAccountName() {
		return subAccountName;
	}
	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}
	public String getSbu() {
		return sbu;
	}
	public void setSbu(String sbu) {
		this.sbu = sbu;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getClientReportingFlag() {
		return clientReportingFlag;
	}
	public void setClientReportingFlag(String clientReportingFlag) {
		this.clientReportingFlag = clientReportingFlag;
	}
	public Integer getClientSsoId() {
		return clientSsoId;
	}
	public void setClientSsoId(Integer clientSsoId) {
		this.clientSsoId = clientSsoId;
	}
	public String getInductionFlag() {
		return inductionFlag;
	}
	public void setInductionFlag(String inductionFlag) {
		this.inductionFlag = inductionFlag;
	}
	public String getTelOfficeNum() {
		return telOfficeNum;
	}
	public void setTelOfficeNum(String telOfficeNum) {
		this.telOfficeNum = telOfficeNum;
	}
	public String getTelMobileNum() {
		return telMobileNum;
	}
	public void setTelMobileNum(String telMobileNum) {
		this.telMobileNum = telMobileNum;
	}
	public int getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	public List<RoleDO> getRoles() {
		return roles;
	}
	public void setRoles(List<RoleDO> roles) {
		this.roles = roles;
	}
	public UserStatus getStatus() {
		return status;
	}
	public void setStatus(UserStatus status) {
		this.status = status;
	}
	
	public UserDO callSignInService(UserDO userDO) throws Exception {
		LoginInfoReq loginInfoReq = populateDOToLoginRequest(userDO);
		SignInService signInImpl = new SignInImpl();
		LoginInfoRes loginSignIn = signInImpl.loginSignIn(loginInfoReq);
		userDO = populateResponseToDO(loginSignIn,userDO);
		return userDO;
	}
	/** forming UserDO ( response-> DO) */
	private UserDO populateResponseToDO(LoginInfoRes loginSignResp, UserDO userDO) {
		userDO = new UserDO();
		if(loginSignResp.getResponseCode().equalsIgnoreCase("100")){ // success=100
			List<RoleDO> roleDOList = new ArrayList<RoleDO>();
			Gson gson = new Gson();
					/** convert response "gson" to "object" */
					for (int i=0;i<loginSignResp.getRolepermission().size();i++){
						RoleDO roleDO = new RoleDO();
						String roleDOJson = gson.toJson( loginSignResp.getRolepermission().get(i));
						roleDO = gson.fromJson(roleDOJson, RoleDO.class);
						roleDOList.add(roleDO);
					}
		//	String homepageData = gson.toJson( loginSignResp.getHomePageData());
			 //HomePageDataDO fromJson = gson.fromJson(homepageData, HomePageDataDO.class);
			//userDO.setHomePageDataDO(fromJson);
			userDO.setRoles(roleDOList);
			userDO.setAccountName(loginSignResp.getUserDedail().getAccountName());
			userDO.setClientReportingFlag(loginSignResp.getUserDedail().getClientReportingFlag());
			userDO.setClientSsoId(loginSignResp.getUserDedail().getClientSsoId());
			userDO.setEmailId(loginSignResp.getUserDedail().getEmailId());
			userDO.setEmployeeCode(loginSignResp.getUserDedail().getEmployeeCode());
			//userDO.setEventDate(loginSignResp.getHomePageData().getEventDate());
			userDO.setGdcName(loginSignResp.getUserDedail().getGdcName());
			userDO.setInductionFlag(loginSignResp.getUserDedail().getInductionFlag());
			userDO.setSbu(loginSignResp.getUserDedail().getSbu());
			userDO.setLocation(loginSignResp.getUserlocations());
			//userDO.setStatus(
			userDO.setSubAccountId(loginSignResp.getUserDedail().getSubAccountId());
			userDO.setSubAccountName(loginSignResp.getUserDedail().getAccountName());
			userDO.setTelMobileNum(loginSignResp.getUserDedail().getTelMobileNum());
			userDO.setTelOfficeNum(loginSignResp.getUserDedail().getTelOfficeNum());
			userDO.setUnitAssigned(loginSignResp.getUserDedail().getUnitAssigned());
			userDO.setUserId(loginSignResp.getUserDedail().getUserId());
			userDO.setUsername(loginSignResp.getUserDedail().getUsername());
		}
		
		userDO.setResponseCode(loginSignResp.getResponseCode());
		userDO.setResponseDescription(loginSignResp.getResponseDescription());
		return userDO;
		
	}
	/** forming LoginRequest ( userDO -> request) */
	private LoginInfoReq populateDOToLoginRequest(UserDO userDO) {
		String methodName="populateDOToLoginRequest";
		LoginInfoReq loginInfoReq = new LoginInfoReq();
		try {
			loginInfoReq.setLoginId(userDO.getUsername());
			loginInfoReq.setPassowrd(AESEncryption.encrypt(userDO.getPassword()));
			loginInfoReq.setTokenId(userDO.getTokenId());
		} catch (Exception e) {
		LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while setting the vslues to login request");
		}
		return loginInfoReq;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	

	

}
