package com.cg.eztrac.domain;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.impl.BuildServiceImpl;
import com.cg.eztrac.service.impl.PerServiceImpl;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.request.PerCCInsertRequest;
import com.cg.eztrac.service.request.PerDetailsRequest;
import com.cg.eztrac.service.request.PerInsertRequest;
import com.cg.eztrac.service.response.BuildListResponse;
import com.cg.eztrac.service.response.PerCCInsertResponse;
import com.cg.eztrac.service.response.PerDetailsResponse;
import com.cg.eztrac.service.response.PerInsertResponse;

@Component(value="perDO")
public class PerDO extends EstimationDO {
	
	private static final String CLASS_NAME = PerDO.class.getSimpleName();
	
	@Autowired
	PerServiceImpl perServiceImpl;
	
	//General - Fields - Per Module
	
	private String currentPhaseEndDateString;
	private String[] managersToNotifyArray;
	private String parNumber;
	//private Date perReceiptDate;
	private String perReceiptDateString;
	private String projectComments;
	private Integer projectType;
	private String projectTypeName;
	private String status;
	
	//Schedule Updates - Fields - Per Module
	/*private Date scheduleCallDate;
	private Date cancellationDate;
	private Date currentScheduleEndDate;
	private Date currentScheduleStartDate;
	private Date restartDate;
	private Date stopDate;
	*/
	private String scheduleCallDateString;
	private String cancellationDateString;
	private String currentScheduleEndDateString;
	private String currentScheduleStartDateString;
	private String restartDateString;
	private String stopDateString;
	
	private PerChangeControlDO perChangeControl;
	private PerLoeDO perLoe;
	
	private List<PurchaseOrderDO> purchaseOrderList;
	private List<PerChangeControlDO> perChangeControlList;
	
	private String description; //TODO - Remove this - Temp added
	
	
	public String getCurrentPhaseEndDateString() {
		return currentPhaseEndDateString;
	}
	public void setCurrentPhaseEndDateString(String currentPhaseEndDateString) {
		this.currentPhaseEndDateString = currentPhaseEndDateString;
	}
	public String[] getManagersToNotifyArray() {
		return managersToNotifyArray;
	}
	public void setManagersToNotifyArray(String[] managersToNotifyArray) {
		this.managersToNotifyArray = managersToNotifyArray;
	}
	public String getParNumber() {
		return parNumber;
	}
	public void setParNumber(String parNumber) {
		this.parNumber = parNumber;
	}
	public String getPerReceiptDateString() {
		return perReceiptDateString;
	}
	public void setPerReceiptDateString(String perReceiptDateString) {
		this.perReceiptDateString = perReceiptDateString;
	}
	public String getScheduleCallDateString() {
		return scheduleCallDateString;
	}
	public void setScheduleCallDateString(String scheduleCallDateString) {
		this.scheduleCallDateString = scheduleCallDateString;
	}
	public String getCancellationDateString() {
		return cancellationDateString;
	}
	public void setCancellationDateString(String cancellationDateString) {
		this.cancellationDateString = cancellationDateString;
	}
	public String getCurrentScheduleEndDateString() {
		return currentScheduleEndDateString;
	}
	public void setCurrentScheduleEndDateString(String currentScheduleEndDateString) {
		this.currentScheduleEndDateString = currentScheduleEndDateString;
	}
	public String getCurrentScheduleStartDateString() {
		return currentScheduleStartDateString;
	}
	public void setCurrentScheduleStartDateString(String currentScheduleStartDateString) {
		this.currentScheduleStartDateString = currentScheduleStartDateString;
	}
	public String getRestartDateString() {
		return restartDateString;
	}
	public void setRestartDateString(String restartDateString) {
		this.restartDateString = restartDateString;
	}
	public String getStopDateString() {
		return stopDateString;
	}
	public void setStopDateString(String stopDateString) {
		this.stopDateString = stopDateString;
	}
	public String getProjectComments() {
		return projectComments;
	}
	public void setProjectComments(String projectComments) {
		this.projectComments = projectComments;
	}
	public Integer getProjectType() {
		return projectType;
	}
	public void setProjectType(Integer projectType) {
		this.projectType = projectType;
	}
	public String getProjectTypeName() {
		return projectTypeName;
	}
	public void setProjectTypeName(String projectTypeName) {
		this.projectTypeName = projectTypeName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public PerChangeControlDO getPerChangeControl() {
		return perChangeControl;
	}
	public void setPerChangeControl(PerChangeControlDO perChangeControl) {
		this.perChangeControl = perChangeControl;
	}
	public PerLoeDO getPerLoe() {
		return perLoe;
	}
	public void setPerLoe(PerLoeDO perLoe) {
		this.perLoe = perLoe;
	}
	public List<PurchaseOrderDO> getPurchaseOrderList() {
		return purchaseOrderList;
	}
	public void setPurchaseOrderList(List<PurchaseOrderDO> purchaseOrderList) {
		this.purchaseOrderList = purchaseOrderList;
	}
	public List<PerChangeControlDO> getPerChangeControlList() {
		return perChangeControlList;
	}
	public void setPerChangeControlList(List<PerChangeControlDO> perChangeControlList) {
		this.perChangeControlList = perChangeControlList;
	}
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void getPerDetails(int perId, HttpSession httpSession) throws Exception {
		final String METHOD_NAME = "getPerDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.getPerDetails:", populatePerDetailsRequest(perId).toString());
		System.out.println("Before Calling perDetailsRequest and Request"+ populatePerDetailsRequest(perId).toString());
		PerDO perDO = new PerDO();
		PerDetailsResponse perDetailsResponse=null;
		try{
			perDetailsResponse = perServiceImpl.getPerDetails(populatePerDetailsRequest(perId));
		}catch(Exception e){
			throw new Exception();
		}
		
		if(null != perDetailsResponse) {
			//TODO
			httpSession.setAttribute("perDetails", perDetailsResponse.getPer());
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.getPerDetails::", perDetailsResponse.toString());
	}
	//TODO
	//what we are going to return
	public void insertPerDetails(PerDO perDO) throws Exception {
		final String METHOD_NAME = "insertPerDetails";
		PerInsertResponse perInsertResponse = perServiceImpl.insertPerDetails(populatePerInsertRequest(perDO));
		String responseCode = perInsertResponse.getResponseCode();
		String responseDescription = perInsertResponse.getResponseDescription();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.insertPerDetails:responseCode:"+responseCode+":responseDescription:"+responseDescription, "");
		//perDO.setResponseMap(responseCode, responseDescription);
		//ICommonConstant.PER_OBJECT = "PerDetails";
		//httpSession.setAttribute(ICommonConstant.PER_OBJECT, perDO);
	}
	
	//TODO 
	//what we are going to return
	public void insertPerCCDetails(PerDO perDO){
		final String METHOD_NAME = "insertPerDetails";
		PerCCInsertResponse perCCInsertResponse = perServiceImpl.insertPerCCDetails(populatePerCCInsertRequest(perDO));
		String responseCode = perCCInsertResponse.getResponseCode();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.insertPerDetails:responseCode::", responseCode);
	}
	
	public PerDetailsRequest populatePerDetailsRequest(int perId) {
		PerDetailsRequest perDetailsRequest = new PerDetailsRequest();
		perDetailsRequest.setPerId(perId);
		perDetailsRequest.setTokenId("hjds");
		perDetailsRequest.setChannelId("CN");
		return perDetailsRequest;
	}
	
	public PerInsertRequest populatePerInsertRequest(PerDO perDO) {
		PerInsertRequest perInsertRequest = new PerInsertRequest();
		//TODO
		//perInsertRequest.setPerDO(perDO);
		//perInsertRequest.setTokenId();
		//perInsertRequest.setChannelId(channelId);
		return perInsertRequest;
	}
	
	public PerCCInsertRequest populatePerCCInsertRequest(PerDO perDO) {
		PerCCInsertRequest perCCInsertRequest = new PerCCInsertRequest();
		perCCInsertRequest.setPerDO(perDO);
		//perCCInsertRequest.setTokenId();
		//perCCInsertRequest.setChannelId(channelId);
		return perCCInsertRequest;
	}
	
	/*BuildList Methods*/
	public BuildListRequest populateBuildListRequest(BuildDO buildDO) {
		BuildListRequest buildListRequest = new BuildListRequest();
		// Dozer Copy Bean Properties from Domain Object to Request Object 
		CommonUtility.copyBeanProperties(buildDO, buildListRequest);
		buildListRequest.setTokenId("1234");
		buildListRequest.setChannelId("EZ");
		return buildListRequest;
	}
	
	public void getBuildList(BuildDO buildDO, HttpSession httpSession) throws Exception {
		
		final String METHOD_NAME = "getBuildList";
		BuildServiceImpl buildServiceImpl = new BuildServiceImpl();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildDO.getBuildList:", populateBuildListRequest(buildDO).toString());

		try {
			BuildListResponse buildListResponse = buildServiceImpl.getBuildList(populateBuildListRequest(buildDO));
			if(null != buildListResponse) {
				httpSession.setAttribute("buildListDO", buildListResponse.getBuildDetails());
				String responseCode= buildListResponse.getResponseCode();
				String responseDescription=buildListResponse.getResponseDescription();
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(responseCode, responseDescription);
				httpSession.setAttribute("responseMap", responseCodeMap);
			}
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildDO.getBuildList::", buildListResponse.toString());
		}
		catch (Exception e) {
			System.out.println("PERDO catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildListResponse Exception", e, "");
			throw new Exception();
		}
	}
	@Override
	public String toString() {
		return "PerDO [currentPhaseEndDateString=" + currentPhaseEndDateString
				+ ", managersToNotifyArray=" + Arrays.toString(managersToNotifyArray) + ", parNumber=" + parNumber
				+ ", perReceiptDateString=" + perReceiptDateString + ", projectComments=" + projectComments
				+ ", projectType=" + projectType + ", projectTypeName=" + projectTypeName + ", status=" + status
				+ ", scheduleCallDateString=" + scheduleCallDateString + ", cancellationDateString="
				+ cancellationDateString + ", currentScheduleEndDateString=" + currentScheduleEndDateString
				+ ", currentScheduleStartDateString=" + currentScheduleStartDateString + ", restartDateString="
				+ restartDateString + ", stopDateString=" + stopDateString + ", perChangeControl=" + perChangeControl
				+ ", perLoe=" + perLoe + ", purchaseOrderList=" + purchaseOrderList + ", perChangeControlList="
				+ perChangeControlList + ", description=" + description + "]";
	}
	
	
}
