package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.impl.PerServiceImpl;
import com.cg.eztrac.service.request.PerListRequest;
import com.cg.eztrac.service.response.PerListResponse;

public class RoleDO {
	
	private String CLASS_NAME = "RoleDO";
	private Integer roleId;
	private String roleName;
	List<RolePermissionDO> RolePermissionList = new ArrayList<RolePermissionDO>();
	
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public List<RolePermissionDO> getRolePermissionList() {
		return RolePermissionList;
	}
	public void setRolePermissionList(List<RolePermissionDO> rolePermissionList) {
		RolePermissionList = rolePermissionList;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public void getPerList(PerDO perDO, HttpSession httpSession) throws Exception {
		final String METHOD_NAME = "getPerList";
		System.out.println("Calling populatePerListRequest");
		//LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside RoleDO.getPerList:", populatePerListRequest(perDO).toString());
		
		PerServiceImpl perServiceImpl = new PerServiceImpl();
		PerListResponse perListResponse = null;
		try{
			perListResponse = perServiceImpl.getPerList(populatePerListRequest(perDO));
		}
		catch(Exception e){
			e.printStackTrace();
			throw new Exception();
		}
		//LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside RoleDO.getPerList::", perListResponse.toString());
		if(null != perListResponse ) {
			System.out.println("PerListResponse is not null and putting in session");
			httpSession.setAttribute("perListDO", perListResponse.getPerDetail());
			String responseCode= perListResponse.getResponseCode();
			String responseDescription=perListResponse.getResponseDescription();
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(responseCode, responseDescription);
			httpSession.setAttribute("responseMap", responseCodeMap);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside RoleDO.getPerList::"+ perListResponse.toString(), "");
	}
	public PerListRequest populatePerListRequest(PerDO perDO) {
		PerListRequest perListRequest = new PerListRequest();
		
		// Dozer Copy Bean Properties from Domain Object to Request Object 
		CommonUtility.copyBeanProperties(perDO, perListRequest);
		
		perListRequest.setChannel("EZ");
		perListRequest.setTokenId("test");
		perListRequest.setSubAccountId(1);
		
		LoggerManager.writeInfoLog(CLASS_NAME, "populatePerListRequest", "Inside RoleDO.perListRequest.toString()::"+ perListRequest.toString(), "");
		
		return perListRequest;
	}
}
