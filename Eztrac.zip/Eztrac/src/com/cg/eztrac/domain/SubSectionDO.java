package com.cg.eztrac.domain;

import java.io.Serializable;

public class SubSectionDO implements Serializable {
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 6423739005483390791L;
	private Integer subSectionID;
	private Integer subSectionType;
	private String subSectionName="";
	boolean elligbleFlag = false;
	
	
	public Integer getSubSectionID() {
		return subSectionID;
	}
	public void setSubSectionID(Integer subSectionID) {
		this.subSectionID = subSectionID;
	}
	public Integer getSubSectionType() {
		return subSectionType;
	}
	public void setSubSectionType(Integer subSectionType) {
		this.subSectionType = subSectionType;
	}
	public String getSubSectionName() {
		return subSectionName;
	}
	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}
	public boolean isElligbleFlag() {
		return elligbleFlag;
	}
	public void setElligbleFlag(boolean elligbleFlag) {
		this.elligbleFlag = elligbleFlag;
	}
	
}
