package com.cg.eztrac.domain;


import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.impl.BuildServiceImpl;
import com.cg.eztrac.service.request.BuildDetailsRequest;
import com.cg.eztrac.service.request.BuildInsertRequest;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.response.BuildDetailsResponse;
import com.cg.eztrac.service.response.BuildInsertResponse;

@Component(value="buildDO")
public class BuildDO extends EstimationDO {
	
	private static final String CLASS_NAME = BuildDO.class.getSimpleName();
	
	@Autowired
	BuildServiceImpl buildServiceImpl;
	
	@Autowired
	BuildDetailsRequest buildDetailsRequest;
	
	@Autowired
	BuildDetailsResponse buildDetailsResponse;
	
	@Autowired
	BuildInsertRequest buildInsertRequest; 
	
	@Autowired
	BuildInsertResponse buildInsertResponse; 
	
	//General - Fields - Build Module
	private Integer buildId;
	private Integer currentBuildPhase;
	private String currentBuildPhaseName;
	private String perPhaseName;
	private Integer onsiteLeverage;
	private Integer onsiteTimesheetLeverage;
	private Double phaseCompletion;
	private String cancelDateString;
	private Integer[] assignedToArray;
	private String[] assignedToArrayName;
	private String comments;
	
	private BuildChangeControlDO buildChangeControl;
	private BuildLoeDO buildLoe;
	
	private List<BuildChangeControlDO> buildChangeControlList;
	
	
	public Integer getBuildId() {
		return buildId;
	}

	public void setBuildId(Integer buildId) {
		this.buildId = buildId;
	}

	public Integer getCurrentBuildPhase() {
		return currentBuildPhase;
	}

	public void setCurrentBuildPhase(Integer currentBuildPhase) {
		this.currentBuildPhase = currentBuildPhase;
	}

	public String getCurrentBuildPhaseName() {
		return currentBuildPhaseName;
	}

	public void setCurrentBuildPhaseName(String currentBuildPhaseName) {
		this.currentBuildPhaseName = currentBuildPhaseName;
	}

	public String getPerPhaseName() {
		return perPhaseName;
	}

	public void setPerPhaseName(String perPhaseName) {
		this.perPhaseName = perPhaseName;
	}

	public Integer getOnsiteLeverage() {
		return onsiteLeverage;
	}

	public void setOnsiteLeverage(Integer onsiteLeverage) {
		this.onsiteLeverage = onsiteLeverage;
	}

	public Integer getOnsiteTimesheetLeverage() {
		return onsiteTimesheetLeverage;
	}

	public void setOnsiteTimesheetLeverage(Integer onsiteTimesheetLeverage) {
		this.onsiteTimesheetLeverage = onsiteTimesheetLeverage;
	}

	public Double getPhaseCompletion() {
		return phaseCompletion;
	}

	public void setPhaseCompletion(Double phaseCompletion) {
		this.phaseCompletion = phaseCompletion;
	}

	public String getCancelDateString() {
		return cancelDateString;
	}

	public void setCancelDateString(String cancelDateString) {
		this.cancelDateString = cancelDateString;
	}

	public Integer[] getAssignedToArray() {
		return assignedToArray;
	}

	public void setAssignedToArray(Integer[] assignedToArray) {
		this.assignedToArray = assignedToArray;
	}

	public String[] getAssignedToArrayName() {
		return assignedToArrayName;
	}

	public void setAssignedToArrayName(String[] assignedToArrayName) {
		this.assignedToArrayName = assignedToArrayName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public BuildChangeControlDO getBuildChangeControl() {
		return buildChangeControl;
	}

	public void setBuildChangeControl(BuildChangeControlDO buildChangeControl) {
		this.buildChangeControl = buildChangeControl;
	}

	public BuildLoeDO getBuildLoe() {
		return buildLoe;
	}

	public void setBuildLoe(BuildLoeDO buildLoe) {
		this.buildLoe = buildLoe;
	}

	public List<BuildChangeControlDO> getBuildChangeControlList() {
		return buildChangeControlList;
	}

	public void setBuildChangeControlList(List<BuildChangeControlDO> buildChangeControlList) {
		this.buildChangeControlList = buildChangeControlList;
	}

	public BuildInsertRequest populateBuildInsertRequest(BuildDO buildDO) {
		
		BuildInsertRequest buildInsertRequest = new BuildInsertRequest();
		// Dozer Copy Bean Properties from Domain Object to Request Object 
		CommonUtility.copyBeanProperties(buildDO, buildInsertRequest);
		buildInsertRequest.setTokenId("1234");
		buildInsertRequest.setChannelId("EZ");
		return buildInsertRequest;
	}
	
	private BuildDetailsRequest populateBuildDetailsRequest(BuildDO buildDO) {
		buildDetailsRequest.setBuildId(buildDO.getBuildId());
		buildDetailsRequest.setTokenId("1234");
		buildDetailsRequest.setChannelId("EZ");
		//buildDetailsRequest.setSystemId(buildDO.getSystemId());
		//buildDetailsRequest.setSubSystemId(buildDO.getSubSystemId());
		System.out.println("BuildDetails Request=========="+buildDetailsRequest);
		return buildDetailsRequest;
	}
	
	public void getBuildDetails(BuildDO buildDO, HttpSession httpSession) throws Exception {
		final String METHOD_NAME = "getBuildDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildDO.getBuildDetails:", populateBuildDetailsRequest(buildDO).toString());
		
		try {
			buildDetailsResponse = buildServiceImpl.getBuildDetails(populateBuildDetailsRequest(buildDO));
		}
		catch (Exception e) {
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "buildDetailsResponse Exception", e, "");
			throw new Exception();
		}
		
		if(null != buildDetailsResponse) {
			/*System.out.println(buildDetailsResponse.getBuild().getAssignedToArray());
			System.out.println(buildDetailsResponse.getBuild().getAssignedToArrayName());*/
			httpSession.setAttribute("buildDODetails",buildDetailsResponse.getBuild());
		}
	}
	
	public void insertBuildDetails(BuildDO buildDO, HttpSession httpSession) throws Exception {
		final String METHOD_NAME = "insertBuildDetails";
		BuildServiceImpl buildServiceImpl = new BuildServiceImpl();
		
		try {
			buildInsertResponse = buildServiceImpl.insertBuildDetails(populateBuildInsertRequest(buildDO));
		}
		catch (Exception e) {
			System.out.println("BuildDO - InsertBuildDetails Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "buildInsertResponse Exception", e, "");
			throw new Exception();
		}
		//String responseCode = buildInsertResponse.getResponseCode();
		//String responseDescription = buildInsertResponse.getResponseDescription();
		
		//Hardcoded 
		String responseCode = "200";
		String responseDescription = "Saved Successfully";
		Map<String, String> responseCodeMap=new HashMap<String, String>();
		responseCodeMap.put(responseCode, responseDescription);
		buildDO.setResponseMap(responseCodeMap);
		httpSession.setAttribute(ICommonConstants.BUILD_INSERT_RESPONSE,buildDO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildDO.insertBuildDetails:responseCode:", responseCode);
	}

	@Override
	public String toString() {
		return "BuildDO [buildServiceImpl=" + buildServiceImpl + ", buildDetailsRequest=" + buildDetailsRequest
				+ ", buildDetailsResponse=" + buildDetailsResponse + ", buildInsertRequest=" + buildInsertRequest
				+ ", buildInsertResponse=" + buildInsertResponse + ", buildId=" + buildId + ", currentBuildPhase="
				+ currentBuildPhase + ", currentBuildPhaseName=" + currentBuildPhaseName + ", perPhaseName="
				+ perPhaseName + ", onsiteLeverage=" + onsiteLeverage + ", onsiteTimesheetLeverage="
				+ onsiteTimesheetLeverage + ", phaseCompletion=" + phaseCompletion + ", cancelDateString="
				+ cancelDateString + ", assignedToArray=" + Arrays.toString(assignedToArray) + ", assignedToArrayName="
				+ Arrays.toString(assignedToArrayName) + ", comments=" + comments + ", buildChangeControl="
				+ buildChangeControl + ", buildLoe=" + buildLoe + ", buildChangeControlList=" + buildChangeControlList
				+ "]";
	}

}
