
$(document).ready(function(){
	
	/* START : To open and close the accordians */
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function() {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}
		}
	}
	/* END : To open and close the accordians */
	
	/* START : PO related script */
	$("#addNewPo").click(function() {
		$("#addPoDetailsDiv").show();
	});
	$("#savePoDetailsButton").click(function() {
		var newPoNumber=$("#newPoNumber").val();
		var newPoAmount=$("#newPoAmount").val();
		$("#poNumber").val(newPoNumber);
		$("#poAmount").val(newPoAmount);
		$("#addPoDetailsDiv").hide();
	});
	$("#cancelPoDetailsButton").click(function() {
		$("#addPoDetailsDiv").hide();
	});
	$("#listAllPo").click(function() {
		$("#listAllPoDiv").show();
	});
	$("#closePoListDiv").click(function() {
		$("#listAllPoDiv").hide();
	});
	/* END : PO related script */
	
	/* START : Picklist code for 'Managers to notify' */
	$("#addManager") .on( 'click', function() {
		var p = $("#managerPickList").find( "#managerToNotifyData option:selected");
		p.clone().appendTo("#managerToNotifyResult");
		p.remove();
	});

	$("#addAllManager").on( 'click', function() {
		var p = $("#managerPickList").find("#managerToNotifyData option");
		p.clone().appendTo("#managerToNotifyResult");
		p.remove();
	});

	$("#removeManager") .on( 'click',function() {
		var p = $("#managerPickList").find("#managerToNotifyResult option:selected");
		p.clone().appendTo("#managerToNotifyData");
		p.remove();
	});

	$("#removeAllManager").on('click',function() {
		var p = $("#managerPickList").find("#managerToNotifyResult option");
		p.clone().appendTo("#managerToNotifyData");
		p.remove();
	});
	/* END : Picklist code for 'Managers to notify' */
	
	/* START : To display list of builds table */
	$("#listOfbuildsLink").click(function() {
		$('#buildListTable').show();
	});

	$("#hideBuildListTable").click(function() {
		$('#buildListTable').hide();
	});

	/* END : To display list of builds table */
	
	/*START : Related to Modals*/
	// Get the modal
	var modal = document.getElementById('myModal');
	var modal1 = document.getElementById('myModal1');
	var modal2 = document.getElementById('myModal2');
	var modal3 = document.getElementById('myModal3');
	
	
	// Get the button that opens the modal
	var btn = document.getElementById("myBtn");
	var btn1 = document.getElementById("myBtn1");
	var btn2 = document.getElementById("myBtn2");
	var btn3 = document.getElementById("myBtn3");
	
	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];

	// When the user clicks the button, open the modal 
	btn.onclick = function() {
		modal.style.display = "block";
	}
	btn1.onclick = function() {
		modal1.style.display = "block";
	}
	btn2.onclick = function() {
		modal2.style.display = "block";
	}
	btn3.onclick = function() {
		modal3.style.display = "block";
	}

	

	$("#modal2close").click(function(){
		$('#myModal2').hide();
	});
	
	//When the user clicks on 'X' button - to close modal
	$("#modal3close").click(function(){
		$('#myModal3').hide();
	});
	
	$("#modalclose").click(function(){
		$('#myModal').hide();
	});
	
	$("#modal1close").click(function(){
		$('#myModal1').hide();
	});
	
	
	
	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		if (event.target == modal) {
			modal.style.display = "none";
		}
		if (event.target == modal1) {
			modal1.style.display = "none";
		}
		if (event.target == modal2) {
			modal2.style.display = "none";
		} 
		if (event.target == modal3) {
			modal3.style.display = "none";
		}  
		
	}
	
	/*END : Related to Modals*/
	
	/* START : Picklist code for 'Teams Involved' */
	/*$("#addTeam").on('click',function() {
		var p = $("#teamInvolvedPickList").find("#teamsInvolvedData option:selected");
		p.clone().appendTo("#teamsInvolvedResult");
		p.remove();
	});

	$("#addAllTeam").on('click',function() {
		var p = $("#teamInvolvedPickList").find("#teamsInvolvedData option");
		p.clone().appendTo("#teamsInvolvedResult");
		p.remove();
	});

	$("#removeTeam").on('click',function() {
		var p = $("#teamInvolvedPickList").find("#teamsInvolvedResult option:selected");
		p.clone().appendTo("#teamsInvolvedData");
		p.remove();
	});

	$("#removeAllTeam").on('click',function() {
		var p = $("#teamInvolvedPickList").find("#teamsInvolvedResult option");
		p.clone().appendTo("#teamsInvolvedData");
		p.remove();
	});*/
	/* END : Picklist code for 'Teams Involved' */
	
	/* START : Date Validation for Schedule Updates */
	$("#perForm").on('submit',function(e) {
			alert("Inside Form Validation");
			var successFlag = true;
			var scheduleCallDate = $('#scheduleCallDate').val();
			var cancellationDate = $('#cancellationDate').val();
			var currentScheduleStartDate = $('#currentScheduleStartDate').val();
			var currentScheduleEndDate = $('#currentScheduleEndDate').val();
			var stopDate = $('#stopDate').val();
			var restartDate = $('#restartDate').val();
			/************Schedule Dates*************/
			if(scheduleCallDate!=null && scheduleCallDate != "" && cancellationDate!=null && cancellationDate!="" && scheduleCallDate > cancellationDate){
				$("#cancellationDateError").text('Cancellation date should be after Scheduling call date.');
				successFlag = false;
			}
			else if(scheduleCallDate==null || scheduleCallDate == "" && cancellationDate!=null && cancellationDate!=""){
				$("#schedulingCallDateError").text('Current scheduled start date is required.');
				successFlag = false;
			}
			if(currentScheduleStartDate!=null && currentScheduleStartDate != "" && currentScheduleEndDate!=null && currentScheduleEndDate!="" && currentScheduleStartDate > currentScheduleEndDate){
				$("#currentScheduleEndDateError").text('Cancellation date should be after Scheduling call date.');
				successFlag = false;
			}
			else if(currentScheduleStartDate==null || currentScheduleStartDate == "" && currentScheduleEndDate!=null && currentScheduleEndDate!=""){
				$("#currentScheduleStartDateError").text('Current scheduled start date is required.');
				successFlag = false;
			}
			if(stopDate!=null && stopDate != "" && restartDate!=null && restartDate!="" && stopDate > restartDate){
				$("#restartDateError").text('Restart date should be after Stop date.');
				successFlag = false;
			}
			else if(stopDate==null || stopDate == "" && restartDate!=null && restartDate!=""){
				$("#stopDateError").text('Stop date is required.');
				successFlag = false;
			}
			/************PhaseTimelines*************/
			var actualReqStartDate = $('#actualReqStartDate').val();
			var actualReqEndDate = $('#actualReqEndDate').val();
			var actualDesignStartDate = $('#actualDesignStartDate').val();
			var actualDesignEndDate = $('#actualDesignEndDate').val();
			var actualConStartDate = $('#actualConStartDate').val();
			var actualConEndDate = $('#actualConEndDate').val();
			var actualTestingStartDate = $('#actualTestingStartDate').val();
			var actualTestingEndDate = $('#actualTestingEndDate').val();
			var actualReleaseStartDate = $('#actualReleaseStartDate').val();
			var actualReleaseEndDate = $('#actualReleaseEndDate').val();
			
			if(actualReqStartDate!=null && actualReqStartDate != "" && actualReqEndDate!=null && actualReqEndDate!="" && actualReqStartDate > actualReqEndDate){
				$("#actualReqEndDateError").text('Actual Requirement End Date should be after Actual Requirement Start Date.');
				successFlag = false;
			}
			else if(actualReqStartDate==null || actualReqStartDate == "" && actualReqEndDate!=null && actualReqEndDate!=""){
				$("#actualReqStartDateError").text('Actual Requirement Start Date is Required.');
				successFlag = false;
			}
			if(actualDesignStartDate!=null && actualDesignStartDate != "" && actualDesignEndDate!=null && actualDesignEndDate!="" && actualDesignStartDate > actualDesignEndDate){
				$("#actualDesignEndDateError").text('Actual Design End Date should be after Actual Design Start Date.');
				successFlag = false;
			}
			else if(actualDesignStartDate==null || actualDesignStartDate == "" && actualDesignEndDate!=null && actualDesignEndDate!=""){
				$("#actualDesignStartDateError").text('Actual Design Start Date is Required.');
				successFlag = false;
			}
			if(actualConStartDate!=null && actualConStartDate != "" && actualConEndDate!=null && actualConEndDate!="" && actualConStartDate > actualConEndDate){
				$("#actualConEndDateError").text('Actual Construction End Date should be after Actual Construction Start Date.');
				successFlag = false;
			}
			else if(actualConStartDate==null || actualConStartDate == "" && actualConEndDate!=null && actualConEndDate!=""){
				$("#actualConStartDateError").text('Actual Construction Start Date is Required.');
				successFlag = false;
			}
			if(actualTestingStartDate!=null && actualTestingStartDate != "" && actualTestingEndDate!=null && actualTestingEndDate!="" && actualTestingStartDate > actualTestingEndDate){
				$("#actualTestingEndDateError").text('Actual Testing End Date should be after Actual Testing Start Date.');
				successFlag = false;
			}
			else if(actualTestingStartDate==null || actualTestingStartDate == "" && actualTestingEndDate!=null && actualTestingEndDate!=""){
				$("#actualTestingStartDateError").text('Actual Testing Start Date is Required.');
				successFlag = false;
			}
			if(actualReleaseStartDate!=null && actualReleaseStartDate != "" && actualReleaseEndDate!=null && actualReleaseEndDate!="" && actualReleaseStartDate > actualReleaseEndDate){
				$("#actualReleaseEndDateError").text('Actual Release End Date should be after Actual Release Start Date.');
				successFlag = false;
			}
			else if(actualReleaseStartDate==null || actualReleaseStartDate == "" && actualReleaseEndDate!=null && actualReleaseEndDate!=""){
				$("#actualReleaseStartDateError").text('Actual Release Start Date is Required.');
				successFlag = false;
			}
			
			if (successFlag) {
				return true;
			} else {
				return false;
			}
			
		});
	/* END :  Date Validation for Schedule Updates */
	$("#attachmentSave").click(function(){
		alert("attachmentSave button Clicked");
		$.ajax({
			type : "POST",
			url : "/per_submit",
		});
		
	});
	
});
