/* ---------------------------------------------- /*
 * Preloader
 /* ---------------------------------------------- */
(function(){
	
    $(document).ready(function() {
    
    	if($(".custom-menu-ul").length){
    		buildCustomMenu();
    	}
    	
    	function buildCustomMenu(){
    		var customMenuVal = $("#customizeJsonMap").val();
    		//var customMenuVal ='{"11":[{"elligbleFlag":true,"sectionId":11,"sectionName":"Projects|PER","subSectionVO":[{"subSectionId":100,"subSectionName":"New","elligbleFlag":false},{"subSectionId":101,"subSectionName":"Edit","elligbleFlag":false},{"subSectionId":102,"subSectionName":"Upload","elligbleFlag":false}]}],"12":[{"elligbleFlag":true,"sectionId":12,"sectionName":"Projects|Build","subSectionVO":[{"subSectionId":103,"subSectionName":"New","elligbleFlag":false},{"subSectionId":104,"subSectionName":"Edit","elligbleFlag":false}]}],"13":[{"elligbleFlag":true,"sectionId":13,"sectionName":"Projects","subSectionVO":[{"subSectionId":105,"subSectionName":"Timesheet","elligbleFlag":false}]}]}';
//    		var customMenuVal ='{"11":[{"elligbleFlag":true,"sectionId":11,"sectionName":"Projects|PER","subSectionVO":[{"subSectionId":100,"subSectionName":"New","elligbleFlag":false},{"subSectionId":101,"subSectionName":"Edit","elligbleFlag":false},{"subSectionId":102,"subSectionName":"Upload","elligbleFlag":false}]}],"12":[{"elligbleFlag":true,"sectionId":12,"sectionName":"Projects|Build","subSectionVO":[{"subSectionId":103,"subSectionName":"New","elligbleFlag":false},{"subSectionId":104,"subSectionName":"Edit","elligbleFlag":false}]}],"13":[{"elligbleFlag":true,"sectionId":13,"sectionName":"Projects","subSectionVO":[{"subSectionId":105,"subSectionName":"Timesheet","elligbleFlag":false}]}],"14":[{"elligbleFlag":true,"sectionId":14,"sectionName":"Reports|Cards Services Report","subSectionVO":[{"subSectionId":106,"subSectionName":"Invoice Reports","elligbleFlag":false},{"subSectionId":107,"subSectionName":"Effort Variance Report","elligbleFlag":false}]}],"15":[{"elligbleFlag":true,"sectionId":15,"sectionName":"Reports|TimeSheet Reports","subSectionVO":[{"subSectionId":108,"subSectionName":" Missed Timesheet Reports","elligbleFlag":false},{"subSectionId":109,"subSectionName":"Timesheet Reports","elligbleFlag":false}]}],"16":[{"elligbleFlag":true,"sectionId":16,"sectionName":"Helpdesk","subSectionVO":[{"subSectionId":110,"subSectionName":"Log Request","elligbleFlag":false},{"subSectionId":111,"subSectionName":"Service Request","elligbleFlag":false}]}],"17":[{"elligbleFlag":true,"sectionId":17,"sectionName":"Administration","subSectionVO":[{"subSectionId":112,"subSectionName":"Users","elligbleFlag":false},{"subSectionId":113,"subSectionName":"System","elligbleFlag":false},{"subSectionId":114,"subSectionName":"Sub System","elligbleFlag":false}]}],"18":[{"elligbleFlag":true,"sectionId":18,"sectionName":"Finance And Business","subSectionVO":[{"subSectionId":115,"subSectionName":"Travel Expenses and Others","elligbleFlag":false}]}],"19":[{"elligbleFlag":true,"sectionId":19,"sectionName":"Invoice and Billing","subSectionVO":[{"subSectionId":116,"subSectionName":"Invoice Reports","elligbleFlag":false}]}]}';
//    		var customMenuVal ='{"11":[{"elligbleFlag":true,"sectionId":11,"sectionName":"Projects|PER","subSectionVO":[{"subSectionId":100,"subSectionName":"New","elligbleFlag":false},{"subSectionId":101,"subSectionName":"Edit","elligbleFlag":false},{"subSectionId":102,"subSectionName":"Upload","elligbleFlag":false}]}],"12":[{"elligbleFlag":true,"sectionId":12,"sectionName":"Projects|Build","subSectionVO":[{"subSectionId":103,"subSectionName":"New","elligbleFlag":false},{"subSectionId":104,"subSectionName":"Edit","elligbleFlag":false}]}]}';
    		var genericDropDownAnchor;
    		var genericDropDownLI  = $("<li>").addClass("dropdown");
    		var subSectionAnchor= $("<a>");
    		var genericDropDownMenuUL = $("<ul>").addClass("dropdown-menu");
    		var customMenuClass = ".custom-menu-ul";
    		
    		$.each(JSON.parse(customMenuVal), function(key, value) {
    			$.each(value, function(i) {
    				genericDropDownAnchor = $("<a/>").addClass("dropdown-toggle").attr({"data-toggle": "dropdown", "href": "#"});
    				genericDropDownLI  = $("<li>").addClass("dropdown");
    				console.log(value[i]);
    				var sectionVO = value[i];
    				var elligbleFlagSection = sectionVO.elligbleFlag, sectionId = sectionVO.sectionId, sectionName = sectionVO.sectionName;
    				var subSectionVOList = sectionVO.subSectionVO;
					if(sectionId==32){
						buildCustomSideBar(subSectionVOList);
					} else {
						if(elligbleFlagSection) {
	    					sectionNameArr = sectionName.split("|"); // projects|per
	    					var len = sectionNameArr.length;
	    					if(len>1) {
	    						var dropDownDownChr =true;
	    						var ULSubSection=$("<ul>").addClass("dropdown-menu");
	        					$.each(subSectionVOList, function(i) {
	        						var subSectionVO = subSectionVOList[i];
		        					var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
		        					var anchorClass = "";
		        					if(elligFlagSubSection){
		        						anchorClass = "form-submit-_-"+(sectionName.trim().replace(/\|/g, '_').replace(/\s/g, '_')+"_"+subSectionName.trim().replace(/\s/g, '_')).toUpperCase();
		        					} else {
		        						anchorClass = "disabled";
		        					}
		        					var anchorSubSection = $("<a>").addClass(anchorClass).attr({"th:href": "#", "href": "#"});
		        					var LISubSection  = $("<li>");
		        					anchorSubSection.text(subSectionName);
		        					LISubSection.append(anchorSubSection);
		        					ULSubSection.append(LISubSection);
	        					});
	        					genericDropDownAnchor.text(sectionNameArr[1]);
	        					genericDropDownLI.append(genericDropDownAnchor);
	        					genericDropDownLI.append(ULSubSection);
	        					$('[class*=" dropdown-menu_'+sectionNameArr[0].toUpperCase()+'"]').append(genericDropDownLI);
	        				} else if(len == 1){
	             				$.each(subSectionVOList, function(i) {
		             				var subSectionVO = subSectionVOList[i];
		        					var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
		        					var anchorClass = "";
		        					if(elligFlagSubSection){
		        						anchorClass = "form-submit-_-"+(sectionName.trim().replace(/\|/g, '_').replace(/\s/g, '_')+"_"+subSectionName.trim().replace(/\s/g, '_')).toUpperCase();
		        					} else {
		        						anchorClass = "disabled";
		        					}
		        					var anchorForSingleLevel1 = $("<a>").addClass(anchorClass).attr({"th:href": "#", "href": "#"});
		        					var genericDropDownLILevel1  = $("<li>").addClass("dropdown");
		        					anchorForSingleLevel1.text(subSectionName);
		        					genericDropDownLILevel1.prepend(anchorForSingleLevel1);
		        					$('[class*=" dropdown-menu_'+sectionName.toUpperCase().replace(/\s/g, '')+'"]').append(genericDropDownLILevel1);
	        					});
	        				}
	    				}
					}
    			});
    		});
    	}
    	
    	
    	function buildCustomSideBar(subSectionVOList){
			$.each(subSectionVOList, function(i) {
				var subSectionVO = subSectionVOList[i];
				var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
				var anchorSideBar = $("<a>").attr({"th:href": "#", "href": "#"});
				var genericSideBarLI  = $("<li>");
				var span=$("<span>");
				var spanClass="";
				if(subSectionName.toLowerCase()=="home"){
					spanClass="glyphicon glyphicon-home";
				} else if(subSectionName.trim().toLowerCase()=="my profile"){
					spanClass="fa fa-user-circle-o";
				} else if(subSectionName.toLowerCase()=="services"){
					spanClass="fa fa-thumbs-o-up";
				} else if(subSectionName.toLowerCase()=="about"){
					spanClass="glyphicon glyphicon-info-sign";
				} else if(subSectionName.toLowerCase()=="contact us"){
					spanClass="fa fa-phone";
				} else if(subSectionName.toLowerCase()=="change password"){
					spanClass="fa fa-pencil-square-o";
				} else if(subSectionName.toLowerCase()=="log out"){
					spanClass="fa fa-power-off";
				}
				span.addClass(spanClass).text(subSectionName);
				anchorSideBar.append(span);
				genericSideBarLI.append(anchorSideBar);
				$('[class*="side-menu-ul"]').append(genericSideBarLI);
			});
    	}
    	
    });
})(jQuery);
//{1 PMO={11=PROJECTS|PER$NEW#ENABLE,EDIT#ENABLE,UPLOAD#DISABLE,, 12=PROJECTS|BUILD$NEW#ENABLE,EDIT#ENABLE,, 13=PROJECTS|TIMESHEET,}}

