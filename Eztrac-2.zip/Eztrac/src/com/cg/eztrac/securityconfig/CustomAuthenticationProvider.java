package com.cg.eztrac.securityconfig;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cg.eztrac.handler.LoginHandler;
import com.cg.eztrac.vo.LoginVO;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String name = authentication.getName();
		String password = authentication.getCredentials().toString();
		// String password = "dummyapppass";

		// sign in service call
		authentication = authenticateUserSignInCallAuth(authentication.getName(), password, authentication);

		logger.info("Name = " + name + " ,Password = " + password);

		// use the credentials and authenticate against the third-party system
		if (authentication.isAuthenticated()) {
			logger.info("Login Success!");
			int i = 1 / 0;
			return authentication;
		}

		logger.info("Login fail!");

		return null;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

	public Authentication authenticateUserSignInCallAuth(String name, String password, Authentication authentication) {
		LoginHandler loginHelper = new LoginHandler();
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		LoginVO loginVO = new LoginVO();
		loginVO.setUserName(name);
		loginVO.setPassword(password);
		boolean signINFlag = true;
//		boolean signINFlag = loginHelper.callSignInService(loginVO, attr.getRequest().getSession(true));

		if (signINFlag) {
			logger.info("Succesful authentication!");

			// Roles Code Start
			List<SimpleGrantedAuthority> authorities = new ArrayList<>();
			if (name.equals("admin")) {
				authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
			} else if (name.equals("user")) {
				authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
			}

			authentication = new UsernamePasswordAuthenticationToken(name, null, authorities);
			// SecurityContextHolder.getContext().setAuthentication(authentication);
			// Roles code end

			return authentication;
		} else {
			return null;
		}
	}

}
