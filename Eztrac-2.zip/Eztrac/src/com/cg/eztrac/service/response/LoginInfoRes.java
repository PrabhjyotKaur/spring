package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;

public class LoginInfoRes implements IRestServiceResponse{
	private UserDetail userDedail;
	private HomePageData homePageData;
	private String responseDescription;
	private String responseCode;
	private List<RolePersmission> rolepermission;
	private String tokenId = "";
	private String channelId;
	
	
	public UserDetail getUserDedail() {
		return userDedail;
	}
	public void setUserDedail(UserDetail userDedail) {
		this.userDedail = userDedail;
	}
	public List<RolePersmission> getRolepermission() {
		return rolepermission;
	}
	public void setRolepermission(List<RolePersmission> rolepermission) {
		this.rolepermission = rolepermission;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public HomePageData getHomePageData() {
		return homePageData;
	}
	public void setHomePageData(HomePageData homePageData) {
		this.homePageData = homePageData;
	}

	@Override
	public String getTokenId() {
		return tokenId;
	}
	@Override
	public String getResponseCode() {
		return responseCode;
	}
	@Override
	public String getResponseDescription() {
		return responseDescription;
	}
	@Override
	public String getChannelId() {
		return channelId;
	}

}
