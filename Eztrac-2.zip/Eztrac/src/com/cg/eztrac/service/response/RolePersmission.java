package com.cg.eztrac.service.response;

public class RolePersmission {
	/** LOGIN SERVICE RESPONSE */
	Integer roleId;
	
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
}
