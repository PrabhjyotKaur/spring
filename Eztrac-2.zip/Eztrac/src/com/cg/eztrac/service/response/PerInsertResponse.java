package com.cg.eztrac.service.response;

import com.cg.eztrac.common.IRestServiceResponse;

public class PerInsertResponse implements IRestServiceResponse {
	
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	public String getTokenId() {
		return tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	
}
