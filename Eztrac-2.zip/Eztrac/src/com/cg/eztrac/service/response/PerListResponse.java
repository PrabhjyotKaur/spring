package com.cg.eztrac.service.response;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.PerDO;

@Component(value="perListResponse")
public class PerListResponse implements IRestServiceResponse {
	
	private List<PerDO> perDetail;
	
	private String tokenId;
	private String responsecCode;
	private String responseDesc;
	
	public List<PerDO> getPerDetail() {
		return perDetail;
	}
	public void setPerDetail(List<PerDO> perDetail) {
		this.perDetail = perDetail;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getResponsecCode() {
		return responsecCode;
	}
	public void setResponsecCode(String responsecCode) {
		this.responsecCode = responsecCode;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getResponseCode() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getResponseDescription() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toString() {
		return "PerListResponse [perDetail=" + perDetail + ", tokenId=" + tokenId + ", responsecCode=" + responsecCode
				+ ", responseDesc=" + responseDesc + "]";
	}
	
}
