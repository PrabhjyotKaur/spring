package com.cg.eztrac.service.impl;

/*
 * Hardcode values for authentication
 * 
 * */

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.eztrac.common.UserStatus;
import com.cg.eztrac.service.UserService;
import com.cg.eztrac.vo.RoleVO;
import com.cg.eztrac.vo.UserVO;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Override
	public UserVO findByUserName(String username) {
		if (username != null && username.equals("username")) {
			UserVO user1 = new UserVO();
			user1.setUsername("username");
			user1.setPassword("123456");
			user1.setStatus(UserStatus.ACTIVE);
			RoleVO role1 = new RoleVO();
			role1.setRolename("USER");
			List<RoleVO> roles1 = new ArrayList<RoleVO>();
			roles1.add(role1);
			user1.setRoles(roles1);
			return user1;
		} else {
			UserVO user2 = new UserVO();
			user2.setUsername("username1");
			user2.setPassword("123456");
			user2.setStatus(UserStatus.ACTIVE);
			RoleVO role2 = new RoleVO();
			role2.setRolename("ADMIN");
			List<RoleVO> roles2 = new ArrayList<RoleVO>();
			roles2.add(role2);
			user2.setRoles(roles2);
			return user2;
		}
	}
}
