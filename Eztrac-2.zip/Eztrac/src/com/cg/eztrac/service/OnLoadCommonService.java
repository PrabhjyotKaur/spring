package com.cg.eztrac.service;

import java.util.List;

import com.cg.eztrac.service.request.RolePermissionRequest;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.response.RoleDetails;
import com.cg.eztrac.service.response.SectionDetail;

public interface OnLoadCommonService {
	public List<SectionDetail> getAllSectionDetails(SectionDetailRequest sectionDetailRequest);
	public List<RoleDetails> getAllRolePermissionDetails(RolePermissionRequest rolePermissionRequest);
}
