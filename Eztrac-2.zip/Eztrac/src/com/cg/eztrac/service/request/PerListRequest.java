package com.cg.eztrac.service.request;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceRequest;

@Component(value="perListRequest")
public class PerListRequest implements IRestServiceRequest {

	private String currentPhase;
	private String perNumber;
	private int projectCoordinator;
	private int systemId;

	private String tokenId;
	private String channel;
	
	public String getCurrentPhase() {
		return currentPhase;
	}
	public void setCurrentPhase(String currentPhase) {
		this.currentPhase = currentPhase;
	}
	public String getPerNumber() {
		return perNumber;
	}
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	public int getProjectCoordinator() {
		return projectCoordinator;
	}
	public void setProjectCoordinator(int projectCoordinator) {
		this.projectCoordinator = projectCoordinator;
	}
	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toString() {
		return "PerListRequest [currentPhase=" + currentPhase + ", perNumber=" + perNumber + ", projectCoordinator="
				+ projectCoordinator + ", systemId=" + systemId + ", tokenId=" + tokenId + ", channel=" + channel
				+ "]";
	}
	
	
}
