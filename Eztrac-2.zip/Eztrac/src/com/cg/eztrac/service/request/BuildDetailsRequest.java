package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class BuildDetailsRequest implements IRestServiceRequest {
	
	private int buildId;
	private int systemId;
	private int subSystemId;
	
	private String tokenId;
	private String channelId;
	
	public int getBuildId() {
		return buildId;
	}
	public void setBuildId(int buildId) {
		this.buildId = buildId;
	}
	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}
	public int getSubSystemId() {
		return subSystemId;
	}
	public void setSubSystemId(int subSystemId) {
		this.subSystemId = subSystemId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
}
