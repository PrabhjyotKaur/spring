package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class BuildListRequest implements IRestServiceRequest {
	
	private String perNumber;
	private int subSystemId;
	private int projectCoordinator;
	private String buildPhase;
	
	private String tokenId;
	private String channelId;
	
	public String getPerNumber() {
		return perNumber;
	}
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	public int getSubSystemId() {
		return subSystemId;
	}
	public void setSubSystemId(int subSystemId) {
		this.subSystemId = subSystemId;
	}
	public int getProjectCoordinator() {
		return projectCoordinator;
	}
	public void setProjectCoordinator(int projectCoordinator) {
		this.projectCoordinator = projectCoordinator;
	}
	public String getBuildPhase() {
		return buildPhase;
	}
	public void setBuildPhase(String buildPhase) {
		this.buildPhase = buildPhase;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
}
