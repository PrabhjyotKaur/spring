package com.cg.eztrac.service.domainobject;

import java.util.ArrayList;
import java.util.List;

public class RoleDO {

	private Integer roleId;
	private String rolename;
	List<RolePermissionDO> RolePermissionList = new ArrayList<RolePermissionDO>();
	
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public List<RolePermissionDO> getRolePermissionList() {
		return RolePermissionList;
	}
	public void setRolePermissionList(List<RolePermissionDO> rolePermissionList) {
		RolePermissionList = rolePermissionList;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	
}
