package com.cg.eztrac.service.domainobject;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.response.SectionDetail;
import com.google.gson.Gson;

public class SectionDetailDO implements IRestServiceRequest{
	String className=SectionDetailDO.class.getSimpleName();
	private String tokenId = "";
	private String channelId = "";
	private int subAccounId;
	private int sectionID;
	private String sectionName = "";
	private String sectionType = "";
	private List<SubSectionDO> subSection = new ArrayList<SubSectionDO>();
	
	public int getSectionID() {
		return sectionID;
	}
	public void setSectionID(int sectionID) {
		this.sectionID = sectionID;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public String getSectionType() {
		return sectionType;
	}
	public void setSectionType(String sectionType) {
		this.sectionType = sectionType;
	}
	
	public List<SubSectionDO> getSubSection() {
		return subSection;
	}
	public void setSubSection(List<SubSectionDO> subSection) {
		this.subSection = subSection;
	}
	public String getTokenId() {
		return tokenId;
	}
	public int getSubAccounId() {
		return subAccounId;
	}
	public void setSubAccounId(int subAccounId) {
		this.subAccounId = subAccounId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	public List<SectionDetailDO> callSectionDetailService(SectionDetailDO sectionDetailDO) {
		String methodName="callSectionDetailService";
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In sectionDetailDO", "Before populating the sectionRequest from DO");
		SectionDetailRequest sectionDetailRequest  = populateSectionRequestFromDO( sectionDetailDO );
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In sectionDetailDO", "Details are populated into sectionDetailRequest");
		OnLoadCommonService sectionDetailService = new OnLoadCommonServiceImpl();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In sectionDetailDO", "Before calling the getAllSectionDetails() to get sectionDetailResponseList ");
		List<SectionDetail> sectionDetailResponseList = sectionDetailService.getAllSectionDetails(sectionDetailRequest);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In sectionDetailDO", " getAllSectionDetails() is called and  got sectionDetailResponseList");
		List<SectionDetailDO> sectionDetails = populateResponseToDO(sectionDetailResponseList);
		return sectionDetails;
	}
	
	private List<SectionDetailDO> populateResponseToDO(List<SectionDetail> sectionDetailResponseList) {
		String methodName="populateResponseToDO";
		List<SectionDetailDO> sectionDetails = new ArrayList<SectionDetailDO>(sectionDetailResponseList.size());
		try {
			SectionDetailDO sectionDetailDO = null;
			Gson gson = new Gson();
			for (int i=0;i<sectionDetailResponseList.size();i++){
				sectionDetailDO = new SectionDetailDO();
				String sectionDetailDOJson = gson.toJson( sectionDetailResponseList.get(i));
				sectionDetailDO = gson.fromJson(sectionDetailDOJson, SectionDetailDO.class);
				sectionDetails.add(sectionDetailDO);
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In sectionDetailDO", "Setting SectionDetailDo from SectoinDetailResponse");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return sectionDetails;
	}
	
	private SectionDetailRequest populateSectionRequestFromDO(SectionDetailDO sectionDetailDO) {
		String methodName="populateSectionRequestFromDO";
		SectionDetailRequest sectionDetailRequest = new SectionDetailRequest();
		sectionDetailRequest.setSubAccountId(sectionDetailDO.getSubAccounId());
		sectionDetailRequest.setTokenId(CommonUtility.getTokenId());
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In sectionDetailDO", "Setting SectionDetail Request from SectionDetailDO");
		return sectionDetailRequest;
	}
	
}
