package com.cg.eztrac.service.domainobject;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.RolePermissionRequest;
import com.cg.eztrac.service.response.RoleDetails;
import com.google.gson.Gson;

public class RolePermissionDO implements IRestServiceResponse{
	String className=RolePermissionDO.class.getSimpleName();
	private int roleId;
	private String roleName;
	
	List<SectionDetailDO> sections = new ArrayList<SectionDetailDO>();
	private String tokenId = "";
	private String responseCode = "";
	private String responseDescription = "";
	private String channelId;
	
	@Override
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	/**
	 * @return the responseDescription
	 */
	public String getResponseDescription() {
		return responseDescription;
	}
	/**
	 * @param responseDescription the responseDescription to set
	 */
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}

	
	public List<SectionDetailDO> getSections() {
		return sections;
	}
	public void setSections(List<SectionDetailDO> sections) {
		this.sections = sections;
	}
	public List<RolePermissionDO> callRolePermissionService() {
		String methodName="callRolePermissionService";
		RolePermissionRequest rolePermissionRequest = populateRoleRequestFromDO();
		OnLoadCommonService onLoadCommonService = new OnLoadCommonServiceImpl();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In RolePermissionDO", "Before calling getAllRolePermissionDetails()");
		List<RoleDetails> rolePermissionList = onLoadCommonService.getAllRolePermissionDetails(rolePermissionRequest);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In RolePermissionDO", "After calling getAllRolePermissionDetails()and receiving  all rolePermissionList");
		List<RolePermissionDO> roleResponseDOList = populateResponseToDO(rolePermissionList);
		return roleResponseDOList;
	}
	
	private List<RolePermissionDO> populateResponseToDO(List<RoleDetails> rolePermissionResponseList) {
		String methodName="populateResponseToDO";
		List<RolePermissionDO> rolePermissionDOList = new ArrayList<RolePermissionDO>(rolePermissionResponseList.size());
		RolePermissionDO rolePermissionDO = new RolePermissionDO();
		Gson gson = new Gson();
		for (int i=0;i<rolePermissionResponseList.size();i++){
			rolePermissionDO = new RolePermissionDO();
			String rolePermissionJson = gson.toJson( rolePermissionResponseList.get(i));
			rolePermissionDO = gson.fromJson(rolePermissionJson, RolePermissionDO.class);
			rolePermissionDOList.add(rolePermissionDO);
		}
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In RolePermissionDO", "RolePermissionResponse populated to DO");
		return rolePermissionDOList;
	}
	
	private RolePermissionRequest populateRoleRequestFromDO() {
		String methodName="populateRoleRequestFromDO";
		RolePermissionRequest rolePermissionRequest = new RolePermissionRequest();
		rolePermissionRequest.setSubAccountId(1);
		rolePermissionRequest.setTokenId(CommonUtility.getTokenId());
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In RolePermissionDO", " RolePermissionRequest populated from DO");
		return rolePermissionRequest;
	}
	
}
