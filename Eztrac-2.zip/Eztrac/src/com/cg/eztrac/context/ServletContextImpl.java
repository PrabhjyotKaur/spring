package com.cg.eztrac.context;

import javax.servlet.ServletContext;

import org.springframework.stereotype.Component;
import org.springframework.web.context.ServletContextAware;

@Component
public class ServletContextImpl implements ServletContextAware {
	private ServletContext servletContext;

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public boolean addObjectToServletContext(String addAttribute, Object attribute) {
		servletContext.setAttribute(addAttribute, attribute);
		return true;
	}

	public Object getObjectFromServletContext(String getAttribute) {
		Object attribute = null;
		try {
			attribute = servletContext.getAttribute(getAttribute);
		} catch (Exception e) {
			// TODO: logger
			attribute = null;
		}	
		return attribute;
	}

}
