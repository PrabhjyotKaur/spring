package com.cg.eztrac.domain;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.impl.BuildServiceImpl;
import com.cg.eztrac.service.request.BuildInsertRequest;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.response.BuildInsertResponse;

public class BuildDO extends EstimationDO {
	
	private static final String CLASS_NAME = BuildDO.class.getSimpleName();
	
	//General - Fields - Build Module
	private String system;
	private String subSystem;
	private String currentBuildPhase;
	private String onsiteLeverage;
	private String onsiteTimesheetLeverage;
	private double phaseCompletion;
	private Date cancelDate;
	private String[] assignedToArray;
	private int subAccountId;
	
	private BuildChangeControlDO buildChangeControlDO;
	private BuildLoeDO buildLoeDO;
	
	private List<BuildChangeControlDO> buildChangeControlDOList;
	
	//lists to populate dropdowns
	private List<String> perNumberList;
	private List<String> systemList;
	private List<String> subSystemList;
	private List<String> currentBuildPhaseList;
	private List<String> assignedToList;
	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getSubSystem() {
		return subSystem;
	}
	public void setSubSystem(String subSystem) {
		this.subSystem = subSystem;
	}
	public String getCurrentBuildPhase() {
		return currentBuildPhase;
	}
	public void setCurrentBuildPhase(String currentBuildPhase) {
		this.currentBuildPhase = currentBuildPhase;
	}
	public String getOnsiteLeverage() {
		return onsiteLeverage;
	}
	public void setOnsiteLeverage(String onsiteLeverage) {
		this.onsiteLeverage = onsiteLeverage;
	}
	public String getOnsiteTimesheetLeverage() {
		return onsiteTimesheetLeverage;
	}
	public void setOnsiteTimesheetLeverage(String onsiteTimesheetLeverage) {
		this.onsiteTimesheetLeverage = onsiteTimesheetLeverage;
	}
	public double getPhaseCompletion() {
		return phaseCompletion;
	}
	public void setPhaseCompletion(double phaseCompletion) {
		this.phaseCompletion = phaseCompletion;
	}
	public Date getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String[] getAssignedToArray() {
		return assignedToArray;
	}
	public void setAssignedToArray(String[] assignedToArray) {
		this.assignedToArray = assignedToArray;
	}
	public int getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	public BuildChangeControlDO getBuildChangeControlDO() {
		return buildChangeControlDO;
	}
	public void setBuildChangeControlDO(BuildChangeControlDO buildChangeControlDO) {
		this.buildChangeControlDO = buildChangeControlDO;
	}
	public BuildLoeDO getBuildLoeDO() {
		return buildLoeDO;
	}
	public void setBuildLoeDO(BuildLoeDO buildLoeDO) {
		this.buildLoeDO = buildLoeDO;
	}
	public List<BuildChangeControlDO> getBuildChangeControlDOList() {
		return buildChangeControlDOList;
	}
	public void setBuildChangeControlDOList(List<BuildChangeControlDO> buildChangeControlDOList) {
		this.buildChangeControlDOList = buildChangeControlDOList;
	}
	public List<String> getPerNumberList() {
		return perNumberList;
	}
	public void setPerNumberList(List<String> perNumberList) {
		this.perNumberList = perNumberList;
	}
	public List<String> getSystemList() {
		return systemList;
	}
	public void setSystemList(List<String> systemList) {
		this.systemList = systemList;
	}
	public List<String> getSubSystemList() {
		return subSystemList;
	}
	public void setSubSystemList(List<String> subSystemList) {
		this.subSystemList = subSystemList;
	}
	public List<String> getCurrentBuildPhaseList() {
		return currentBuildPhaseList;
	}
	public void setCurrentBuildPhaseList(List<String> currentBuildPhaseList) {
		this.currentBuildPhaseList = currentBuildPhaseList;
	}
	public List<String> getAssignedToList() {
		return assignedToList;
	}
	public void setAssignedToList(List<String> assignedToList) {
		this.assignedToList = assignedToList;
	}
	
	public void insertBuildDetails(BuildDO buildDO) throws Exception {
		final String METHOD_NAME = "insertBuildDetails";
		BuildServiceImpl buildServiceImpl = new BuildServiceImpl();
		BuildInsertResponse buildInsertResponse = buildServiceImpl.insertBuildDetails(populateBuildInsertRequest(buildDO));
		String responseCode = buildInsertResponse.getResponseCode();
		String responseDescription = buildInsertResponse.getResponseDescription();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.buildSubmit:responseCode:", responseCode);
	}
	
	public BuildListRequest populateBuildListRequest(BuildDO buildDO) {
		BuildListRequest buildListRequest = new BuildListRequest();
		buildListRequest.setPerNumber(buildDO.getPerNumber());
		buildListRequest.setProjectCoordinator(buildDO.getProjectCoordinator());
		buildListRequest.setBuildPhase(buildDO.getCurrentBuildPhase());
		//buildListRequest.setSubSystemId(subSystemId);
		//buildListRequest.setTokenId(tokenId);
		//buildListRequest.setChannelId(channelId);
		return buildListRequest;
	}
	
	public BuildInsertRequest populateBuildInsertRequest(BuildDO buildDO) {
		BuildInsertRequest buildInsertRequest = new BuildInsertRequest();
		buildInsertRequest.setBuildDO(buildDO);
		//buildInsertRequest.setTokenId(tokenId);
		//buildInsertRequest.setChannelId(channelId);
		return buildInsertRequest;
	}
	
	@Override
	public String toString() {
		return "BuildDO [system=" + system + ", subSystem=" + subSystem + ", currentBuildPhase=" + currentBuildPhase
				+ ", onsiteLeverage=" + onsiteLeverage + ", onsiteTimesheetLeverage=" + onsiteTimesheetLeverage
				+ ", phaseCompletion=" + phaseCompletion + ", cancelDate=" + cancelDate + ", assignedToArray="
				+ Arrays.toString(assignedToArray) + ", subAccountId=" + subAccountId + ", buildChangeControlDO="
				+ buildChangeControlDO + ", buildLoeDO=" + buildLoeDO + ", buildChangeControlDOList="
				+ buildChangeControlDOList + ", perNumberList=" + perNumberList + ", systemList=" + systemList
				+ ", subSystemList=" + subSystemList + ", currentBuildPhaseList=" + currentBuildPhaseList
				+ ", assignedToList=" + assignedToList + "]";
	}
	
}
