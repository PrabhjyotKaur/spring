package com.cg.eztrac.domain;

import java.util.Date;

public class CommentDO {
	
	private String comment;
	private String commentBy;
	private Date commentOn;
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getCommentBy() {
		return commentBy;
	}
	public void setCommentBy(String commentBy) {
		this.commentBy = commentBy;
	}
	public Date getCommentOn() {
		return commentOn;
	}
	public void setCommentOn(Date commentOn) {
		this.commentOn = commentOn;
	}
	
	@Override
	public String toString() {
		return "CommentDO [comment=" + comment + ", commentBy=" + commentBy + ", commentOn=" + commentOn + "]";
	}
	
}
