package com.cg.eztrac.domain;

import java.util.Date;
import java.util.List;

public class EstimationDO {

	// General - Fields - Common for Per and Build Modules
	private int perId;
	private String perNumber;
	private String perDescription;
	private String projectHealth;
	private String comments;
	private int projectCoordinator;
	private String projectCoordinatorName;

	private String createdBy;
	private Date createdOn;
	private String lastModifiedBy;
	private Date lastModifiedOn;

	private PhaseTimelinesDO phaseTimelinesDO;

	private AttachmentDO attachmentDO;
	private CommentDO commentDO;
	private NotificationDO notificationDO;

	private List<AttachmentDO> attachmentDOList;
	private List<CommentDO> commentDOList;
	private List<NotificationDO> notificationDOList;

	// lists to populate dropdowns
	private List<String> projectHealthList;

	public int getPerId() {
		return perId;
	}

	public void setPerId(int perId) {
		this.perId = perId;
	}

	public String getPerNumber() {
		return perNumber;
	}

	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}

	public String getPerDescription() {
		return perDescription;
	}

	public void setPerDescription(String perDescription) {
		this.perDescription = perDescription;
	}

	public String getProjectHealth() {
		return projectHealth;
	}

	public void setProjectHealth(String projectHealth) {
		this.projectHealth = projectHealth;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getProjectCoordinator() {
		return projectCoordinator;
	}

	public void setProjectCoordinator(int projectCoordinator) {
		this.projectCoordinator = projectCoordinator;
	}

	public String getProjectCoordinatorName() {
		return projectCoordinatorName;
	}

	public void setProjectCoordinatorName(String projectCoordinatorName) {
		this.projectCoordinatorName = projectCoordinatorName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedOn() {
		return lastModifiedOn;
	}

	public void setLastModifiedOn(Date lastModifiedOn) {
		this.lastModifiedOn = lastModifiedOn;
	}

	public PhaseTimelinesDO getPhaseTimelinesDO() {
		return phaseTimelinesDO;
	}

	public void setPhaseTimelinesDO(PhaseTimelinesDO phaseTimelinesDO) {
		this.phaseTimelinesDO = phaseTimelinesDO;
	}

	public AttachmentDO getAttachmentDO() {
		return attachmentDO;
	}

	public void setAttachmentDO(AttachmentDO attachmentDO) {
		this.attachmentDO = attachmentDO;
	}

	public CommentDO getCommentDO() {
		return commentDO;
	}

	public void setCommentDO(CommentDO commentDO) {
		this.commentDO = commentDO;
	}

	public NotificationDO getNotificationDO() {
		return notificationDO;
	}

	public void setNotificationDO(NotificationDO notificationDO) {
		this.notificationDO = notificationDO;
	}

	public List<AttachmentDO> getAttachmentDOList() {
		return attachmentDOList;
	}

	public void setAttachmentDOList(List<AttachmentDO> attachmentDOList) {
		this.attachmentDOList = attachmentDOList;
	}

	public List<CommentDO> getCommentDOList() {
		return commentDOList;
	}

	public void setCommentDOList(List<CommentDO> commentDOList) {
		this.commentDOList = commentDOList;
	}

	public List<NotificationDO> getNotificationDOList() {
		return notificationDOList;
	}

	public void setNotificationDOList(List<NotificationDO> notificationDOList) {
		this.notificationDOList = notificationDOList;
	}

	public List<String> getProjectHealthList() {
		return projectHealthList;
	}

	public void setProjectHealthList(List<String> projectHealthList) {
		this.projectHealthList = projectHealthList;
	}
	
	@Override
	public String toString() {
		return "EstimationDO [perId=" + perId + ", perNumber=" + perNumber + ", perDescription=" + perDescription
				+ ", projectHealth=" + projectHealth + ", comments=" + comments + ", projectCoordinator="
				+ projectCoordinator + ", projectCoordinatorName=" + projectCoordinatorName + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", lastModifiedBy=" + lastModifiedBy + ", lastModifiedOn="
				+ lastModifiedOn + ", phaseTimelinesDO=" + phaseTimelinesDO + ", attachmentDO=" + attachmentDO
				+ ", commentDO=" + commentDO + ", notificationDO=" + notificationDO + ", attachmentDOList="
				+ attachmentDOList + ", commentDOList=" + commentDOList + ", notificationDOList=" + notificationDOList
				+ ", projectHealthList=" + projectHealthList + "]";
	}
	
}
