package com.cg.eztrac.domain;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.impl.PerServiceImpl;
import com.cg.eztrac.service.request.PerInsertRequest;
import com.cg.eztrac.service.request.PerListRequest;
import com.cg.eztrac.service.response.PerInsertResponse;
import com.cg.eztrac.service.response.PerListResponse;

@Component(value="perDO")
public class PerDO extends EstimationDO {
	
	private static final String CLASS_NAME = PerDO.class.getSimpleName();
	
	@Autowired
	PerServiceImpl perServiceImpl;
	
	@Autowired
	PerListRequest perListRequest;
	
	@Autowired
	PerListResponse perListResponse;
	
	//General - Fields - Per Module
	private int currentPhase;
	private String currentPhaseName;
	private Date currentPhaseEndDate;
	private String[] managersToNotifyArray;
	private String parNumber;
	private Date perReceiptDate;
	private String projectComments;
	private String projectType;
	private String status;
	
	private String gePM;
	private int systemId;
	private String systemName;
	
	//Schedule Updates - Fields - Per Module
	private Date scheduleCallDate;
	private Date cancellationDate;
	private Date currentScheduleEndDate;
	private Date currentScheduleStartDate;
	private Date restartDate;
	private Date stopDate;
	
	private PurchaseOrderDO purchaseOrderDO;
	private PerChangeControlDO perChangeControlDO;
	private PerLoeDO perLoeDO;
	
	private List<PurchaseOrderDO> purchaseOrderDOList;
	private List<PerChangeControlDO> perChangeControlDOList;
	
	private String description; //TODO - Remove this - Temp added
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getCurrentPhase() {
		return currentPhase;
	}
	public void setCurrentPhase(int currentPhase) {
		this.currentPhase = currentPhase;
	}
	public String getCurrentPhaseName() {
		return currentPhaseName;
	}
	public void setCurrentPhaseName(String currentPhaseName) {
		this.currentPhaseName = currentPhaseName;
	}
	public Date getCurrentPhaseEndDate() {
		return currentPhaseEndDate;
	}
	public void setCurrentPhaseEndDate(Date currentPhaseEndDate) {
		this.currentPhaseEndDate = currentPhaseEndDate;
	}
	public String[] getManagersToNotifyArray() {
		return managersToNotifyArray;
	}
	public void setManagersToNotifyArray(String[] managersToNotifyArray) {
		this.managersToNotifyArray = managersToNotifyArray;
	}
	public String getParNumber() {
		return parNumber;
	}
	public void setParNumber(String parNumber) {
		this.parNumber = parNumber;
	}
	public Date getPerReceiptDate() {
		return perReceiptDate;
	}
	public void setPerReceiptDate(Date perReceiptDate) {
		this.perReceiptDate = perReceiptDate;
	}
	public String getProjectComments() {
		return projectComments;
	}
	public void setProjectComments(String projectComments) {
		this.projectComments = projectComments;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGePM() {
		return gePM;
	}
	public void setGePM(String gePM) {
		this.gePM = gePM;
	}
	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public Date getScheduleCallDate() {
		return scheduleCallDate;
	}
	public void setScheduleCallDate(Date scheduleCallDate) {
		this.scheduleCallDate = scheduleCallDate;
	}
	public Date getCancellationDate() {
		return cancellationDate;
	}
	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}
	public Date getCurrentScheduleEndDate() {
		return currentScheduleEndDate;
	}
	public void setCurrentScheduleEndDate(Date currentScheduleEndDate) {
		this.currentScheduleEndDate = currentScheduleEndDate;
	}
	public Date getCurrentScheduleStartDate() {
		return currentScheduleStartDate;
	}
	public void setCurrentScheduleStartDate(Date currentScheduleStartDate) {
		this.currentScheduleStartDate = currentScheduleStartDate;
	}
	public Date getRestartDate() {
		return restartDate;
	}
	public void setRestartDate(Date restartDate) {
		this.restartDate = restartDate;
	}
	public Date getStopDate() {
		return stopDate;
	}
	public void setStopDate(Date stopDate) {
		this.stopDate = stopDate;
	}
	public PurchaseOrderDO getPurchaseOrderDO() {
		return purchaseOrderDO;
	}
	public void setPurchaseOrderDO(PurchaseOrderDO purchaseOrderDO) {
		this.purchaseOrderDO = purchaseOrderDO;
	}
	public PerChangeControlDO getPerChangeControlDO() {
		return perChangeControlDO;
	}
	public void setPerChangeControlDO(PerChangeControlDO perChangeControlDO) {
		this.perChangeControlDO = perChangeControlDO;
	}
	public PerLoeDO getPerLoeDO() {
		return perLoeDO;
	}
	public void setPerLoeDO(PerLoeDO perLoeDO) {
		this.perLoeDO = perLoeDO;
	}
	public List<PurchaseOrderDO> getPurchaseOrderDOList() {
		return purchaseOrderDOList;
	}
	public void setPurchaseOrderDOList(List<PurchaseOrderDO> purchaseOrderDOList) {
		this.purchaseOrderDOList = purchaseOrderDOList;
	}
	public List<PerChangeControlDO> getPerChangeControlDOList() {
		return perChangeControlDOList;
	}
	public void setPerChangeControlDOList(List<PerChangeControlDO> perChangeControlDOList) {
		this.perChangeControlDOList = perChangeControlDOList;
	}
	
	public void getPerList(PerDO perDO) throws Exception {
		final String METHOD_NAME = "getPerList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.getPerList:", populatePerListRequest(perDO).toString());
		perListResponse = perServiceImpl.getPerList(populatePerListRequest(perDO));
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.getPerList::", perListResponse.toString());
	}
	
	public void insertPerDetails(PerDO perDO) throws Exception {
		final String METHOD_NAME = "insertPerDetails";
		PerInsertResponse perInsertResponse = perServiceImpl.insertPerDetails(populatePerInsertRequest(perDO));
		String responseCode = perInsertResponse.getResponseCode();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.insertPerDetails:responseCode::", responseCode);
	}
	
	public PerListRequest populatePerListRequest(PerDO perDO) {
		perListRequest.setPerNumber(perDO.getPerNumber());
		//TODO - CurrentPhase to be an int
		perListRequest.setCurrentPhase(perDO.getCurrentPhase() + "");
		perListRequest.setProjectCoordinator(perDO.getProjectCoordinator());
		perListRequest.setSystemId(perDO.getSystemId());
		//perListRequest.setTokenId(tokenId);
		//perListRequest.setChannelId(channelId);
		perListRequest.setTokenId("test");
		//perListRequest.setChannelId("EZ");
		perListRequest.setChannel("EZ");
		return perListRequest;
	}
	
	public PerInsertRequest populatePerInsertRequest(PerDO perDO) {
		PerInsertRequest perInsertRequest = new PerInsertRequest();
		perInsertRequest.setPerDO(perDO);
		//perInsertRequest.setTokenId(tokenId);
		//perInsertRequest.setChannelId(channelId);
		return perInsertRequest;
	}
	
	@Override
	public String toString() {
		return "PerDO [perServiceImpl=" + perServiceImpl + ", perListRequest=" + perListRequest + ", perListResponse="
				+ perListResponse + ", currentPhase=" + currentPhase + ", currentPhaseName=" + currentPhaseName
				+ ", currentPhaseEndDate=" + currentPhaseEndDate + ", managersToNotifyArray="
				+ Arrays.toString(managersToNotifyArray) + ", parNumber=" + parNumber + ", perReceiptDate="
				+ perReceiptDate + ", projectComments=" + projectComments + ", projectType=" + projectType + ", status="
				+ status + ", gePM=" + gePM + ", systemId=" + systemId + ", systemName=" + systemName
				+ ", scheduleCallDate=" + scheduleCallDate + ", cancellationDate=" + cancellationDate
				+ ", currentScheduleEndDate=" + currentScheduleEndDate + ", currentScheduleStartDate="
				+ currentScheduleStartDate + ", restartDate=" + restartDate + ", stopDate=" + stopDate
				+ ", purchaseOrderDO=" + purchaseOrderDO + ", perChangeControlDO=" + perChangeControlDO + ", perLoeDO="
				+ perLoeDO + ", purchaseOrderDOList=" + purchaseOrderDOList + ", perChangeControlDOList="
				+ perChangeControlDOList + ", description=" + description + ", getPerId()=" + getPerId()
				+ ", getPerNumber()=" + getPerNumber() + ", getPerDescription()=" + getPerDescription()
				+ ", getProjectHealth()=" + getProjectHealth() + ", getComments()=" + getComments()
				+ ", getProjectCoordinator()=" + getProjectCoordinator() + ", getProjectCoordinatorName()="
				+ getProjectCoordinatorName() + ", getCreatedBy()=" + getCreatedBy() + ", getCreatedOn()="
				+ getCreatedOn() + ", getLastModifiedBy()=" + getLastModifiedBy() + ", getLastModifiedOn()="
				+ getLastModifiedOn() + ", getPhaseTimelinesDO()=" + getPhaseTimelinesDO() + ", getAttachmentDO()="
				+ getAttachmentDO() + ", getCommentDO()=" + getCommentDO() + ", getNotificationDO()="
				+ getNotificationDO() + ", getAttachmentDOList()=" + getAttachmentDOList() + ", getCommentDOList()="
				+ getCommentDOList() + ", getNotificationDOList()=" + getNotificationDOList()
				+ ", getProjectHealthList()=" + getProjectHealthList() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
}
