package com.cg.eztrac.domain;

import java.util.Date;

public class ChangeControlDO {
	
	private int ccId;
	private String ccNumber;
	private String ccCategoryId;
	private String ccPhase;
	private Date ccStartDate;
	private Date ccEndDate;
	private String ccDescription;
	
	private String ccCreatedBy;
	private Date ccCreatedOn;
	private String ccLastModifiedBy;
	private Date ccLastModifiedOn;
	
	public int getCcId() {
		return ccId;
	}
	public void setCcId(int ccId) {
		this.ccId = ccId;
	}
	public String getCcNumber() {
		return ccNumber;
	}
	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}
	public String getCcCategoryId() {
		return ccCategoryId;
	}
	public void setCcCategoryId(String ccCategoryId) {
		this.ccCategoryId = ccCategoryId;
	}
	public String getCcPhase() {
		return ccPhase;
	}
	public void setCcPhase(String ccPhase) {
		this.ccPhase = ccPhase;
	}
	public Date getCcStartDate() {
		return ccStartDate;
	}
	public void setCcStartDate(Date ccStartDate) {
		this.ccStartDate = ccStartDate;
	}
	public Date getCcEndDate() {
		return ccEndDate;
	}
	public void setCcEndDate(Date ccEndDate) {
		this.ccEndDate = ccEndDate;
	}
	public String getCcDescription() {
		return ccDescription;
	}
	public void setCcDescription(String ccDescription) {
		this.ccDescription = ccDescription;
	}
	public String getCcCreatedBy() {
		return ccCreatedBy;
	}
	public void setCcCreatedBy(String ccCreatedBy) {
		this.ccCreatedBy = ccCreatedBy;
	}
	public Date getCcCreatedOn() {
		return ccCreatedOn;
	}
	public void setCcCreatedOn(Date ccCreatedOn) {
		this.ccCreatedOn = ccCreatedOn;
	}
	public String getCcLastModifiedBy() {
		return ccLastModifiedBy;
	}
	public void setCcLastModifiedBy(String ccLastModifiedBy) {
		this.ccLastModifiedBy = ccLastModifiedBy;
	}
	public Date getCcLastModifiedOn() {
		return ccLastModifiedOn;
	}
	public void setCcLastModifiedOn(Date ccLastModifiedOn) {
		this.ccLastModifiedOn = ccLastModifiedOn;
	}
	
	@Override
	public String toString() {
		return "ChangeControlDO [ccId=" + ccId + ", ccNumber=" + ccNumber + ", ccCategoryId=" + ccCategoryId
				+ ", ccPhase=" + ccPhase + ", ccStartDate=" + ccStartDate + ", ccEndDate=" + ccEndDate
				+ ", ccDescription=" + ccDescription + ", ccCreatedBy=" + ccCreatedBy + ", ccCreatedOn=" + ccCreatedOn
				+ ", ccLastModifiedBy=" + ccLastModifiedBy + ", ccLastModifiedOn=" + ccLastModifiedOn + "]";
	}
	
}
