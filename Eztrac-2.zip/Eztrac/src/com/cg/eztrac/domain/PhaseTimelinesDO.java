package com.cg.eztrac.domain;

import java.util.Date;

public class PhaseTimelinesDO {
	
	private Date plannedReqEndDate;
	private Date plannedReqStartDate;
	private Date plannedDesignEndDate;
	private Date plannedDesignStartDate;
	private Date plannedConEndDate;
	private Date plannedConStartDate;
	private Date plannedTestingEndDate;
	private Date plannedTestingStartDate;
	private Date plannedReleaseEndDate;
	private Date plannedReleaseStartDate;
	
	private Date actualReqEndDate;
	private Date actualReqStartDate;
	private Date actualDesignEndDate;
	private Date actualDesignStartDate;
	private Date actualConEndDate;
	private Date actualConStartDate;
	private Date actualTestingEndDate;
	private Date actualTestingStartDate;
	private Date actualReleaseEndDate;
	private Date actualReleaseStartDate;
	
	public Date getPlannedReqEndDate() {
		return plannedReqEndDate;
	}
	public void setPlannedReqEndDate(Date plannedReqEndDate) {
		this.plannedReqEndDate = plannedReqEndDate;
	}
	public Date getPlannedReqStartDate() {
		return plannedReqStartDate;
	}
	public void setPlannedReqStartDate(Date plannedReqStartDate) {
		this.plannedReqStartDate = plannedReqStartDate;
	}
	public Date getPlannedDesignEndDate() {
		return plannedDesignEndDate;
	}
	public void setPlannedDesignEndDate(Date plannedDesignEndDate) {
		this.plannedDesignEndDate = plannedDesignEndDate;
	}
	public Date getPlannedDesignStartDate() {
		return plannedDesignStartDate;
	}
	public void setPlannedDesignStartDate(Date plannedDesignStartDate) {
		this.plannedDesignStartDate = plannedDesignStartDate;
	}
	public Date getPlannedConEndDate() {
		return plannedConEndDate;
	}
	public void setPlannedConEndDate(Date plannedConEndDate) {
		this.plannedConEndDate = plannedConEndDate;
	}
	public Date getPlannedConStartDate() {
		return plannedConStartDate;
	}
	public void setPlannedConStartDate(Date plannedConStartDate) {
		this.plannedConStartDate = plannedConStartDate;
	}
	public Date getPlannedTestingEndDate() {
		return plannedTestingEndDate;
	}
	public void setPlannedTestingEndDate(Date plannedTestingEndDate) {
		this.plannedTestingEndDate = plannedTestingEndDate;
	}
	public Date getPlannedTestingStartDate() {
		return plannedTestingStartDate;
	}
	public void setPlannedTestingStartDate(Date plannedTestingStartDate) {
		this.plannedTestingStartDate = plannedTestingStartDate;
	}
	public Date getPlannedReleaseEndDate() {
		return plannedReleaseEndDate;
	}
	public void setPlannedReleaseEndDate(Date plannedReleaseEndDate) {
		this.plannedReleaseEndDate = plannedReleaseEndDate;
	}
	public Date getPlannedReleaseStartDate() {
		return plannedReleaseStartDate;
	}
	public void setPlannedReleaseStartDate(Date plannedReleaseStartDate) {
		this.plannedReleaseStartDate = plannedReleaseStartDate;
	}
	public Date getActualReqEndDate() {
		return actualReqEndDate;
	}
	public void setActualReqEndDate(Date actualReqEndDate) {
		this.actualReqEndDate = actualReqEndDate;
	}
	public Date getActualReqStartDate() {
		return actualReqStartDate;
	}
	public void setActualReqStartDate(Date actualReqStartDate) {
		this.actualReqStartDate = actualReqStartDate;
	}
	public Date getActualDesignEndDate() {
		return actualDesignEndDate;
	}
	public void setActualDesignEndDate(Date actualDesignEndDate) {
		this.actualDesignEndDate = actualDesignEndDate;
	}
	public Date getActualDesignStartDate() {
		return actualDesignStartDate;
	}
	public void setActualDesignStartDate(Date actualDesignStartDate) {
		this.actualDesignStartDate = actualDesignStartDate;
	}
	public Date getActualConEndDate() {
		return actualConEndDate;
	}
	public void setActualConEndDate(Date actualConEndDate) {
		this.actualConEndDate = actualConEndDate;
	}
	public Date getActualConStartDate() {
		return actualConStartDate;
	}
	public void setActualConStartDate(Date actualConStartDate) {
		this.actualConStartDate = actualConStartDate;
	}
	public Date getActualTestingEndDate() {
		return actualTestingEndDate;
	}
	public void setActualTestingEndDate(Date actualTestingEndDate) {
		this.actualTestingEndDate = actualTestingEndDate;
	}
	public Date getActualTestingStartDate() {
		return actualTestingStartDate;
	}
	public void setActualTestingStartDate(Date actualTestingStartDate) {
		this.actualTestingStartDate = actualTestingStartDate;
	}
	public Date getActualReleaseEndDate() {
		return actualReleaseEndDate;
	}
	public void setActualReleaseEndDate(Date actualReleaseEndDate) {
		this.actualReleaseEndDate = actualReleaseEndDate;
	}
	public Date getActualReleaseStartDate() {
		return actualReleaseStartDate;
	}
	public void setActualReleaseStartDate(Date actualReleaseStartDate) {
		this.actualReleaseStartDate = actualReleaseStartDate;
	}
	
	@Override
	public String toString() {
		return "PhaseTimelinesDO [plannedReqEndDate=" + plannedReqEndDate + ", plannedReqStartDate="
				+ plannedReqStartDate + ", plannedDesignEndDate=" + plannedDesignEndDate + ", plannedDesignStartDate="
				+ plannedDesignStartDate + ", plannedConEndDate=" + plannedConEndDate + ", plannedConStartDate="
				+ plannedConStartDate + ", plannedTestingEndDate=" + plannedTestingEndDate
				+ ", plannedTestingStartDate=" + plannedTestingStartDate + ", plannedReleaseEndDate="
				+ plannedReleaseEndDate + ", plannedReleaseStartDate=" + plannedReleaseStartDate + ", actualReqEndDate="
				+ actualReqEndDate + ", actualReqStartDate=" + actualReqStartDate + ", actualDesignEndDate="
				+ actualDesignEndDate + ", actualDesignStartDate=" + actualDesignStartDate + ", actualConEndDate="
				+ actualConEndDate + ", actualConStartDate=" + actualConStartDate + ", actualTestingEndDate="
				+ actualTestingEndDate + ", actualTestingStartDate=" + actualTestingStartDate
				+ ", actualReleaseEndDate=" + actualReleaseEndDate + ", actualReleaseStartDate="
				+ actualReleaseStartDate + "]";
	}
	
}
