package com.cg.eztrac.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;

public class CommonInterceptor extends HandlerInterceptorAdapter {
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		HttpSession session = request.getSession();
		session.setAttribute(ICommonConstants.TOKEN_ID_STR, CommonUtility.getTokenId());
		// TOOD: logger
		return true;
	}
}
