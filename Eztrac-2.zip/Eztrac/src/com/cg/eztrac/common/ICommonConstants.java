package com.cg.eztrac.common;

public interface ICommonConstants {

	String STRING_TRUE = "true";
	String STRING_FALSE = "false";
	
	String PIPE_SEPARATOR="|";
	
	String loginService = "loginWS_URL";
	String USERDETAILS = "UserDetails";
	String ROLEPERMISSION = "RolePermission";
	String ALL_SUB_SEC_DETAILS_STR = "AllSubSectionDetails";
	String ALL_SEC_DETAILS_STR = "allSectionDetails";
	String ALL_SEC_DETAILS_CONTEXT = "ALL_SEC_DETAILS_SERVICE";
	String ALL_ROLE_DETAILS_CONTEXT = "ALL_ROLE_DETAILS_SERVICE";
	String All_ROLE_MENU_ACCESS_CONTEXT="All_ROLE_MENU_ACCESSIBILITY";
	String DISABLE_STR = "DISABLE";
	String ENABLE_STR = "ENABLE";
	String LOGIN_SERVICE_LOG_KEY = " - LOGINFLOW - ";
	String BUILD_SERVICE_LOG_KEY = "BUILDFLOW";
	String PER_SERVICE_LOG_KEY = "PERFLOW";
	
	String PER_PERNEW_RESTRICTION_PATTERN = "Per~PerNew~";
	String PER_PEREDIT_RESTRICTION_PATTERN = "Per~PerEdit~";
	
	String BUILD_BUILDNEW_RESTRICTION_PATTERN = "Build~BuildNew~";
	String BUILD_BUILDEDIT_RESTRICTION_PATTERN = "Build~BuildEdit~";
	String TOKEN_ID_STR = "TOKEN_ID";
	
}

