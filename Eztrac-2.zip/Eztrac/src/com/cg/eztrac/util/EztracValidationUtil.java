package com.cg.eztrac.util;

import java.util.Date;
import java.util.regex.Pattern;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

public class EztracValidationUtil {
	
	private static final String CLASS_NAME = "EztracValidationUtil";
	
	public static void rejectValue(Errors errors, String fieldName, String fieldErrorMessage) {
		errors.rejectValue(fieldName, fieldErrorMessage);
	}

	public static void rejectIfEmptyOrWhitespace(Errors errors, String fieldName, String fieldErrorMessage) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, fieldName, fieldErrorMessage);
	}
	
	public static void rejectIfLengthMismatch(Errors errors, String fieldName, String fieldErrorMessage, int fieldLength, int requiredLength) {
		if(fieldLength != requiredLength) {
			rejectValue(errors, fieldName, fieldErrorMessage);
		}
	}
	
	public static void rejectIfMinMaxLengthMismatch(Errors errors, String fieldName, String fieldErrorMessage, int fieldLength, int requiredMinLength, int requiredMaxLength) {
		if(fieldLength < requiredMinLength || fieldLength > requiredMaxLength) {
			rejectValue(errors, fieldName, fieldErrorMessage);
		}
	}
	
	public static void rejectIfPatternMismatch(Errors errors, String fieldName, String fieldErrorMessage, String fieldValue, String requiredPattern) {
		Pattern pattern = Pattern.compile(requiredPattern);
		if(!pattern.matcher(fieldValue).matches()) {
			rejectValue(errors, fieldName, fieldErrorMessage);
		}
	}
	
	public static void rejectIfDateComparisonFails(Errors errors, String fieldName, String fieldErrorMessage, Date dateField1, Date dateField2) {
		if(!StringUtils.isEmpty(dateField1) && !StringUtils.isEmpty(dateField2) && dateField2.before(dateField1)) {
			rejectValue(errors, fieldName, fieldErrorMessage);
		}
	}
	
}
