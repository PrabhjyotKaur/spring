package com.cg.eztrac.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.handler.PerHandler;
import com.cg.eztrac.validator.PerValidator;
import com.cg.eztrac.vo.PerVO;

/*
 * @Author Vamshi
 * */
@Controller
public class PerController {
	
	private static final String CLASS_NAME = "PerController";
	
	private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	
	@Autowired
	PerValidator perValidator;
	
	@Autowired
	PerHandler perHandler;
	
	@RequestMapping(value = "/per_new", method = RequestMethod.GET)
	public ModelAndView perNew() {
		final String METHOD_NAME = "perNew";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, METHOD_NAME, METHOD_NAME);
		
		PerVO perVo = new PerVO();
		
		perVo.setPerNumber("PR123456");
		
		List<String> currentPerPhaseList = new ArrayList<String>();
		currentPerPhaseList.add("Requirement");
		currentPerPhaseList.add("Design");
		currentPerPhaseList.add("Construction");
		currentPerPhaseList.add("Testing");
		currentPerPhaseList.add("Release");

		perVo.setCurrentPerPhaseList(currentPerPhaseList);
		
		String restrictionPattern = ICommonConstants.PER_PERNEW_RESTRICTION_PATTERN;
		
		//TODO - Below Logic to be replaced from getAllSubSectionList details that we receive from Login Service Starts
		String perEditRestrictionPattern = ICommonConstants.PER_PEREDIT_RESTRICTION_PATTERN;
		String buildNewRestrictionPattern = ICommonConstants.BUILD_BUILDNEW_RESTRICTION_PATTERN;
		String buildEditRestrictionPattern = ICommonConstants.BUILD_BUILDEDIT_RESTRICTION_PATTERN;
		
		List<String> allSubSectionNameList = new ArrayList<String>();
		allSubSectionNameList.add(restrictionPattern+"perNumber");
		allSubSectionNameList.add(restrictionPattern+"currentPhaseName");
		allSubSectionNameList.add(buildNewRestrictionPattern+"perNumber");
		allSubSectionNameList.add(buildNewRestrictionPattern+"currentPhaseName");
		allSubSectionNameList.add(buildEditRestrictionPattern+"perNumber");
		allSubSectionNameList.add(buildEditRestrictionPattern+"currentPhaseName");
		allSubSectionNameList.add(perEditRestrictionPattern+"perNumber");
		allSubSectionNameList.add(perEditRestrictionPattern+"currentPhaseName");
		//TODO - Below Logic to be replaced from getAllSubSectionList details that we receive from Login Service Ends
		
		//RestrictionMatrix Logic for UI
		Map<String, String> restrictionMatrixMap = CommonUtility.getRestrictionMatrixMap(allSubSectionNameList, restrictionPattern);
		perVo.setRestrictionMatrixMap(restrictionMatrixMap);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "perNumber:"+perVo.getRestrictionMatrixMap().get("perNumber")+":", "");
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "currentPhase:"+perVo.getRestrictionMatrixMap().get("currentPhase")+":", "");
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "parNum:"+perVo.getRestrictionMatrixMap().get("parNum")+":", "");
		
		ModelAndView mav = new ModelAndView("per");
		mav.addObject("perVo", perVo);
		return mav;
	}
	
	@RequestMapping(value = "/per_submit", method = RequestMethod.POST)
	public ModelAndView perSubmit(@ModelAttribute("perVo") @Valid PerVO perVo, BindingResult result) throws Exception {
		final String METHOD_NAME = "perSubmit";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, METHOD_NAME, METHOD_NAME);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, perVo.toString(), "Inside PerController.perSubmit:");
		
		//ConvertStringToDateFields
		convertStringToDateFields(perVo);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, perVo.toString(), "Inside PerController.perSubmit::");
		
		//Invoke Validator for Server Side Validations
		perValidator.validate(perVo, result);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, result.hasErrors()+"", "Inside PerController.perSubmit:::");
		
		ModelAndView mav = new ModelAndView("per");
		
		if(!result.hasErrors()) {
			//Invoke Handler
			perHandler.insertPerDetails(perVo);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerController.perSubmit:", "");
			
			mav.addObject("perVo", perVo);
		} else {
			mav.addObject("perVo", perVo);
		}
		
		return mav;
	}
	
	@RequestMapping(value = "/per_edit", method = RequestMethod.GET)
	public ModelAndView perEdit(@ModelAttribute("perVO") PerVO perVO) {
		ModelAndView mav = new ModelAndView("perList");
		return mav;
	}
	
	@RequestMapping(value = "/per_details", method = RequestMethod.POST)
	public ModelAndView perDetails(@ModelAttribute("perVo") PerVO perVo) {
		ModelAndView mav = new ModelAndView("perChangeControl");
		return mav;
	}
	
	@RequestMapping(value = "/per_cc", method = RequestMethod.GET)
	public ModelAndView perChangeControl() {
		PerVO perVo = new PerVO();
		ModelAndView mav = new ModelAndView("perChangeControl");
		mav.addObject("perVO", perVo);
		return mav;
	}
	
	@RequestMapping(value = "/per_list", method = RequestMethod.GET)
	public ModelAndView perList(@ModelAttribute("perVo") @Valid PerVO perVo, BindingResult result) throws Exception {
		final String METHOD_NAME = "perList";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerController.perList:", perVo.toString());
		
		//Invoke Validator for Server Side Validations
		//perValidator.validate(perVo, result);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerController.perList:result.hasErrors():", result.hasErrors()+"");
		
		ModelAndView mav = new ModelAndView("per");
		
		if(!result.hasErrors()) {
			//Invoke Handler
			
			//TODO - To Be Removed
			//{"perNumber":"PR001122","projectCoordinator":"1000","systemId":1,"currentPhase":"12","tokenId":"test","channel":"EZ"}
			//Problem 1: currentPhase as String in request and int in response
			//Problem 2: channel in few places and channelId in fewPlaces - need to follow one approach
			//Problem 3: projectCoordinator as String in request and int in response
			
			perVo.setPerNumber("PR001122");
			perVo.setProjectCoordinator("1000");
			perVo.setSystemId(1);
			perVo.setCurrentPhase(12);
			
			perHandler.getPerList(perVo);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerController.perList:", perVo.toString());
			
			mav.addObject("perVo", perVo);
		} else {
			mav.addObject("perVo", perVo);
		}
		
		return mav;
	}
	
	private void convertStringToDateFields(PerVO perVo) {
		if(!StringUtils.isEmpty(perVo.getScheduleCallDateString())){
			perVo.setScheduleCallDate(CommonUtility.getDateFromString(perVo.getScheduleCallDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCancellationDateString())){
			perVo.setCancellationDate(CommonUtility.getDateFromString(perVo.getCancellationDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleStartDateString())){
			perVo.setCurrentScheduleStartDate(CommonUtility.getDateFromString(perVo.getCurrentScheduleStartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getCurrentScheduleEndDateString())){
			perVo.setCurrentScheduleEndDate(CommonUtility.getDateFromString(perVo.getCurrentScheduleEndDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getStopDateString())){
			perVo.setStopDate(CommonUtility.getDateFromString(perVo.getStopDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
		if(!StringUtils.isEmpty(perVo.getRestartDateString())){
			perVo.setRestartDate(CommonUtility.getDateFromString(perVo.getRestartDateString(), DATE_FORMAT_YYYY_MM_DD));
		}
	}
	
}
