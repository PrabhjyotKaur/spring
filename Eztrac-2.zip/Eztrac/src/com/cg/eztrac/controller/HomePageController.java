package com.cg.eztrac.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.handler.HomePageHandler;
import com.cg.eztrac.vo.HomePageVO;

@Controller
public class HomePageController {
	
	@RequestMapping(value = {"/switchRole" }, method = RequestMethod.POST)
	public Model buildRoleBasedHome(ModelAndView mv,@ModelAttribute HomePageVO homePageVO, Model model) {
		homePageVO.getRoleId();
		HomePageHandler homePageHandler = new HomePageHandler();
//		homePageVO = homePageHandler.switchRoleMenuHandler(homePageVO);
		model.addAttribute(homePageVO);
		return model;
	}
}
