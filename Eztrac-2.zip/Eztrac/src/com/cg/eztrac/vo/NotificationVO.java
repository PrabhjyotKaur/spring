package com.cg.eztrac.vo;

import java.util.Date;

public class NotificationVO {
	
	private int notifyId;
	private int notifyTypeId;
	private String from;
	private String to;
	private String cc;
	private String subject;
	private String body;
	private String createdBy;
	private String createdOnString;
	private Date createdOn;
	
	public int getNotifyId() {
		return notifyId;
	}
	public void setNotifyId(int notifyId) {
		this.notifyId = notifyId;
	}
	public int getNotifyTypeId() {
		return notifyTypeId;
	}
	public void setNotifyTypeId(int notifyTypeId) {
		this.notifyTypeId = notifyTypeId;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getCc() {
		return cc;
	}
	public void setCc(String cc) {
		this.cc = cc;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOnString() {
		return createdOnString;
	}
	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	@Override
	public String toString() {
		return "NotificationVO [notifyId=" + notifyId + ", notifyTypeId=" + notifyTypeId + ", from=" + from + ", to="
				+ to + ", cc=" + cc + ", subject=" + subject + ", body=" + body + ", createdBy=" + createdBy
				+ ", createdOnString=" + createdOnString + ", createdOn=" + createdOn + "]";
	}
	
}
