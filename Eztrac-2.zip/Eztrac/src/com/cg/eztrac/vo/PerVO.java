package com.cg.eztrac.vo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class PerVO extends EstimationVO {
	
	//General - Fields - Per Module
	private int currentPhase;
	private String currentPhaseName;
	private String currentPhaseEndDateString;
	private Date currentPhaseEndDate;
	private String[] managersToNotifyArray;
	private String parNumber;
	private String perReceiptDateString;
	private Date perReceiptDate;
	private String projectComments;
	
	private String projectType;
	private String status;
	
	private String gePM;
	private int systemId;
	private String systemName;
	
	//Schedule Updates - Fields - Per Module
	private String scheduleCallDateString;
	private Date scheduleCallDate;
	private String cancellationDateString;
	private Date cancellationDate;
	private String currentScheduleEndDateString;
	private Date currentScheduleEndDate;
	private String currentScheduleStartDateString;
	private Date currentScheduleStartDate;
	private String restartDateString;
	private Date restartDate;
	private String stopDateString;
	private Date stopDate;
	
	private PurchaseOrderVO purchaseOrderVO;
	private PerChangeControlVO perChangeControlVO;
	private PerLoeVO perLoeVO;
	
	private List<PurchaseOrderVO> purchaseOrderVOList;
	private List<PerChangeControlVO> perChangeControlVOList;
	
	//lists to populate dropdowns
	private List<String> currentPerPhaseList;
	private Map<String, String> restrictionMatrixMap;
	
	public int getCurrentPhase() {
		return currentPhase;
	}
	public void setCurrentPhase(int currentPhase) {
		this.currentPhase = currentPhase;
	}
	public String getCurrentPhaseName() {
		return currentPhaseName;
	}
	public void setCurrentPhaseName(String currentPhaseName) {
		this.currentPhaseName = currentPhaseName;
	}
	public String getCurrentPhaseEndDateString() {
		return currentPhaseEndDateString;
	}
	public void setCurrentPhaseEndDateString(String currentPhaseEndDateString) {
		this.currentPhaseEndDateString = currentPhaseEndDateString;
	}
	public Date getCurrentPhaseEndDate() {
		return currentPhaseEndDate;
	}
	public void setCurrentPhaseEndDate(Date currentPhaseEndDate) {
		this.currentPhaseEndDate = currentPhaseEndDate;
	}
	public String[] getManagersToNotifyArray() {
		return managersToNotifyArray;
	}
	public void setManagersToNotifyArray(String[] managersToNotifyArray) {
		this.managersToNotifyArray = managersToNotifyArray;
	}
	public String getParNumber() {
		return parNumber;
	}
	public void setParNumber(String parNumber) {
		this.parNumber = parNumber;
	}
	public String getPerReceiptDateString() {
		return perReceiptDateString;
	}
	public void setPerReceiptDateString(String perReceiptDateString) {
		this.perReceiptDateString = perReceiptDateString;
	}
	public Date getPerReceiptDate() {
		return perReceiptDate;
	}
	public void setPerReceiptDate(Date perReceiptDate) {
		this.perReceiptDate = perReceiptDate;
	}
	public String getProjectComments() {
		return projectComments;
	}
	public void setProjectComments(String projectComments) {
		this.projectComments = projectComments;
	}
	
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGePM() {
		return gePM;
	}
	public void setGePM(String gePM) {
		this.gePM = gePM;
	}
	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getScheduleCallDateString() {
		return scheduleCallDateString;
	}
	public void setScheduleCallDateString(String scheduleCallDateString) {
		this.scheduleCallDateString = scheduleCallDateString;
	}
	public Date getScheduleCallDate() {
		return scheduleCallDate;
	}
	public void setScheduleCallDate(Date scheduleCallDate) {
		this.scheduleCallDate = scheduleCallDate;
	}
	public String getCancellationDateString() {
		return cancellationDateString;
	}
	public void setCancellationDateString(String cancellationDateString) {
		this.cancellationDateString = cancellationDateString;
	}
	public Date getCancellationDate() {
		return cancellationDate;
	}
	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}
	public String getCurrentScheduleEndDateString() {
		return currentScheduleEndDateString;
	}
	public void setCurrentScheduleEndDateString(String currentScheduleEndDateString) {
		this.currentScheduleEndDateString = currentScheduleEndDateString;
	}
	public Date getCurrentScheduleEndDate() {
		return currentScheduleEndDate;
	}
	public void setCurrentScheduleEndDate(Date currentScheduleEndDate) {
		this.currentScheduleEndDate = currentScheduleEndDate;
	}
	public String getCurrentScheduleStartDateString() {
		return currentScheduleStartDateString;
	}
	public void setCurrentScheduleStartDateString(String currentScheduleStartDateString) {
		this.currentScheduleStartDateString = currentScheduleStartDateString;
	}
	public Date getCurrentScheduleStartDate() {
		return currentScheduleStartDate;
	}
	public void setCurrentScheduleStartDate(Date currentScheduleStartDate) {
		this.currentScheduleStartDate = currentScheduleStartDate;
	}
	public String getRestartDateString() {
		return restartDateString;
	}
	public void setRestartDateString(String restartDateString) {
		this.restartDateString = restartDateString;
	}
	public Date getRestartDate() {
		return restartDate;
	}
	public void setRestartDate(Date restartDate) {
		this.restartDate = restartDate;
	}
	public String getStopDateString() {
		return stopDateString;
	}
	public void setStopDateString(String stopDateString) {
		this.stopDateString = stopDateString;
	}
	public Date getStopDate() {
		return stopDate;
	}
	public void setStopDate(Date stopDate) {
		this.stopDate = stopDate;
	}
	public PurchaseOrderVO getPurchaseOrderVO() {
		return purchaseOrderVO;
	}
	public void setPurchaseOrderVO(PurchaseOrderVO purchaseOrderVO) {
		this.purchaseOrderVO = purchaseOrderVO;
	}
	public PerChangeControlVO getPerChangeControlVO() {
		return perChangeControlVO;
	}
	public void setPerChangeControlVO(PerChangeControlVO perChangeControlVO) {
		this.perChangeControlVO = perChangeControlVO;
	}
	public PerLoeVO getPerLoeVO() {
		return perLoeVO;
	}
	public void setPerLoeVO(PerLoeVO perLoeVO) {
		this.perLoeVO = perLoeVO;
	}
	public List<PurchaseOrderVO> getPurchaseOrderVOList() {
		return purchaseOrderVOList;
	}
	public void setPurchaseOrderVOList(List<PurchaseOrderVO> purchaseOrderVOList) {
		this.purchaseOrderVOList = purchaseOrderVOList;
	}
	public List<PerChangeControlVO> getPerChangeControlVOList() {
		return perChangeControlVOList;
	}
	public void setPerChangeControlVOList(List<PerChangeControlVO> perChangeControlVOList) {
		this.perChangeControlVOList = perChangeControlVOList;
	}
	public List<String> getCurrentPerPhaseList() {
		return currentPerPhaseList;
	}
	public void setCurrentPerPhaseList(List<String> currentPerPhaseList) {
		this.currentPerPhaseList = currentPerPhaseList;
	}
	public Map<String, String> getRestrictionMatrixMap() {
		return restrictionMatrixMap;
	}
	public void setRestrictionMatrixMap(Map<String, String> restrictionMatrixMap) {
		this.restrictionMatrixMap = restrictionMatrixMap;
	}
	
	@Override
	public String toString() {
		return "PerVO [currentPhase=" + currentPhase + ", currentPhaseName=" + currentPhaseName
				+ ", currentPhaseEndDateString=" + currentPhaseEndDateString + ", currentPhaseEndDate="
				+ currentPhaseEndDate + ", managersToNotifyArray=" + Arrays.toString(managersToNotifyArray)
				+ ", parNumber=" + parNumber + ", perReceiptDateString=" + perReceiptDateString + ", perReceiptDate="
				+ perReceiptDate + ", projectComments=" + projectComments + ", projectType=" + projectType + ", status="
				+ status + ", gePM=" + gePM + ", systemId=" + systemId + ", systemName=" + systemName
				+ ", scheduleCallDateString=" + scheduleCallDateString + ", scheduleCallDate=" + scheduleCallDate
				+ ", cancellationDateString=" + cancellationDateString + ", cancellationDate=" + cancellationDate
				+ ", currentScheduleEndDateString=" + currentScheduleEndDateString + ", currentScheduleEndDate="
				+ currentScheduleEndDate + ", currentScheduleStartDateString=" + currentScheduleStartDateString
				+ ", currentScheduleStartDate=" + currentScheduleStartDate + ", restartDateString=" + restartDateString
				+ ", restartDate=" + restartDate + ", stopDateString=" + stopDateString + ", stopDate=" + stopDate
				+ ", purchaseOrderVO=" + purchaseOrderVO + ", perChangeControlVO=" + perChangeControlVO + ", perLoeVO="
				+ perLoeVO + ", purchaseOrderVOList=" + purchaseOrderVOList + ", perChangeControlVOList="
				+ perChangeControlVOList + ", currentPerPhaseList=" + currentPerPhaseList + ", restrictionMatrixMap="
				+ restrictionMatrixMap + "]";
	}
	
}
