package com.cg.eztrac.vo;

public class MenuVO {
	
	private String customizeJsonMap = "";
//	private Map<Integer, List<SectionVO>> menuMap = new TreeMap<Integer, List<SectionVO>>();
	
	
	public String getCustomizeJsonMap() {
		return customizeJsonMap;
	}

	public void setCustomizeJsonMap(String customizeJsonMap) {
		this.customizeJsonMap = customizeJsonMap;
	}


	/*public Map<Integer, List<SectionVO>> getMenuMap() {
		return menuMap;
	}

	public void setMenuMap(Map<Integer, List<SectionVO>> menuMap) {
		this.menuMap = menuMap;
	}*/
	
	
	
}
