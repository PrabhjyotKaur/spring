package com.cg.eztrac.vo;

import java.util.Date;
import java.util.List;

public class EstimationVO {
	
	//General - Fields - Common for Per and Build Modules
	private int perId;
	private String perNumber;
	private String perDescription;
	private String projectHealth;
	private String projectCoordinator;
	private String comments;
	
	private String createdBy;
	private String createdOnString;
	private Date createdOn;
	private String lastModifiedBy;
	private String lastModifiedOnString;
	private Date lastModifiedOn;
	
	private PhaseTimelinesVO phaseTimelinesVO;
	
	private AttachmentVO attachmentVO;
	private CommentVO commentVO;
	private NotificationVO notificationVO;
	
	private List<AttachmentVO> attachmentVOList;
	private List<CommentVO> commentVOList;
	private List<NotificationVO> notificationVOList;
	
	//lists to populate dropdowns
	private List<String> projectHealthList;

	public int getPerId() {
		return perId;
	}

	public void setPerId(int perId) {
		this.perId = perId;
	}

	public String getPerNumber() {
		return perNumber;
	}

	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}

	public String getPerDescription() {
		return perDescription;
	}

	public void setPerDescription(String perDescription) {
		this.perDescription = perDescription;
	}

	public String getProjectHealth() {
		return projectHealth;
	}

	public void setProjectHealth(String projectHealth) {
		this.projectHealth = projectHealth;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedOnString() {
		return createdOnString;
	}

	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedOnString() {
		return lastModifiedOnString;
	}

	public void setLastModifiedOnString(String lastModifiedOnString) {
		this.lastModifiedOnString = lastModifiedOnString;
	}

	public Date getLastModifiedOn() {
		return lastModifiedOn;
	}

	public void setLastModifiedOn(Date lastModifiedOn) {
		this.lastModifiedOn = lastModifiedOn;
	}

	public PhaseTimelinesVO getPhaseTimelinesVO() {
		return phaseTimelinesVO;
	}

	public void setPhaseTimelinesVO(PhaseTimelinesVO phaseTimelinesVO) {
		this.phaseTimelinesVO = phaseTimelinesVO;
	}

	public AttachmentVO getAttachmentVO() {
		return attachmentVO;
	}

	public void setAttachmentVO(AttachmentVO attachmentVO) {
		this.attachmentVO = attachmentVO;
	}

	public CommentVO getCommentVO() {
		return commentVO;
	}

	public void setCommentVO(CommentVO commentVO) {
		this.commentVO = commentVO;
	}

	public NotificationVO getNotificationVO() {
		return notificationVO;
	}

	public void setNotificationVO(NotificationVO notificationVO) {
		this.notificationVO = notificationVO;
	}

	public List<AttachmentVO> getAttachmentVOList() {
		return attachmentVOList;
	}

	public void setAttachmentVOList(List<AttachmentVO> attachmentVOList) {
		this.attachmentVOList = attachmentVOList;
	}

	public List<CommentVO> getCommentVOList() {
		return commentVOList;
	}

	public void setCommentVOList(List<CommentVO> commentVOList) {
		this.commentVOList = commentVOList;
	}

	public List<NotificationVO> getNotificationVOList() {
		return notificationVOList;
	}

	public void setNotificationVOList(List<NotificationVO> notificationVOList) {
		this.notificationVOList = notificationVOList;
	}

	public List<String> getProjectHealthList() {
		return projectHealthList;
	}

	public void setProjectHealthList(List<String> projectHealthList) {
		this.projectHealthList = projectHealthList;
	}

	public String getProjectCoordinator() {
		return projectCoordinator;
	}

	public void setProjectCoordinator(String projectCoordinator) {
		this.projectCoordinator = projectCoordinator;
	}

	@Override
	public String toString() {
		return "EstimationVO [perId=" + perId + ", perNumber=" + perNumber + ", perDescription=" + perDescription
				+ ", projectHealth=" + projectHealth + ", comments=" + comments + ", createdBy=" + createdBy
				+ ", createdOnString=" + createdOnString + ", createdOn=" + createdOn + ", lastModifiedBy="
				+ lastModifiedBy + ", lastModifiedOnString=" + lastModifiedOnString + ", lastModifiedOn="
				+ lastModifiedOn + ", phaseTimelinesVO=" + phaseTimelinesVO + ", attachmentVO=" + attachmentVO
				+ ", commentVO=" + commentVO + ", notificationVO=" + notificationVO + ", attachmentVOList="
				+ attachmentVOList + ", commentVOList=" + commentVOList + ", notificationVOList=" + notificationVOList
				+ ", projectCoordinator=" + projectCoordinator + ", projectHealthList=" + projectHealthList + "]";
	}

}
