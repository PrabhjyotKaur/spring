package com.cg.eztrac.handler;

import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.domainobject.RolePermissionDO;
import com.cg.eztrac.service.domainobject.SectionDetailDO;

public class OnLoadHandler {
	String className=OnLoadHandler.class.getSimpleName();
	
	public List<SectionDetailDO> loadSectionDetails(){
		String methodName="loadSectionDetails";
		SectionDetailDO sectionDetailDO = new SectionDetailDO();
		sectionDetailDO.setSubAccounId(1);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In onload handler", "Before calling the callSectionDetailService() from onloadhandler class");
		List<SectionDetailDO> sectionDetailResponse = sectionDetailDO.callSectionDetailService(sectionDetailDO);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In onload handler", "After calling the callSectionDetailService() from onloadhandler class");
		return sectionDetailResponse;
	}
	
	public List<RolePermissionDO> loadRolePermissionDetails(){
		List<RolePermissionDO> rolePermissionReponse = new RolePermissionDO().callRolePermissionService();
		return rolePermissionReponse;
	}

}
