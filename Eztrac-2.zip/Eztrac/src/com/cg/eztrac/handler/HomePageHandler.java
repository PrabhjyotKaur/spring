package com.cg.eztrac.handler;

public class HomePageHandler {

	/*public HomePageVO switchRoleMenuHandler(HomePageVO homePageVO) {
		MenuVO menuVO = new CommonUtility().cutomizeMenu(homePageVO.getRoleId());
		return homePageVO;
	}*/
	
}
