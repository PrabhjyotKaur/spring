package com.cg.eztrac.exception;

/*import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import javax.servlet.ServletContext;

import org.apache.catalina.core.StandardContext;
import org.apache.catalina.core.StandardEngine;
import org.apache.catalina.deploy.ErrorPage;*/

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionController {

	/*
	 * @Autowired ServletContext context;
	 */

	@ExceptionHandler(CustomException.class)
	public ModelAndView handleCustomException(CustomException ex) {
		ex.setErrCode("10045");
		ex.setErrMsg("Exception Handled in CustomException");

		ModelAndView model = new ModelAndView();
		model.addObject("errCode", ex.getErrCode());
		model.addObject("errMsg", ex.getErrMsg());
		model.setViewName("genericerror");
		return model;

	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleAllException(Exception ex) {
		/*
		 * try { StandardEngine standardEngine; standardEngine = (StandardEngine)
		 * MBeanServerFactory.findMBeanServer(null).get(0) .getAttribute(new
		 * ObjectName("Catalina", "type", "Engine"), "managedResource"); StandardContext
		 * standardContext = (StandardContext) standardEngine
		 * .findChild(standardEngine.getDefaultHost()).findChild(context.getContextPath(
		 * ));
		 * 
		 * ErrorPage errorPage404 = new ErrorPage(); errorPage404.setErrorCode(404);
		 * errorPage404.setLocation("/views/genericerror.html");
		 * 
		 * standardContext.addErrorPage(errorPage404); } catch (Exception e) {
		 * e.printStackTrace(); }
		 */

		ModelAndView model = new ModelAndView();
		model.addObject("errCode", "EXEXXX");
		model.addObject("errMsg", ex.getMessage());
		model.setViewName("genericerror");
		return model;

	}

}
