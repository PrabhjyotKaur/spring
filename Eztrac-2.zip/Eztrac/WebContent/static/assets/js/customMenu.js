console.log('%c Proudly Crafted with ZiOn.', 'background: #222; color: #bada55');




/* ---------------------------------------------- /*
 * Preloader
 /* ---------------------------------------------- */
(function(){
	
    $(document).ready(function() {
    	if($(".custom-menu-ul").length){
    		buildCustomMenu();
    	}
    	
    	if($(".switchrole_onclick").length){
    		  $(".switchrole_onclick").click(function(){
    			  var val = $(this).attr("id");
    			  $("#roleId").val(val);
    			  $( "#homePage-form" ).submit();
    		  });
    	}
    	
    	function buildCustomMenu(){
//    		var customMenuVal = $("#customizeJsonMap").val();
    		var customMenuVal ='{"11":[{"elligbleFlag":true,"sectionId":11,"sectionName":"Projects|PER","subSectionVO":[{"subSectionId":100,"subSectionName":"New","elligbleFlag":false}]}]}';
    		var genericDropDownLI  = $("<li>").addClass("dropdown");
    		var genericDropDownAnchor = $("<a/>").addClass("dropdown-toggle").attr({"data-toggle": "dropdown", "href": "#"});
    		var subSectionAnchor= $("<a>");
    		var genericDropDownMenuUL = $("<ul>").addClass("dropdown-menu");
    		var customMenuClass = ".custom-menu-ul";
    		
    		$.each(JSON.parse(customMenuVal), function(key, value) {
    			// find custom-menu-ul \\ ul li a.data ul li a.data ul li a.data
    			//buildSwitchRole(key);
    			$.each(value, function(i) {
    				genericDropDownLI  = $("<li>").addClass("dropdown");
    				console.log(value[i]);
    				var sectionVO = value[i];
    				var elligbleFlagSection = sectionVO.elligbleFlag, sectionId = sectionVO.sectionId, sectionName = sectionVO.sectionName;
    				var subSectionVOList = sectionVO.subSectionVO;
    				if(elligbleFlagSection) {
    					sectionNameArr = sectionName.split("|"); // projects|per
    					var len = sectionNameArr.length;
    					if(len==2) {
    						var dropDownDownChr =true;
    						var ULSubSection=$("<ul>").addClass("dropdown-menu");
        					$.each(subSectionVOList, function(i) {
        						var subSectionVO = subSectionVOList[i];
	        					var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
	        					var anchorSubSection = $("<a>").attr({"th:href": "#", "href": "#"});
	        					var LISubSection  = $("<li>");
	        					anchorSubSection.text(subSectionName);
	        					LISubSection.append(anchorSubSection);
	        					ULSubSection.append(LISubSection);
        					});//<li><a href="per_upload" th:href="@{/per_upload}">Upload</a></li>
        					//<ul class="dropdown-menu dropdown-sub-menu dropdown-sub-menu_per">
        					genericDropDownAnchor.text(sectionNameArr[1]);
        					genericDropDownAnchor.append(ULSubSection);
        					genericDropDownLI.append(genericDropDownAnchor);
        					$('[class*=" dropdown-menu_'+sectionNameArr[0].toUpperCase()+'"]').append(genericDropDownLI);
        					
        				}	else{
        					
	             					$.each(subSectionVOList, function(i) {
	             				var subSectionVO = subSectionVOList[i];
	        					var elligFlagSubSection = subSectionVO.elligbleFlag, subSectionId = subSectionVO.subSectionId, subSectionName = subSectionVO.subSectionName;
	        					
	        					var anchorForSingleLevel1 = $("<a>").attr({"th:href": "#", "href": "#"});
	        					var genericDropDownLILevel1  = $("<li>").addClass("dropdown");
	        					
	        					anchorForSingleLevel1.text(subSectionName);
	        					genericDropDownLILevel1.prepend(anchorForSingleLevel1);
	        					$('[class*=" dropdown-menu_'+sectionName.toUpperCase()+'"]').append(genericDropDownLILevel1);
	        					//<li class="dropdown_TIMESHEET"><a href="timesheet.html" th:href="@{/timesheet.html}">TimeSheet</a></li>
	        					});
        					
        				}
    						
    					}
    					
    			
    			});
    			
    		});
    	}
    	/*function buildSwitchRole( key){
    		var li = $("<li>");
    		var anchor;
    		var switchRoleKeyUL = ".dropdown-menu_SWITCHROLE";
    		anchor = $("<a>").attr({"th:href": "#", "href": "#"}).text(key);
    		li.prepend(anchor);
    		$( "ul" ).find( switchRoleKeyUL ).append(li);
    	}*/
    	
    	
    });
})(jQuery);
//{1 PMO={11=PROJECTS|PER$NEW#ENABLE,EDIT#ENABLE,UPLOAD#DISABLE,, 12=PROJECTS|BUILD$NEW#ENABLE,EDIT#ENABLE,, 13=PROJECTS|TIMESHEET,}}

