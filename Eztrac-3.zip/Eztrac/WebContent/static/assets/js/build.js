
$(document).ready(function() {
alert("build js");
	
	/* START : To show and hide the CC table in build CC */
	$("#buildCCshowtablebutton").click(function(){
		
	$('#buildCCtable').show();
	});
	
	$("#buildCChidetablebutton").click(function(){
	
	$('#buildCCtable').hide();
	});
	/* END : To show and hide the CC table in build CC */
	
	$("#dummyshow").click(function(){
		
	$('#dummytable').show();
	});
	
	$("#dummyhide").click(function(){
	
	$('#dummytable').hide();
	});
	
	/*START : Related to Modals*/
	// Get the modal
	var modal = document.getElementById('myModal');
	var modal1 = document.getElementById('myModal1');
	var modal2 = document.getElementById('myModal2');
	var modal3 = document.getElementById('myModal3');
	
	
	// Get the button that opens the modal
	var btn = document.getElementById("myBtn");
	var btn1 = document.getElementById("myBtn1");
	var btn2 = document.getElementById("myBtn2");
	var btn3 = document.getElementById("myBtn3");
	
	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];

	// When the user clicks the button, open the modal 
	btn.onclick = function() {
		modal.style.display = "block";
	}
	btn1.onclick = function() {
		modal1.style.display = "block";
	}
	btn2.onclick = function() {
		modal2.style.display = "block";
	}
	btn3.onclick = function() {
		modal3.style.display = "block";
	}

	

	$("#modal2close").click(function(){
		$('#myModal2').hide();
	});
	
	//When the user clicks on 'X' button - to close modal
	$("#modal3close").click(function(){
		$('#myModal3').hide();
	});
	
	$("#modalclose").click(function(){
		$('#myModal').hide();
	});
	
	$("#modal1close").click(function(){
		$('#myModal1').hide();
	});
	
	
	
	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		if (event.target == modal) {
			modal.style.display = "none";
		}
		if (event.target == modal1) {
			modal1.style.display = "none";
		}
		if (event.target == modal2) {
			modal2.style.display = "none";
		} 
		if (event.target == modal3) {
			modal3.style.display = "none";
		}  
		
	}
	
	/*END : Related to Modals*/

	
	/* START : To open and close the accordians */
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function(){
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}
		}
	}
	/* END : To open and close the accordians */
	
	
	 $("#pAdd").on('click', function() {
	       var p = $("#pickList").find("#pickData option:selected");
	        p.clone().appendTo("#pickListResult");
	        p.remove();
	      });

	      $("#pAddAll").on('click', function() {
			var p = $("#pickList").find("#pickData option");
	        p.clone().appendTo("#pickListResult");
	        p.remove();
	      });

	      $("#pRemove").on('click', function() {
	       var p = $("#pickList").find("#pickListResult option:selected");
	       p.clone().appendTo("#pickData");
	       p.remove();
	      });

	      $("#pRemoveAll").on('click', function() {
	       var p = $("#pickList").find("#pickListResult option");
	       p.clone().appendTo("#pickData");
	       p.remove();
	      });
	
	
	/* START : To show and hide the picklist for 'assigned to' */
	$("#addEmployees").click(function(){
		
	$('#pickList').show();
	});
	
	$("#hideEmployees").click(function(){
	
	$('#pickList').hide();
	});
	/* END : To show and hide the picklist for 'assigned to' */
	
});
  

  









