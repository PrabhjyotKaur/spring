$(document).ready(function() {
                alert("per");
                
             
                
                /* START : To open and close the accordians */
                var acc = document.getElementsByClassName("accordion");
                var i;

                for (i = 0; i < acc.length; i++) {
                                acc[i].onclick = function(){
                                                this.classList.toggle("active");
                                                var panel = this.nextElementSibling;
                                                if (panel.style.display === "block") {
                                                                panel.style.display = "none";
                                                } else {
                                                                panel.style.display = "block";
                                                }
                                }
                }
                /* END : To open and close the accordians */
                
                /*START : Related to Modals*/
                // Get the modal
                var modal = document.getElementById('myModal');
                var modal1 = document.getElementById('myModal1');
                var modal2 = document.getElementById('myModal2');
                var modal3 = document.getElementById('myModal3');
                var modal4 = document.getElementById('myModal4');
                // Get the button that opens the modal
                var btn = document.getElementById("myBtn");
                var btn1 = document.getElementById("myBtn1");
                var btn2 = document.getElementById("myBtn2");
                var btn3 = document.getElementById("myBtn3");
                var btn4 = document.getElementById("myBtn4");
                // Get the <span> element that closes the modal
                var span = document.getElementsByClassName("close")[0];

                // When the user clicks the button, open the modal 
                btn.onclick = function() {
                                modal.style.display = "block";
                }
                btn1.onclick = function() {
                                modal1.style.display = "block";
                }
                btn2.onclick = function() {
                                modal2.style.display = "block";
                }
                btn3.onclick = function() {
                                modal3.style.display = "block";
                }
                btn4.onclick = function() {
                                modal4.style.display = "block";
                }

                // When the user clicks on <span> (x), close the modal
                $("#modal2close").click(function(){
                                $('#myModal2').hide();
                });
                $("#modal3close").click(function(){
                                $('#myModal3').hide();
                });
                
                $("#modalclose").click(function(){
                                $('#myModal').hide();
                });
                
                $("#modal1close").click(function(){
                                $('#myModal1').hide();
                });
                $("#modal4close").click(function(){
                                
                                $('#myModal4').hide();
                });


                // When the user clicks anywhere outside of the modal, close it
                window.onclick = function(event) {
                  if (event.target == modal) {
                                                modal.style.display = "none";
                                }
                                if (event.target == modal1) {
                                                modal1.style.display = "none";
                                }
                                if (event.target == modal2) {
                                                modal2.style.display = "none";
                                } 
                if (event.target == modal3) {
                                                modal3.style.display = "none";
                                }  
                if (event.target == modal4) {
                                                modal4.style.display = "none";
                                }              
                }
                /*END : Related to Modals*/
                
                /* START : Picklist code for 'Managers to notify' */
                $("#addManager").on('click', function() {
         	       var p = $("#managerPickList").find("#managerToNotifyData option:selected");
         	        p.clone().appendTo("#managerToNotifyResult");
         	        p.remove();
         	      });

         	      $("#addAllManager").on('click', function() {
         			var p = $("#managerPickList").find("#managerToNotifyData option");
         	        p.clone().appendTo("#managerToNotifyResult");
         	        p.remove();
         	      });

         	      $("#removeManager").on('click', function() {
         	       var p = $("#managerPickList").find("#managerToNotifyResult option:selected");
         	       p.clone().appendTo("#managerToNotifyData");
         	       p.remove();
         	      });

         	      $("#removeAllManager").on('click', function() {
         	       var p = $("#managerPickList").find("#managerToNotifyResult option");
         	       p.clone().appendTo("#managerToNotifyData");
         	       p.remove();
         	      });
                /* END : Picklist code for 'Managers to notify' */
         	      
         	      
         	     /* START : Picklist code for 'Teams Involved' */
                  $("#addTeam").on('click', function() {
           	       var p = $("#teamInvolvedPickList").find("#teamsInvolvedData option:selected");
           	        p.clone().appendTo("#teamsInvolvedResult");
           	        p.remove();
           	      });

           	      $("#addAllTeam").on('click', function() {
           			var p = $("#teamInvolvedPickList").find("#teamsInvolvedData option");
           	        p.clone().appendTo("#teamsInvolvedResult");
           	        p.remove();
           	      });

           	      $("#removeTeam").on('click', function() {
           	       var p = $("#teamInvolvedPickList").find("#teamsInvolvedResult option:selected");
           	       p.clone().appendTo("#teamsInvolvedData");
           	       p.remove();
           	      });

           	      $("#removeAllTeam").on('click', function() {
           	       var p = $("#teamInvolvedPickList").find("#teamsInvolvedResult option");
           	       p.clone().appendTo("#teamsInvolvedData");
           	       p.remove();
           	      });
                  /* END : Picklist code for 'Teams Involved' */
                
           	      
           	      /* START : To display list of builds table */
                  $("#listOfbuildsLink").click(function(){
                  	$('#buildListTable').show();
                  });
                  
                  $("#hideBuildListTable").click(function(){
                  	$('#buildListTable').hide();
                  });
                  
                  /* END : To display list of builds table */
                  
                  
                
                /* START : To show and hide the picklist for 'Managers to notify' */
                $("#addManagers").click(function(){
                                
                $('#pickList').show();
                });
                
                $("#hideManagers").click(function(){
                
                $('#pickList').hide();
                });
                /* END : To show and hide the picklist for 'Managers to notify' */
                
                /* START : To show and hide the PER CC table in PER CC */
                $("#PerCCshowtablebutton").click(function(){
                                
                	$('#perCCtableshown').show();
                });
                
                $("#PerCChidetablebutton").click(function(){
                
                	$('#perCCtableshown').hide();
                });
                /* END : To show and hide the PER CC table in PER CC */
                
                
                /* START : To show and hide extra filter div in Per list page */
                
                $("#showExtraFilter").click(function(){
                    
                	$('#extraFilterData').show();
                });
                /* END : To show and hide extra filter div in Per list page */
                
                /*Date Validation for Schedule Updates*/
                $("#perForm").on('submit', function(e) {
                	
                    alert("Inside Form Validation");
                    
                    var successFlag = true;
                    
                    var DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
                    
                    if($('#scheduleCallDate').val()>$('#cancellationDate').val()){
                    	alert(true);
                    }
                    
        			var scheduleCallDate = new Date($('#scheduleCallDate').val()).toDateString(DATE_FORMAT_YYYY_MM_DD);
        			var cancellationDate = new Date($('#cancellationDate').val()).toDateString(DATE_FORMAT_YYYY_MM_DD);
        			
        			if("" != scheduleCallDate && "" != cancellationDate && cancellationDate < scheduleCallDate) {        				
                    	$("#schedulingCallDateError").text('Cancellation date should be after Scheduling call date.');
                    	successFlag = false;
        			}
        			
                    if (successFlag){
                        alert('FORM FIELDS ARE VALID');
                        return true;
                    } else {
                    	alert('FORM FIELDS ARE INVALID');
                    	return false;
                    }
                });
                
});
