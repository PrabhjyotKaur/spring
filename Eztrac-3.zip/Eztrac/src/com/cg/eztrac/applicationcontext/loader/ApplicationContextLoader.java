package com.cg.eztrac.applicationcontext.loader;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.handler.OnLoadHandler;
import com.cg.eztrac.service.domainobject.RolePermissionDO;
import com.cg.eztrac.service.domainobject.SectionDetailDO;
import com.cg.eztrac.vo.SectionVO;

import net.sf.ehcache.CacheManager;

@Component
public class ApplicationContextLoader {
	
	String className=ApplicationContextLoader.class.getSimpleName();
	@Autowired  
	ServletContextImpl servletContextImpl;
	
	/** method called only once at application start up to load SECTION DETAIL from service*/
	@EventListener(ContextRefreshedEvent.class)
	public void contextRefreshedEvent(ContextRefreshedEvent event)  {
		String methodName="contextRefreshedEvent";
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "application context called upon application start-up");
		
		//throw new CustomException("EXEAPPCON", "Exception occured");
		
		/** condition to avoId multiple load from context ( webcontext and dispatcherServlet context ) */
		if(event.getApplicationContext().getParent() == null){
			OnLoadHandler onLoadHandler = new OnLoadHandler();
			
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"In application context", "Before calling the loadSectionDetails() from Application context");
			List<SectionDetailDO> loadSectionDetails = onLoadHandler.loadSectionDetails();
			if(null != loadSectionDetails && !loadSectionDetails.isEmpty()){
				servletContextImpl.addObjectToServletContext(ICommonConstants.ALL_SEC_DETAILS_CONTEXT, loadSectionDetails);
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "loadSectionDetails() is called and data is added to servelt context");
			
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "Before calling the loadRolePermissionDetails() from Application context");
			List<RolePermissionDO> loadRolePermissionDetails = onLoadHandler.loadRolePermissionDetails();
			if(null != loadRolePermissionDetails && !loadRolePermissionDetails.isEmpty()){
				servletContextImpl.addObjectToServletContext(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT, loadRolePermissionDetails);
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "loadRolePermissionDetails() is called and data is added to servelt context");
			CommonUtility commonUtility=new CommonUtility();
			Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = commonUtility.getUserMenuAccebiltiy(loadRolePermissionDetails, loadSectionDetails);
			if(null != allRoleMenuAccebiltiy && !allRoleMenuAccebiltiy.isEmpty()){
				servletContextImpl.addObjectToServletContext(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT, allRoleMenuAccebiltiy);
			}
		}
	}
	
	@EventListener(ContextClosedEvent.class)
	public void contextClosedEvent(ContextClosedEvent event) {
		String methodName="contextClosedEvent";
		try {
			if(event.getApplicationContext().getParent() == null){
				
				LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "application context is closed and before removing data from cache");
				CacheManager cm = CacheManager.getInstance();
				if(cm!=null){
					String[] cacheNames = cm.getCacheNames();
					for (String cacheName : cacheNames) {
						cm.removeCache(cacheName);
					}
				}
				LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+" Application context", "application context is closed and after removing data from cache");
			}
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while closing the application context");
		}
	}
}
