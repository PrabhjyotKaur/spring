package com.cg.eztrac.domain;

public class LoeDO {
	
	private int planningLOEReq;
	private int planningLOEDesign;
	private int planningLOECons;
	private int planningLOETest;
	private int planningLOERelease;
	
	private int executionLOEReq;
	private int executionLOEDesign;
	private int executionLOECons;
	private int executionLOETest;
	private int executionLOERelease;
	
	private int actualDaysLOEReq;
	private int actualDaysLOEDesign;
	private int actualDaysLOECons;
	private int actualDaysLOETest;
	private int actualDaysLOERelease;
	
	private boolean sendLOEEmailFlag;

	public int getPlanningLOEReq() {
		return planningLOEReq;
	}

	public void setPlanningLOEReq(int planningLOEReq) {
		this.planningLOEReq = planningLOEReq;
	}

	public int getPlanningLOEDesign() {
		return planningLOEDesign;
	}

	public void setPlanningLOEDesign(int planningLOEDesign) {
		this.planningLOEDesign = planningLOEDesign;
	}

	public int getPlanningLOECons() {
		return planningLOECons;
	}

	public void setPlanningLOECons(int planningLOECons) {
		this.planningLOECons = planningLOECons;
	}

	public int getPlanningLOETest() {
		return planningLOETest;
	}

	public void setPlanningLOETest(int planningLOETest) {
		this.planningLOETest = planningLOETest;
	}

	public int getPlanningLOERelease() {
		return planningLOERelease;
	}

	public void setPlanningLOERelease(int planningLOERelease) {
		this.planningLOERelease = planningLOERelease;
	}

	public int getExecutionLOEReq() {
		return executionLOEReq;
	}

	public void setExecutionLOEReq(int executionLOEReq) {
		this.executionLOEReq = executionLOEReq;
	}

	public int getExecutionLOEDesign() {
		return executionLOEDesign;
	}

	public void setExecutionLOEDesign(int executionLOEDesign) {
		this.executionLOEDesign = executionLOEDesign;
	}

	public int getExecutionLOECons() {
		return executionLOECons;
	}

	public void setExecutionLOECons(int executionLOECons) {
		this.executionLOECons = executionLOECons;
	}

	public int getExecutionLOETest() {
		return executionLOETest;
	}

	public void setExecutionLOETest(int executionLOETest) {
		this.executionLOETest = executionLOETest;
	}

	public int getExecutionLOERelease() {
		return executionLOERelease;
	}

	public void setExecutionLOERelease(int executionLOERelease) {
		this.executionLOERelease = executionLOERelease;
	}

	public int getActualDaysLOEReq() {
		return actualDaysLOEReq;
	}

	public void setActualDaysLOEReq(int actualDaysLOEReq) {
		this.actualDaysLOEReq = actualDaysLOEReq;
	}

	public int getActualDaysLOEDesign() {
		return actualDaysLOEDesign;
	}

	public void setActualDaysLOEDesign(int actualDaysLOEDesign) {
		this.actualDaysLOEDesign = actualDaysLOEDesign;
	}

	public int getActualDaysLOECons() {
		return actualDaysLOECons;
	}

	public void setActualDaysLOECons(int actualDaysLOECons) {
		this.actualDaysLOECons = actualDaysLOECons;
	}

	public int getActualDaysLOETest() {
		return actualDaysLOETest;
	}

	public void setActualDaysLOETest(int actualDaysLOETest) {
		this.actualDaysLOETest = actualDaysLOETest;
	}

	public int getActualDaysLOERelease() {
		return actualDaysLOERelease;
	}

	public void setActualDaysLOERelease(int actualDaysLOERelease) {
		this.actualDaysLOERelease = actualDaysLOERelease;
	}

	public boolean isSendLOEEmailFlag() {
		return sendLOEEmailFlag;
	}

	public void setSendLOEEmailFlag(boolean sendLOEEmailFlag) {
		this.sendLOEEmailFlag = sendLOEEmailFlag;
	}

	@Override
	public String toString() {
		return "LoeDO [planningLOEReq=" + planningLOEReq + ", planningLOEDesign=" + planningLOEDesign
				+ ", planningLOECons=" + planningLOECons + ", planningLOETest=" + planningLOETest
				+ ", planningLOERelease=" + planningLOERelease + ", executionLOEReq=" + executionLOEReq
				+ ", executionLOEDesign=" + executionLOEDesign + ", executionLOECons=" + executionLOECons
				+ ", executionLOETest=" + executionLOETest + ", executionLOERelease=" + executionLOERelease
				+ ", actualDaysLOEReq=" + actualDaysLOEReq + ", actualDaysLOEDesign=" + actualDaysLOEDesign
				+ ", actualDaysLOECons=" + actualDaysLOECons + ", actualDaysLOETest=" + actualDaysLOETest
				+ ", actualDaysLOERelease=" + actualDaysLOERelease + ", sendLOEEmailFlag=" + sendLOEEmailFlag + "]";
	}
	
}
