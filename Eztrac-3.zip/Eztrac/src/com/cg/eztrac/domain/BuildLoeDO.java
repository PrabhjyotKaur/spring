package com.cg.eztrac.domain;

import java.util.Date;

public class BuildLoeDO extends LoeDO {
	
	private Date buildPlanningLOEEstimationDate;
	private Date buildExecutionLOEEstimationDate;
	
	private int buildTotalExecutionCCLOEReq;
	private int buildTotalExecutionCCLOEDesign;
	private int buildTotalExecutionCCLOECons;
	private int buildTotalExecutionCCLOETest;
	private int buildTotalExecutionCCLOERelease;
	
	public Date getBuildPlanningLOEEstimationDate() {
		return buildPlanningLOEEstimationDate;
	}
	public void setBuildPlanningLOEEstimationDate(Date buildPlanningLOEEstimationDate) {
		this.buildPlanningLOEEstimationDate = buildPlanningLOEEstimationDate;
	}
	public Date getBuildExecutionLOEEstimationDate() {
		return buildExecutionLOEEstimationDate;
	}
	public void setBuildExecutionLOEEstimationDate(Date buildExecutionLOEEstimationDate) {
		this.buildExecutionLOEEstimationDate = buildExecutionLOEEstimationDate;
	}
	public int getBuildTotalExecutionCCLOEReq() {
		return buildTotalExecutionCCLOEReq;
	}
	public void setBuildTotalExecutionCCLOEReq(int buildTotalExecutionCCLOEReq) {
		this.buildTotalExecutionCCLOEReq = buildTotalExecutionCCLOEReq;
	}
	public int getBuildTotalExecutionCCLOEDesign() {
		return buildTotalExecutionCCLOEDesign;
	}
	public void setBuildTotalExecutionCCLOEDesign(int buildTotalExecutionCCLOEDesign) {
		this.buildTotalExecutionCCLOEDesign = buildTotalExecutionCCLOEDesign;
	}
	public int getBuildTotalExecutionCCLOECons() {
		return buildTotalExecutionCCLOECons;
	}
	public void setBuildTotalExecutionCCLOECons(int buildTotalExecutionCCLOECons) {
		this.buildTotalExecutionCCLOECons = buildTotalExecutionCCLOECons;
	}
	public int getBuildTotalExecutionCCLOETest() {
		return buildTotalExecutionCCLOETest;
	}
	public void setBuildTotalExecutionCCLOETest(int buildTotalExecutionCCLOETest) {
		this.buildTotalExecutionCCLOETest = buildTotalExecutionCCLOETest;
	}
	public int getBuildTotalExecutionCCLOERelease() {
		return buildTotalExecutionCCLOERelease;
	}
	public void setBuildTotalExecutionCCLOERelease(int buildTotalExecutionCCLOERelease) {
		this.buildTotalExecutionCCLOERelease = buildTotalExecutionCCLOERelease;
	}
	
	@Override
	public String toString() {
		return "BuildLoeDO [buildPlanningLOEEstimationDate=" + buildPlanningLOEEstimationDate
				+ ", buildExecutionLOEEstimationDate=" + buildExecutionLOEEstimationDate
				+ ", buildTotalExecutionCCLOEReq=" + buildTotalExecutionCCLOEReq + ", buildTotalExecutionCCLOEDesign="
				+ buildTotalExecutionCCLOEDesign + ", buildTotalExecutionCCLOECons=" + buildTotalExecutionCCLOECons
				+ ", buildTotalExecutionCCLOETest=" + buildTotalExecutionCCLOETest
				+ ", buildTotalExecutionCCLOERelease=" + buildTotalExecutionCCLOERelease + "]";
	}
	
}
