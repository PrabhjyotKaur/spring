package com.cg.eztrac.common;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.service.domainobject.RolePermissionDO;
import com.cg.eztrac.service.domainobject.SectionDetailDO;
import com.cg.eztrac.service.domainobject.SubSectionDO;
import com.cg.eztrac.vo.SectionVO;
import com.cg.eztrac.vo.SubSectionVO;

public class CommonUtility {
	String className=CommonUtility.class.getSimpleName();
	
	@Autowired ServletContextImpl servletContextImpl;
	final static String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	public static String formatMessage(String className, String methodName, String message,
			String additionalLogDetails) {
		StringBuffer sb = new StringBuffer();
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append("class=");
		sb.append(className);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append("Method=");
		sb.append(methodName);
		if (additionalLogDetails != null) {
			sb.append(ICommonConstants.PIPE_SEPARATOR);
			sb.append(additionalLogDetails);

		}

		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(message);
		return sb.toString();
	}
	
	public static String getTokenId() {
		String methodName="getTokenId";
		String className=CommonUtility.class.getSimpleName();
		int len=10;
		StringBuilder sb = new StringBuilder(len);
		SecureRandom rnd = new SecureRandom();
		try {
			rnd = SecureRandom.getInstance("SHA1PRNG");
			for (int i = 0; i < len; i++)
				sb.append(AB.charAt(rnd.nextInt(AB.length())));
		} catch (NoSuchAlgorithmException e) {
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while generating the token_id");
			sb =null;
		}
		return sb.toString();
	}
	
	public static Map<String, String> getRestrictionMatrixMap(List<String> allSubSectionNameList, String restrictionMatrixPattern) {
		Map<String, String> restrictionMatrixMap = new HashMap<String, String>();
		if(null != allSubSectionNameList && !allSubSectionNameList.isEmpty()) {
			for(String allSubSectionName: allSubSectionNameList) {
				if(allSubSectionName.contains(restrictionMatrixPattern)) {
					restrictionMatrixMap.put(allSubSectionName.substring(restrictionMatrixPattern.length()), ICommonConstants.STRING_TRUE);
				}
			}
		}
		return restrictionMatrixMap;
	}
	
	public static void copyBeanProperties(Object source, Object target) {
		BeanUtils.copyProperties(source, target);
	}
	
	public static Date getDateFromString(String dateString, String dateFormat) {
		try {
			return new SimpleDateFormat(dateFormat).parse(dateString);
		} catch (ParseException e) {
			return null;
		}
	}
	
	public Map<Integer,Map<Integer, List<SectionVO>>> getUserMenuAccebiltiy(List<RolePermissionDO> contextRolePerDetails,
			List<SectionDetailDO> contextSectionDetails) {
		String methodName="getUserMenuAccebiltiy";
		Map<Integer,Map<Integer, List<SectionVO>>> menuRoleMap=new HashMap<Integer,Map<Integer, List<SectionVO>>>();
		Map<Integer, List<SectionVO>> menuMap=new TreeMap<Integer, List<SectionVO>>();
		Map <Integer, List<Integer>> singleRoleMap = new HashMap<Integer, List<Integer>>();
		
		try {
			for(RolePermissionDO rolePersmission:contextRolePerDetails){
				for(SectionDetailDO scDO:rolePersmission.getSections()){
					if(Float.parseFloat( scDO.getSectionType() ) != 2){
						ArrayList<Integer> roleSubSectionIDs =new ArrayList<Integer> ();
						for(SubSectionDO subSecVO: scDO.getSubSection()){
							roleSubSectionIDs.add(subSecVO.getSubSectionID());
						}
						Collections.sort(roleSubSectionIDs);
						singleRoleMap.put(scDO.getSectionID(),roleSubSectionIDs );
					}
				}
				List<SectionVO> sectionVOList=new ArrayList<SectionVO>();
				for(SectionDetailDO sectionDetail : contextSectionDetails){
					if(Float.parseFloat( sectionDetail.getSectionType() ) != 2){
						List<Integer> roleSubSections = singleRoleMap.get(sectionDetail.getSectionID());
						SectionVO sectionVO = new SectionVO();
						sectionVOList=new ArrayList<SectionVO>();
						if(null != roleSubSections  ){
							sectionVO = new SectionVO();
							sectionVO.setSectionId(sectionDetail.getSectionID());
							sectionVO.setSectionName(sectionDetail.getSectionName());
							sectionVO.setElligbleFlag(true);
							Map<Integer, String> subSectionMap = new TreeMap<Integer, String>();
							for(SubSectionDO subSection : sectionDetail.getSubSection()){
								subSectionMap.put(subSection.getSubSectionID(), subSection.getSubSectionName());
							}
							List<SubSectionVO> subSectionVOList=new ArrayList<SubSectionVO>();
							for(Integer subSectionID : subSectionMap.keySet()){
								SubSectionVO subSectionVO = new SubSectionVO();
								if(!roleSubSections.contains(subSectionID)){
									subSectionVO.setElligbleFlag(true);
								}
								subSectionVO.setSubSectionId(subSectionID);
								subSectionVO.setSubSectionName(subSectionMap.get(subSectionID));
								subSectionVOList.add(subSectionVO);
							}
							sectionVO.getSubSectionVO().addAll(subSectionVOList);
						} else{
							sectionVO = new SectionVO();
							sectionVO.setSectionId(sectionDetail.getSectionID());
							sectionVO.setSectionName(sectionDetail.getSectionName());
						}
						sectionVOList.add(sectionVO);
						menuMap.put(sectionVO.getSectionId(), sectionVOList);
					}
				}
				menuRoleMap.put(rolePersmission.getRoleId(), menuMap);
			}
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while making the map for getUserMenuAccebiltiy");
			
		}
		return menuRoleMap;
	}
	
	
}
