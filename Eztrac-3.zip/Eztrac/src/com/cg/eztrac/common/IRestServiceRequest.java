package com.cg.eztrac.common;
public interface IRestServiceRequest {

String getChannelId();
String getTokenId();
}
