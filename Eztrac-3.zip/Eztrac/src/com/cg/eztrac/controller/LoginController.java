package com.cg.eztrac.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.handler.LoginHandler;
import com.cg.eztrac.validator.LoginValidator;
import com.cg.eztrac.vo.HomePageVO;
import com.cg.eztrac.vo.LoginVO;

@Controller
@PropertySource("classpath:appurlcontroller.properties")
public class LoginController {
	
	@Autowired LoginValidator loginValidator;
	String className=LoginController.class.getSimpleName();
	
	@Autowired HttpSession httpSession;
	
	@Autowired private ServletContextImpl servletContextImpl;
	
	

	@RequestMapping(value = "${login.home}", method = RequestMethod.POST)
	public ModelAndView loginSubmit(ModelAndView mv, @ModelAttribute @Valid LoginVO loginVO,
			BindingResult bindingResult, Model model, HttpServletRequest httpRequest) {
		
		String methodName="loginSubmit";
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+" serverside validation", "Before doing server side validations");
		HomePageVO homePageVO = new HomePageVO();
		/** if entered username and password has errors user will be redirected to login page. */
		loginValidator.validate(loginVO, bindingResult);
		if(bindingResult.hasErrors()){
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"serverside validation", "inside if of validations");
			mv = new ModelAndView("login");		
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"serverside validation", "After doing server side validations");
		} else{
			LoginHandler loginHandler = new LoginHandler();
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"(helper)- callSignInService()", "Before calling (helper)-callSignInService()");
			/** passing the login credentials to sign-in service */
			loginVO.setTokenId(httpSession.getAttribute(ICommonConstants.TOKEN_ID_STR)+"");
			homePageVO = loginHandler.callSignInService(loginVO,servletContextImpl,httpSession);
			if(homePageVO!=null){
				mv = new ModelAndView("home");
				model.addAttribute(homePageVO);
			} else {
				mv = new ModelAndView("login");
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"(helper)-callSignInService()", "After calling (helper)-callSignInService()");		
		}
		return mv;
	}

	@RequestMapping(value = "/admin**", method = RequestMethod.POST)
	public ModelAndView getAdmin(ModelAndView mv) {
		User user = getUserDetails();
		ModelAndView mav = new ModelAndView("adminPage", "user", user);
		return mav;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}
		return "redirect:/login?logout";
	}

	// Spring Security see this :
	@RequestMapping(value = { "${login.default}", "${login.login}" }, method = {RequestMethod.GET , RequestMethod.POST})
	public ModelAndView login(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout, ModelAndView model) {
        model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid username and password!");
		}

		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
		}
		model.setViewName("login");
		LoginVO loginVO = new LoginVO();
		model.addObject(loginVO);
		return model;

	}

	@RequestMapping(value = "/access_denied**", method = RequestMethod.POST)
	public ModelAndView accessDenied() {	
		LoggerManager.writeInfoLog("LoginController", "accessDenied", "Hi I am in access denied",
				"Hi I am in access denied");
		ModelAndView model = new ModelAndView();
		model.addObject("message", "Access Denied!");
		model.setViewName("access_denied");
		return model;
	}

	
	public User getUserDetails() {
		User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return user;
	}
	
}
