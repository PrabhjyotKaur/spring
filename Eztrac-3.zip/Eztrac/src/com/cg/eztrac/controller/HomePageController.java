package com.cg.eztrac.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.handler.HomePageHandler;
import com.cg.eztrac.vo.HomePageVO;

@Controller
public class HomePageController {
	@Autowired HttpSession httpSession;
	@Autowired private ServletContextImpl servletContextImpl;
	@RequestMapping(value = {"/switchRole" }, method = RequestMethod.POST)
	public ModelAndView buildRoleBasedHome(ModelAndView mv,@ModelAttribute HomePageVO homePageVO, Model model) {
		HomePageHandler homePageHandler = new HomePageHandler();
		homePageVO = homePageHandler.switchRoleMenuHandler(httpSession, homePageVO, servletContextImpl);
		//System.out.println(homePageVO);
		mv = new ModelAndView("home");
		model.addAttribute(homePageVO);
		return mv;
	}
}
