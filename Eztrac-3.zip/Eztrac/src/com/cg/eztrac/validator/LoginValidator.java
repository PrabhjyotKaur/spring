package com.cg.eztrac.validator;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.LoginVO;

@Component(value="loginValidator")
public class LoginValidator implements Validator {
	 String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
	 /*(?=.*[0-9]) a digit must occur at least once
	 (?=.*[a-z]) a lower case letter must occur at least once
	 (?=.*[A-Z]) an upper case letter must occur at least once
	 (?=.*[@#$%^&+=]) a special character must occur at least once
	 (?=\\S+$) no whitespace allowed in the entire string
	 .{8,} at least 8 characters*/
	 Pattern patternc = Pattern.compile(pattern);
	 
	 private static final String CLASSNAME = "LoginValidator";
	
	@Override
	public boolean supports(Class<?> clazz) {
		return LoginVO.class.isAssignableFrom(clazz);		
	}	
  
	@Override
	public void validate(Object target, Errors errors) {
		
		String methodName = "validate";
		
		LoggerManager.writeInfoLog(CLASSNAME,methodName, methodName , methodName);
		
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "userName", "error.login.userName.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "password","error.login.password.required");
		
		     /* if (loginVo.getUserName() != null && (loginVo.getUserName().length() < 5 ||
		    		  loginVo.getUserName().length() > 9)) {
		          errors.rejectValue("userName", "User Name must be of more than 5 and less than 9 characters");
		      }

		      if (loginVo.getPassword() != null && loginVo.getPassword().contains(" ")) {
		          errors.rejectValue("password", "Password must not have spaces");
		      }
		      if (loginVo.getPassword() != null && loginVo.getPassword().length() < 5 &&
		    		  loginVo.getPassword().length() > 15) {
		          errors.rejectValue("password", " Password length must of between 6 and 15.");
		      }
		      Matcher match = patternc.matcher(loginVo.getPassword());
		 	 if (!match.matches()) {
		 		 errors.rejectValue("password", " Password did not match the pattern");
		 	 } */

	}
}
