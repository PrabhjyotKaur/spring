package com.cg.eztrac.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.BuildVO;

@Component(value="buildValidator")
public class BuildValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return false;
	}

	@Override
	public void validate(Object build, Errors errors) {
		
		BuildVO buildVO = (BuildVO) build;
		
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perNumber", "error.build.perNumber.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "system", "error.build.system.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "subSystem", "error.build.subSystem.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "currentBuildPhase", "error.build.currentBuildPhase.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "buildChangeControlVO.ccNumber", "error.build.ccNumber.required");
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoeVO.executionLOEReq","error.build.loe.value" , buildVO.getBuildLoeVO().getExecutionLOEReq(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoeVO.executionLOEDesign","error.build.loe.value" , buildVO.getBuildLoeVO().getExecutionLOEDesign(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoeVO.executionLOECons","error.build.loe.value" , buildVO.getBuildLoeVO().getExecutionLOECons(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoeVO.executionLOETest","error.build.loe.value" , buildVO.getBuildLoeVO().getExecutionLOETest(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoeVO.executionLOERelease","error.build.loe.value" , buildVO.getBuildLoeVO().getExecutionLOETest(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCReqLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCReqLoe(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCDesignLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCDesignLoe(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCConLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCConLoe(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCTestingLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCTestingLoe(), 0, 500);
		EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCReleaseLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCReleaseLoe(), 0, 500);

	}
}

