package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class Request implements IRestServiceRequest{
	Integer subAccountId;
	String token;
	String channel;
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public Integer getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(Integer subAccountId) {
		this.subAccountId = subAccountId;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
