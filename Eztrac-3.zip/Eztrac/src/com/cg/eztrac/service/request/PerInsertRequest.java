package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.domain.PerDO;

public class PerInsertRequest implements IRestServiceRequest {
	
	private PerDO perDO;
	
	private String tokenId;
	private String channelId;
	
	public PerDO getPerDO() {
		return perDO;
	}
	public void setPerDO(PerDO perDO) {
		this.perDO = perDO;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
}
