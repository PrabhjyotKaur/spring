package com.cg.eztrac.service.response;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.BuildDO;

public class BuildDetailsResponse implements IRestServiceResponse {
	
	private BuildDO buildDO;
	
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	public BuildDO getBuildDO() {
		return buildDO;
	}
	public String getTokenId() {
		return tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	
}