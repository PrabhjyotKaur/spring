package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;

public class RoleDetails implements IRestServiceResponse{
	/** getAllRolePermission SERVICE RESPONSE */
	Integer roleId;
	String roleName;
	List<SectionDetail> sections;
	private String responseDescription;
	private String responseCode;
	private String tokenId = "";
	private String channelId;
	
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public List<SectionDetail> getSections() {
		return sections;
	}
	public void setSections(List<SectionDetail> sections) {
		this.sections = sections;
	}
	
	@Override
	public String getTokenId() {
		return tokenId;
	}
	@Override
	public String getResponseCode() {
		return responseCode;
	}
	@Override
	public String getResponseDescription() {
		return responseDescription;
	}
	@Override
	public String getChannelId() {
		return channelId;
	}
}
