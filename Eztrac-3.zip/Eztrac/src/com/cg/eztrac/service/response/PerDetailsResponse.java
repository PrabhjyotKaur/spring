package com.cg.eztrac.service.response;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.PerDO;

public class PerDetailsResponse implements IRestServiceResponse {
	
	private PerDO perDO;
	
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	public PerDO getPerDO() {
		return perDO;
	}
	public String getTokenId() {
		return tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	
}