package com.cg.eztrac.service.response;

public class SubSectionDetails {
	
	Integer subSectionID;
	Integer subSectionType;
	String subSectionName;
	
	public Integer getSubSectionType() {
		return subSectionType;
	}
	public void setSubSectionType(Integer subSectionType) {
		this.subSectionType = subSectionType;
	}
	public Integer getSubSectionID() {
		return subSectionID;
	}
	public void setSubSectionID(Integer subSectionID) {
		this.subSectionID = subSectionID;
	}
	public String getSubSectionName() {
		return subSectionName;
	}
	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}
}
