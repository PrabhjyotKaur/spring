package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.BuildDO;

public class BuildListResponse implements IRestServiceResponse {
	
	private List<BuildDO> buildDOList;
	
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	public List<BuildDO> getBuildDOList() {
		return buildDOList;
	}
	public String getTokenId() {
		return tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	
}
