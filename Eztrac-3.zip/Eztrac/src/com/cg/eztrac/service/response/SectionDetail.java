	package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.service.domainobject.SubSectionDO;

public class SectionDetail implements IRestServiceResponse{

    
	Integer sectionID;
	Integer sectionType;
	String sectionName;
	List<SubSectionDO> subSection;
	
	public Integer getSectionType() {
		return sectionType;
	}
	public void setSectionType(Integer sectionType) {
		this.sectionType = sectionType;
	}
	public Integer getSectionID() {
		return sectionID;
	}
	public void setSectionID(Integer sectionID) {
		this.sectionID = sectionID;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
	public List<SubSectionDO> getSubSection() {
		return subSection;
	}
	public void setSubSection(List<SubSectionDO> subSection) {
		this.subSection = subSection;
	}
	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getResponseCode() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getResponseDescription() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
