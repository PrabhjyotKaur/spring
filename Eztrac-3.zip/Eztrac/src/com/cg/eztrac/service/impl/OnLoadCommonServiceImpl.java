package com.cg.eztrac.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.request.RolePermissionRequest;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.response.RoleDetails;
import com.cg.eztrac.service.response.SectionDetail;

public class OnLoadCommonServiceImpl implements OnLoadCommonService {
	String className=OnLoadCommonServiceImpl.class.getSimpleName();

	@SuppressWarnings("unchecked")
	@Override
	public List<SectionDetail> getAllSectionDetails(SectionDetailRequest sectionDetailRequest) {
		String methodName="getAllSectionDetails";
		List<SectionDetail> sectionDetailsResponse = null;
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-SectionDetail ", "(before)calling  restClient to get all SectionDetail");
		sectionDetailsResponse = (ArrayList<SectionDetail>) EztracRestClient.invokeRestService(sectionDetailRequest, "http://10.219.13.151:8096/getAllSectionDetailsPost", List.class.getName());
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-SectionDetail ", "(after)call made to restClient to get all SectionDetail");
		if(null == sectionDetailsResponse){
			LoggerManager.writeWaringLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-SectionDetail ",null ,"null response is received from restClient-SectionDetail ");
//			sectionDetailsResponse = new LoginHandler().hardcodeSectionDetailsResponse();
		}
		return sectionDetailsResponse;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RoleDetails> getAllRolePermissionDetails(RolePermissionRequest rolePermissionRequest) {
		String methodName="getAllRolePermissionDetails";
		List<RoleDetails> roleDetailsResponse = null;
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-rolePermission ", "(before)calling  restClient to get all rolePermission");
		roleDetailsResponse=(List<RoleDetails>) EztracRestClient.invokeRestService(rolePermissionRequest, "http://10.219.13.151:8096/getAllRolePermissionPost", List.class.getName());
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-rolePermission ", "(after)call made to restClient to get all rolePermission");
		if(null == roleDetailsResponse){
			LoggerManager.writeWaringLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"call to restClient-rolePermission ",null ,"null response is received from restClient-rolePermission ");
//			roleDetailsResponse = new LoginHandler().hardcodeLoginresponse();
		}
		return roleDetailsResponse;
	}

}
