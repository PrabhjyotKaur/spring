package com.cg.eztrac.service.impl;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.BuildService;
import com.cg.eztrac.service.request.BuildDetailsRequest;
import com.cg.eztrac.service.request.BuildInsertRequest;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.response.BuildDetailsResponse;
import com.cg.eztrac.service.response.BuildInsertResponse;
import com.cg.eztrac.service.response.BuildListResponse;

public class BuildServiceImpl implements BuildService {
	
	private static final String classname = BuildServiceImpl.class.getName();
	
	@Override
	public BuildListResponse getBuildList(BuildListRequest buildListRequest) {
		final String methodName = "getBuildList";
		LoggerManager.writeInfoLog(classname, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
//		BuildListResponse response = (BuildListResponse) EztracRestClient.invokeRestService(buildListRequest, "http://10.147.254.11:8080/build", BuildListResponse.class.getName());
		LoggerManager.writeInfoLog(classname, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return null;
	}

	@Override
	public BuildDetailsResponse getBuildDetails(BuildDetailsRequest buildDetailsRequest) {
		final String methodName = "getBuildDetails";
		LoggerManager.writeInfoLog(classname, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
//		BuildDetailsResponse response = (BuildDetailsResponse) EztracRestClient.invokeRestService(buildDetailsRequest, "http://10.147.254.11:8080/build", BuildDetailsResponse.class.getName());
		LoggerManager.writeInfoLog(classname, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return null;
	}

	@Override
	public BuildInsertResponse insertBuildDetails(BuildInsertRequest buildInsertRequest) {
		final String methodName = "insertBuildDetails";
		LoggerManager.writeInfoLog(classname, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
//		BuildInsertResponse response = (BuildInsertResponse) EztracRestClient.invokeRestService(buildInsertRequest, "http://10.147.254.11:8080/build", BuildInsertResponse.class.getName());
		LoggerManager.writeInfoLog(classname, methodName, ICommonConstants.BUILD_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return null;
	}
	
}
