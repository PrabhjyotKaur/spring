package com.cg.eztrac.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.PerService;
import com.cg.eztrac.service.request.PerDetailsRequest;
import com.cg.eztrac.service.request.PerInsertRequest;
import com.cg.eztrac.service.request.PerListRequest;
import com.cg.eztrac.service.response.PerDetailsResponse;
import com.cg.eztrac.service.response.PerInsertResponse;
import com.cg.eztrac.service.response.PerListResponse;

@Component(value="perServiceImpl")
public class PerServiceImpl implements PerService {
	
	private static final String CLASS_NAME = PerServiceImpl.class.getSimpleName();
	
	@Autowired
	PerListResponse perListResponse;
	
	@Override
	public PerListResponse getPerList(PerListRequest perListRequest) {
		String methodName = "getPerList";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.PER_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
		perListResponse = (PerListResponse) EztracRestClient.invokeRestService(perListRequest, "http://10.219.13.151:8098/getPerDetails", PerListResponse.class.getName());
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.PER_SERVICE_LOG_KEY+" invoked rest service :perListResponse.toString():"+perListResponse.toString(), "After rest service invocation");
		return perListResponse;
	}

	@Override
	public PerDetailsResponse getPerDetails(PerDetailsRequest perDetailsRequest) {
		String methodName = "getPerDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.PER_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
//		PerDetailsResponse response = (PerDetailsResponse) EztracRestClient.invokeRestService(perDetailsRequest, "http://10.147.254.11:8080/per", PerDetailsResponse.class.getName());
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.PER_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return null;
	}

	@Override
	public PerInsertResponse insertPerDetails(PerInsertRequest perInsertRequest) {
		String methodName = "insertPerDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.PER_SERVICE_LOG_KEY+" invoked rest service", "Before calling rest service invocation");
//		PerInsertResponse response = (PerInsertResponse) EztracRestClient.invokeRestService(perInsertRequest, "http://10.147.254.11:8080/per", PerInsertResponse.class.getName());
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.PER_SERVICE_LOG_KEY+" invoked rest service", "After rest service invocation");
		return null;
	}
	
}
