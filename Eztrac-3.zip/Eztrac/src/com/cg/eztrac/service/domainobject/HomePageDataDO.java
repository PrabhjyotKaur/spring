package com.cg.eztrac.service.domainobject;

public class HomePageDataDO {
	String eventDate;
	String eventName;
	String notifications;
	String invoiceCutoffDate;
	/**
	 * @return the eventDate
	 */
	public String getEventDate() {
		return eventDate;
	}
	/**
	 * @param eventDate the eventDate to set
	 */
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}
	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	/**
	 * @return the notifications
	 */
	public String getNotifications() {
		return notifications;
	}
	/**
	 * @param notifications the notifications to set
	 */
	public void setNotifications(String notifications) {
		this.notifications = notifications;
	}
	/**
	 * @return the invoiceCutoffDate
	 */
	public String getInvoiceCutoffDate() {
		return invoiceCutoffDate;
	}
	/**
	 * @param invoiceCutoffDate the invoiceCutoffDate to set
	 */
	public void setInvoiceCutoffDate(String invoiceCutoffDate) {
		this.invoiceCutoffDate = invoiceCutoffDate;
	}
	
}