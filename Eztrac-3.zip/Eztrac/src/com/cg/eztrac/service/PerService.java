package com.cg.eztrac.service;

import com.cg.eztrac.service.request.PerDetailsRequest;
import com.cg.eztrac.service.request.PerInsertRequest;
import com.cg.eztrac.service.request.PerListRequest;
import com.cg.eztrac.service.response.PerDetailsResponse;
import com.cg.eztrac.service.response.PerInsertResponse;
import com.cg.eztrac.service.response.PerListResponse;

public interface PerService {
	
	public PerListResponse getPerList(PerListRequest perListRequest);
	
	public PerDetailsResponse getPerDetails(PerDetailsRequest perDetailsRequest);
	
	public PerInsertResponse insertPerDetails(PerInsertRequest perInsertRequest);
	
}
