package com.cg.eztrac.handler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.vo.PerVO;

@Component(value="perHandler")
public class PerHandler {
	
	private static final String CLASS_NAME = PerHandler.class.getSimpleName();
	
	@Autowired
	PerDO perDO;
	
	public List<PerVO> getPerList(PerVO perVO) throws Exception {
		
		final String METHOD_NAME = "getPerList";
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerList:", perVO.toString());
		
		List<PerVO> perVOList = new ArrayList<PerVO>();
		
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		perDO.getPerList(perDO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.getPerList::", perDO.toString());
		
		return perVOList;
	}
	
	public void insertPerDetails(PerVO perVO) throws Exception {
		final String METHOD_NAME = "insertPerDetails";
		
		CommonUtility.copyBeanProperties(perVO, perDO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerHandler.insertPerDetails:", perDO.toString());
		
		perDO.insertPerDetails(perDO);
	}
	
}
