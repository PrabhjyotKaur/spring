package com.cg.eztrac.handler;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.vo.HomePageVO;
import com.cg.eztrac.vo.SectionVO;
import com.google.gson.Gson;

public class HomePageHandler {

	public HomePageVO switchRoleMenuHandler(HttpSession httpSession, HomePageVO homePageVO, ServletContextImpl servletContextImpl) {
		int roleId=homePageVO.getMenuVO().getRoleId();
		Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = (Map<Integer, Map<Integer, List<SectionVO>>>) servletContextImpl.getObjectFromServletContext(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT);
		Map<Integer, List<SectionVO>> menuBasedOnRole = allRoleMenuAccebiltiy.get(roleId);
		String menuMapJson = new Gson().toJson(menuBasedOnRole);
		homePageVO.getMenuVO().setCustomizeJsonMap(menuMapJson);
		homePageVO.getMenuVO().setSwitchRoles((Map<Integer,String>)httpSession.getAttribute(ICommonConstants.PERMISSIABLE_ROLEID_SESSION));
		menuBasedOnRole = null;
		return homePageVO;
	}
	
}
