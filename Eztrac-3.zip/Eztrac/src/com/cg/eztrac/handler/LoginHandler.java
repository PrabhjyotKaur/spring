package com.cg.eztrac.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.service.domainobject.RoleDO;
import com.cg.eztrac.service.domainobject.UserDO;
import com.cg.eztrac.vo.HomePageVO;
import com.cg.eztrac.vo.LoginVO;
import com.cg.eztrac.vo.SectionVO;
import com.google.gson.Gson;

public class LoginHandler {
	String className=LoginHandler.class.getSimpleName();
	
	@SuppressWarnings("unchecked")
	public HomePageVO callSignInService(LoginVO loginVO, ServletContextImpl servletContextImpl, HttpSession httpSession) {
		String methodName="callSignInService";
		HomePageVO homePageVO = new HomePageVO ();
		try {
			UserDO userDO = new UserDO(); 
			CommonUtility.copyBeanProperties(loginVO, userDO);
			userDO = userDO.callSignInService(userDO);
			Map<Integer,String> sortedRoles = getSortedRoles(userDO.getRoles());
			httpSession.setAttribute(ICommonConstants.PERMISSIABLE_ROLEID_SESSION, sortedRoles);
			if(null!=sortedRoles && !sortedRoles.isEmpty()){
				Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = (Map<Integer, Map<Integer, List<SectionVO>>>) servletContextImpl.getObjectFromServletContext(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT);
				Map<Integer, List<SectionVO>> menuBasedOnRole = allRoleMenuAccebiltiy.get(sortedRoles.keySet().toArray()[0]);
				String menuMapJson = new Gson().toJson(menuBasedOnRole);
				homePageVO.getMenuVO().setCustomizeJsonMap(menuMapJson);
				homePageVO.getMenuVO().setSwitchRoles(sortedRoles);
				menuBasedOnRole = null;
			}
//			CommonUtility.copyBeanProperties(userDO, loginVO);
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After calling (service)-loginSignIn()");
		} catch (Exception e) {
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e , " Exception while callSignInService ");
		}
		/*Map<Integer, String> sortedRoles = new HashMap<Integer, String>();
		sortedRoles.put(1, "1");
		sortedRoles.put(2, "2");
		homePageVO.getMenuVO().setSwitchRoles(sortedRoles );*/
		return homePageVO;
	}

	private Map<Integer,String> getSortedRoles(List<RoleDO> rolePermissionDetails) {
		Map<Integer,String> roleNames =new HashMap<Integer,String>(); 
		for (RoleDO roleDO : rolePermissionDetails) {
			roleNames.put(roleDO.getRoleId(), ""+roleDO.getRoleId());
		}
		return roleNames;
	}

/*
	public List<SectionDetail> hardcodeSectionDetailsResponse() {
		
		List<SectionDetail> sectionDetailResponseList=new ArrayList<SectionDetail>();
		
		SectionDetail sectionDetailResponse=new SectionDetail();		
		sectionDetailResponse.setSectionId(11);
		sectionDetailResponse.setSectionName("PROJECTS|PER");
		sectionDetailResponse.setSectionType("1");
		HashMap<Integer, HashMap<String, List<SubSections>>> sectionDetailMap =new HashMap<Integer, HashMap<String, List<SubSections>>>();
		HashMap<String, List<SubSections>> subSectionMap=new HashMap<String, List<SubSections>>();
		List<SubSections> subectionlist=new ArrayList<SubSections>();
		SubSections subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSection.setSubSectionName("EDIT");
		subSection.setEligibleFlag(true);
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(102);
		subSection.setSubSectionName("UPLOAD");
		subectionlist.add(subSection);
		subSectionMap.put("PROJECTS|PER", subectionlist);
		sectionDetailMap.put(11,subSectionMap);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(12);
		sectionDetailResponse.setSectionName("PROJECTS|BUILD");	
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(104);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);	
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(13);
		sectionDetailResponse.setSectionName("Projects|TIMESHEET");	
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(105);
		subSection.setSubSectionName("TIMESHEET");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(14);
		sectionDetailResponse.setSectionName("Reports|Cards Services Report");	
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(106);
		subSection.setSubSectionName("INVOICE REPORTS");		
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(107);
		subSection.setSubSectionName("EFFORT VARIANCE REPORT");		
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(15);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(108);
		subSection.setSubSectionName("Missed Timesheet Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(109);
		subSection.setSubSectionName("Timesheet Reports");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(16);
		sectionDetailResponse.setSectionName("HELPDESK");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(110);
		subSection.setSubSectionName("Log Request");
		subectionlist.add(subSection);
		subSection=new SubSections();	
		subSection.setSubSectionId(111);
		subSection.setSubSectionName("Service Request");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(17);
		sectionDetailResponse.setSectionName("Administration");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(112);
		subSection.setSubSectionName("USERS");
		subectionlist.add(subSection);
		subSection=new SubSections();	
		subSection.setSubSectionId(113);
		subSection.setSubSectionName("SYSTEM");
		subectionlist.add(subSection);
		subSection=new SubSections();	
		subSection.setSubSectionId(114);
		subSection.setSubSectionName("SUB SYSTEM");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(18);
		sectionDetailResponse.setSectionName("Finance And Business");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(115);
		subSection.setSubSectionName("Travel expenses and others");	
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(19);
		sectionDetailResponse.setSectionName("Invoice and Billing");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(116);
		subSection.setSubSectionName("INVOICE REPORTS");	
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		return sectionDetailResponseList;
	}
	
	public List<RoleDetails> hardcodeLoginresponse() {
		
		List<RoleDetails> rolePermisssionList = new  ArrayList<RoleDetails>();
		RoleDetails rolePermissionDetails=new RoleDetails();
		SectionDetail sectionDetailResponse=new SectionDetail();
		
		HashMap<Integer, HashMap<String, List<SubSections>>> sectionDetailMap = new HashMap<Integer, HashMap<String, List<SubSections>>>();
		HashMap<String, List<SubSections>> sectionMap = new HashMap<String, List<SubSections>>();
		*//*************** list[0] of rolePermission **********************//*
		rolePermissionDetails.setRoleId(2);
		rolePermissionDetails.setRoleName("PMO");
		List<SectionDetail> sectionDetailResponseList=new ArrayList<SectionDetail>();
		
		sectionDetailResponse.setSectionId(11);
		sectionDetailResponse.setSectionName("PROJECTS|PER");
		sectionDetailResponse.setSectionType("1");
		List<SubSections> subectionlist=new ArrayList<SubSections>();
		SubSections subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionMap.put(sectionDetailResponse.getSectionName(), subectionlist);
		sectionDetailMap.put(sectionDetailResponse.getSectionId(), sectionMap);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(12);
		sectionDetailResponse.setSectionName("PROJECTS|build");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(13);
		sectionDetailResponse.setSectionName("PROJECTS|timesheet");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(105);
		subSection.setSubSectionName("Timesheet");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(14);
		sectionDetailResponse.setSectionName("Reports|Cards Services Report");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(106);
		subSection.setSubSectionName("Invoice Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(107);
		subSection.setSubSectionName("Effort Variance Report");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(15);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(108);
		subSection.setSubSectionName("Missed Timesheet Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(109);
		subSection.setSubSectionName("Timesheet Reports");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(16);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(110);
		subSection.setSubSectionName("Log Request");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(111);
		subSection.setSubSectionName("Service Request");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);		
		
		rolePermissionDetails.setSectionDetailResponse(sectionDetailResponseList);
		rolePermisssionList.add(rolePermissionDetails);
		*//*************** End of  list[0] of rolePermission **********************//*
		
		
		*//*************** Second list of rolePermission **********************//*
		rolePermissionDetails.setRoleId(3);
		rolePermissionDetails.setRoleName("PM");
		sectionDetailResponseList=new ArrayList<SectionDetail>();
		
		sectionDetailResponse.setSectionId(11);
		sectionDetailResponse.setSectionName("PROJECTS|PER");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);			
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(12);
		sectionDetailResponse.setSectionName("PROJECTS|build");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(13);
		sectionDetailResponse.setSectionName("PROJECTS|timesheet");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(105);
		subSection.setSubSectionName("Timesheet");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(14);
		sectionDetailResponse.setSectionName("Reports|Cards Services Report");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(106);
		subSection.setSubSectionName("Invoice Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(107);
		subSection.setSubSectionName("Effort Variance Report");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(15);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(108);
		subSection.setSubSectionName("Missed Timesheet Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(109);
		subSection.setSubSectionName("Timesheet Reports");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(16);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(110);
		subSection.setSubSectionName("Log Request");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(111);
		subSection.setSubSectionName("Service Request");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);		
		
		rolePermissionDetails.setSectionDetailResponse(sectionDetailResponseList);
		rolePermisssionList.add(rolePermissionDetails);
		*//*************** End of Second list of rolePermission **********************//*
		
//		loginInfoResponse.setRolePersmission(rolePermisssionList);
		return rolePermisssionList;
	}*/
}
