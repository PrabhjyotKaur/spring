package com.cg.eztrac.handler;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.BuildDO;
import com.cg.eztrac.vo.BuildVO;

public class BuildHandler {
	
	private static final String CLASS_NAME = BuildHandler.class.getSimpleName();
	
	public void insertBuildDetails(BuildVO buildVO) throws Exception {
		final String METHOD_NAME = "insertBuildDetails";
		
		BuildDO buildDO = new BuildDO();
		CommonUtility.copyBeanProperties(buildVO, buildDO);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildHandler.buildSubmit:", buildDO.toString());
		
		buildDO.insertBuildDetails(buildDO);
	}
	
}
