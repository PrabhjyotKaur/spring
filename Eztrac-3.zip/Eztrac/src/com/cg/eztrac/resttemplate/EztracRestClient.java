package com.cg.eztrac.resttemplate;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.common.LoggerManager;

public class EztracRestClient {
	static final String CLASS_NAME = EztracRestClient.class.getSimpleName();

	@SuppressWarnings({ "unused", "unchecked" })
	public static Object invokeRestService(IRestServiceRequest requestObject, String requestServiceURL, String responseObjectType) {
		final String methodName = "invokeRestService ";
		String defaultRestServiceMethod = "POST";
		String serviceMethodType = "";
		HttpMethod serviceMethod = null;

		if (null == serviceMethodType) {
			serviceMethod = HttpMethod.valueOf(serviceMethodType);
		} else {
			serviceMethod = HttpMethod.valueOf(defaultRestServiceMethod);
		}
		MultiValueMap<String, Object> headers = new LinkedMultiValueMap<String, Object>();
		headers.add("Accept", MediaType.APPLICATION_JSON.toString());
		headers.add("Content-Type", MediaType.APPLICATION_JSON.toString());
		@SuppressWarnings("rawtypes")
		HttpEntity request = new HttpEntity(requestObject, headers);

		ResponseEntity<?> response = null;
		RestTemplate restTemplateObj = new RestTemplate();
		Object postForObject = null;
		Object responseObject = null;
		try {
			response = restTemplateObj.exchange(requestServiceURL, HttpMethod.valueOf(defaultRestServiceMethod), request, Class.forName(responseObjectType));
			if (null != response) {
				 responseObject = response.getBody();
				 /*if(body instanceof ArrayList){
					 respObjList = (ArrayList<IRestServiceResponse>) body;
				 } else {
					 respObj = (IRestServiceResponse) body;
					 return respObj;
				 }*/
			}
		} catch (Exception e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,methodName,e.getMessage(), e,"exception while getting the response of the services");
		}
		return responseObject;
	}
}
