package com.cg.eztrac.vo;

public class HomePageVO {
	
	MenuVO menuVO = new MenuVO();
	
	public MenuVO getMenuVO() {
		return menuVO;
	}
	public void setMenuVO(MenuVO menuVO) {
		this.menuVO = menuVO;
	}
}
