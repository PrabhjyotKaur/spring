package com.cg.eztrac.vo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class BuildVO extends EstimationVO {

	//General - Fields - Build Module
	private String system;
	private String subSystem;
	private String currentBuildPhase;
	private String onsiteLeverage;
	private String onsiteTimesheetLeverage;
	private double phaseCompletion;
	private String cancelDateString;
	private Date cancelDate;
	private String[] assignedToArray;
	private int subAccountId;
	
	private BuildChangeControlVO buildChangeControlVO;
	private BuildLoeVO buildLoeVO;
	
	private List<BuildChangeControlVO> buildChangeControlVOList;
	
	//lists to populate dropdowns
	private List<String> perNumberList;
	private List<String> systemList;
	private List<String> subSystemList;
	private List<String> currentBuildPhaseList;
	private List<String> assignedToList;
	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getSubSystem() {
		return subSystem;
	}
	public void setSubSystem(String subSystem) {
		this.subSystem = subSystem;
	}
	public String getCurrentBuildPhase() {
		return currentBuildPhase;
	}
	public void setCurrentBuildPhase(String currentBuildPhase) {
		this.currentBuildPhase = currentBuildPhase;
	}
	public String getOnsiteLeverage() {
		return onsiteLeverage;
	}
	public void setOnsiteLeverage(String onsiteLeverage) {
		this.onsiteLeverage = onsiteLeverage;
	}
	public String getOnsiteTimesheetLeverage() {
		return onsiteTimesheetLeverage;
	}
	public void setOnsiteTimesheetLeverage(String onsiteTimesheetLeverage) {
		this.onsiteTimesheetLeverage = onsiteTimesheetLeverage;
	}
	public double getPhaseCompletion() {
		return phaseCompletion;
	}
	public void setPhaseCompletion(double phaseCompletion) {
		this.phaseCompletion = phaseCompletion;
	}
	public String getCancelDateString() {
		return cancelDateString;
	}
	public void setCancelDateString(String cancelDateString) {
		this.cancelDateString = cancelDateString;
	}
	public Date getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String[] getAssignedToArray() {
		return assignedToArray;
	}
	public void setAssignedToArray(String[] assignedToArray) {
		this.assignedToArray = assignedToArray;
	}
	public int getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	public BuildChangeControlVO getBuildChangeControlVO() {
		return buildChangeControlVO;
	}
	public void setBuildChangeControlVO(BuildChangeControlVO buildChangeControlVO) {
		this.buildChangeControlVO = buildChangeControlVO;
	}
	public BuildLoeVO getBuildLoeVO() {
		return buildLoeVO;
	}
	public void setBuildLoeVO(BuildLoeVO buildLoeVO) {
		this.buildLoeVO = buildLoeVO;
	}
	public List<BuildChangeControlVO> getBuildChangeControlVOList() {
		return buildChangeControlVOList;
	}
	public void setBuildChangeControlVOList(List<BuildChangeControlVO> buildChangeControlVOList) {
		this.buildChangeControlVOList = buildChangeControlVOList;
	}
	public List<String> getPerNumberList() {
		return perNumberList;
	}
	public void setPerNumberList(List<String> perNumberList) {
		this.perNumberList = perNumberList;
	}
	public List<String> getSystemList() {
		return systemList;
	}
	public void setSystemList(List<String> systemList) {
		this.systemList = systemList;
	}
	public List<String> getSubSystemList() {
		return subSystemList;
	}
	public void setSubSystemList(List<String> subSystemList) {
		this.subSystemList = subSystemList;
	}
	public List<String> getCurrentBuildPhaseList() {
		return currentBuildPhaseList;
	}
	public void setCurrentBuildPhaseList(List<String> currentBuildPhaseList) {
		this.currentBuildPhaseList = currentBuildPhaseList;
	}
	public List<String> getAssignedToList() {
		return assignedToList;
	}
	public void setAssignedToList(List<String> assignedToList) {
		this.assignedToList = assignedToList;
	}
	
	@Override
	public String toString() {
		return "BuildVO [system=" + system + ", subSystem=" + subSystem + ", currentBuildPhase=" + currentBuildPhase
				+ ", onsiteLeverage=" + onsiteLeverage + ", onsiteTimesheetLeverage=" + onsiteTimesheetLeverage
				+ ", phaseCompletion=" + phaseCompletion + ", cancelDateString=" + cancelDateString + ", cancelDate="
				+ cancelDate + ", assignedToArray=" + Arrays.toString(assignedToArray) + ", subAccountId="
				+ subAccountId + ", buildChangeControlVO=" + buildChangeControlVO + ", buildLoeVO=" + buildLoeVO
				+ ", buildChangeControlVOList=" + buildChangeControlVOList + ", perNumberList=" + perNumberList
				+ ", systemList=" + systemList + ", subSystemList=" + subSystemList + ", currentBuildPhaseList="
				+ currentBuildPhaseList + ", assignedToList=" + assignedToList + "]";
	}
	
}
