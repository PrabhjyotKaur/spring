package com.cg.eztrac.vo;

public class PerLoeVO extends LoeVO {
	
	private int perPlanningLOETotal;
	private int perExecutionLOETotal;
	private int perActualDaysLOETotal;
	
	public int getPerPlanningLOETotal() {
		return perPlanningLOETotal;
	}
	public void setPerPlanningLOETotal(int perPlanningLOETotal) {
		this.perPlanningLOETotal = perPlanningLOETotal;
	}
	public int getPerExecutionLOETotal() {
		return perExecutionLOETotal;
	}
	public void setPerExecutionLOETotal(int perExecutionLOETotal) {
		this.perExecutionLOETotal = perExecutionLOETotal;
	}
	public int getPerActualDaysLOETotal() {
		return perActualDaysLOETotal;
	}
	public void setPerActualDaysLOETotal(int perActualDaysLOETotal) {
		this.perActualDaysLOETotal = perActualDaysLOETotal;
	}
	
	@Override
	public String toString() {
		return "PerLoeVO [perPlanningLOETotal=" + perPlanningLOETotal + ", perExecutionLOETotal=" + perExecutionLOETotal
				+ ", perActualDaysLOETotal=" + perActualDaysLOETotal + "]";
	}
	
}
