package com.cg.eztrac.vo;

import java.util.Date;

public class PurchaseOrderVO {
	
	private String poNumber;
	private double poAmount;
	private String createdBy;
	private String createdOnString;
	private Date createdOn;
	
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public double getPoAmount() {
		return poAmount;
	}
	public void setPoAmount(double poAmount) {
		this.poAmount = poAmount;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOnString() {
		return createdOnString;
	}
	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	@Override
	public String toString() {
		return "PurchaseOrderVO [poNumber=" + poNumber + ", poAmount=" + poAmount + ", createdBy=" + createdBy
				+ ", createdOnString=" + createdOnString + ", createdOn=" + createdOn + "]";
	}
	
}
