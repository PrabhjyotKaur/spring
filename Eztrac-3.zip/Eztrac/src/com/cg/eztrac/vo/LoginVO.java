package com.cg.eztrac.vo;

import java.io.Serializable;

public class LoginVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5713679176789233930L;
	private String userName;
	private String password;
	private String tokenId;
	
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
