package com.cg.eztrac.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SectionVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 716690851791074014L;
	boolean elligbleFlag = false;
	private Integer sectionId;
	private String sectionName="";
	private List<SubSectionVO> subSectionVO = new ArrayList<SubSectionVO>();
	
	public List<SubSectionVO> getSubSectionVO() {
		return subSectionVO;
	}
	public void setSubSectionVO(List<SubSectionVO> subSectionVO) {
		this.subSectionVO = subSectionVO;
	}
	public boolean isElligbleFlag() {
		return elligbleFlag;
	}
	public void setElligbleFlag(boolean elligbleFlag) {
		this.elligbleFlag = elligbleFlag;
	}
	public Integer getSectionId() {
		return sectionId;
	}
	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
	
}
